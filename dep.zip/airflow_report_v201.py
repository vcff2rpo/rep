# SPDX-License-Identifier: Apache-2.0
"""Airflow 3.1 Runtime Report v201 plugin loader. Copy with adjacent verified ZIP.

Unpacks immutable payload to a private process-local directory because the
original v201 renderer is loaded from Path(__file__).with_name(...).
"""
from __future__ import annotations
import atexit
import hashlib
import importlib
import json
import logging
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import sys
import tempfile
from zipfile import ZipFile, BadZipFile

RELEASE = "release-20261029-201"
BUNDLE_NAME = 'airflow_report_v201.zip'
BUNDLE_SHA256 = '11da51bf920e4da664e552ef96cc6512f73c421e08e2239ebaf9af383c9b0075'
MANIFEST_NAME = "RR201_PLUGIN_BUNDLE_MANIFEST.json"
LOG = logging.getLogger("airflow.plugin.runtime_report_v201")
_PRIVATE_ROOT = None


def _activate():
    global _PRIVATE_ROOT
    path = Path(__file__).resolve().with_name(BUNDLE_NAME)
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 32 * 1024 * 1024:
        raise ValueError("v201 bundle missing, symlinked, or oversized")
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != BUNDLE_SHA256:
        raise ValueError("v201 bundle SHA-256 mismatch")
    with ZipFile(path) as z:
        infos = z.infolist()
        if len(infos) > 150:
            raise ValueError("Too many runtime bundle members")
        filenames = [info.filename for info in infos]
        if len(filenames) != len(set(filenames)):
            raise ValueError("Duplicate runtime bundle entries")
        manifest = json.loads(z.read(MANIFEST_NAME))
        if manifest.get("release") != RELEASE or manifest.get("schema") != "airflow-runtime-report-v201-copyonly-v1":
            raise ValueError("Wrong runtime bundle manifest")
        records = manifest.get("files")
        if not isinstance(records, dict) or set(records) != set(filenames)-{MANIFEST_NAME}:
            raise ValueError("Runtime bundle inventory mismatch")
        if sum(info.file_size for info in infos) > 32 * 1024 * 1024:
            raise ValueError("Runtime bundle exceeds declared budget")
        content = {}
        for info in infos:
            name = info.filename
            parts = PurePosixPath(name).parts
            if (info.is_dir() or not parts or name.startswith("/") or "\\" in name
                or ":" in name or "//" in name or any(p in (".", "..") for p in name.split("/"))
                or ((info.external_attr>>16)&0o170000)==stat.S_IFLNK
                or info.file_size > 16 * 1024 * 1024):
                raise ValueError("Unsafe runtime entry")
            if name == MANIFEST_NAME:
                continue
            with z.open(info) as source:
                raw = source.read(16 * 1024 * 1024 + 1)
            record = records[name]
            if not isinstance(record,dict) or len(raw)!=info.file_size or len(raw)!=record.get("bytes") or hashlib.sha256(raw).hexdigest()!=record.get("sha256"):
                raise ValueError("Runtime bundle content digest mismatch")
            content[name] = raw
    if set(content) != set(records):
        raise ValueError("Incomplete runtime payload")
    for name in ("airflow_runtime_report_plugin.py", "airflow_runtime_report_v3.html", "airflow_report/__init__.py", "bounded_io.py"):
        if name not in content:
            raise ValueError("Missing essential runtime file: " + name)
    # No writing into the Airflow plugins folder, no production-file mutation.
    stage = Path(tempfile.mkdtemp(prefix="rr201_plugin_"))
    stage.chmod(0o700)
    try:
        for name, raw in sorted(content.items()):
            target = stage.joinpath(*PurePosixPath(name).parts)
            target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            with target.open("xb") as dest:
                dest.write(raw)
            target.chmod(0o600)
        for name in ("airflow_report", "airflow_runtime_report_plugin"):
            existing = sys.modules.get(name)
            if existing is not None:
                raise ValueError("Conflicting preloaded module prevents isolated v201 registration: "+name)
        sys.path.insert(0,str(stage))
        try:
            plugin = importlib.import_module("airflow_runtime_report_plugin")
        except Exception:
            sys.path.remove(str(stage))
            raise
        if getattr(plugin,"PLUGIN_RELEASE",None) != RELEASE or getattr(plugin,"PLUGIN_EXPECTED_RENDERER_SHA256",None) != manifest.get("rendererSha256"):
            raise ValueError("Loaded plugin identity mismatch")
        loaded_path = Path(plugin.__file__).resolve()
        if loaded_path != (stage/"airflow_runtime_report_plugin.py").resolve():
            raise ValueError("Untrusted plugin module origin")
        cls = getattr(plugin,"AirflowRuntimeReportPlugin")
        _PRIVATE_ROOT = stage
        atexit.register(shutil.rmtree,stage,ignore_errors=True)
        return cls
    except Exception:
        shutil.rmtree(stage,ignore_errors=True)
        raise

try:
    AirflowRuntimeReportPlugin = _activate()
except (OSError, ValueError, ImportError, RuntimeError, KeyError, TypeError, BadZipFile, EOFError) as exc:
    LOG.error("Runtime Report v201 loader rejected bundle: %s",exc)
    # No valid AirflowPlugin subclass is exported on an invalid bundle.
