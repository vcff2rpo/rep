# SPDX-License-Identifier: Apache-2.0
"""FSviewer Airflow source-plugin loader.

The implementation is stored in a sibling zip bundle so Airflow's recursive
plugins-directory scanner sees only this loader as Python source.
"""

from __future__ import annotations

import hashlib
import importlib
import os
import secrets
import stat
import sys
from pathlib import Path

from airflow.plugins_manager import AirflowPlugin

EXPECTED_PACKAGE_VERSION = "0.2.216"
EXPECTED_BUNDLE_SHA256 = "a97ce21e49f55fcce72e016eb2ce87250b15483e9eeaefb95fe4ea0c60086fa4"  # fmt: skip
BUNDLE_NAME = "airflow_fs_viewer_bundle.zip"
MAX_BUNDLE_BYTES = 2 * 1024 * 1024
MIN_PYTHON = (3, 12)


class _InactiveFilesystemViewerPlugin(AirflowPlugin):
    """An unavailable/disabled optional plugin never exposes filesystem routes."""

    name = "fsviewer"
    fastapi_apps: list[dict[str, object]] = []  # noqa: RUF012 - Airflow registration lists
    external_views: list[dict[str, object]] = []  # noqa: RUF012 - Airflow registration lists
    fastapi_root_middlewares: list[dict[str, object]] = []  # noqa: RUF012 - Airflow registration lists
    load_error = "disabled"


def _bundle_path() -> Path:
    """Return the release-paired sibling bundle expected beside this loader."""
    return Path(__file__).resolve().with_name(BUNDLE_NAME)


def _bundle_signature(info: os.stat_result) -> tuple[int, int, int, int, int]:
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def _verify_bundle(path: Path) -> tuple[int, int, int, int, int]:
    """Hash a bounded, non-linked sibling file with no symlink traversal."""
    flags = os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK
    fd = os.open(path, flags)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or not 0 < before.st_size <= MAX_BUNDLE_BYTES:
            raise RuntimeError("FSviewer bundle is linked, non-regular or exceeds the byte limit")
        hasher = hashlib.sha256()
        remaining = MAX_BUNDLE_BYTES
        while True:
            chunk = os.read(fd, min(64 * 1024, remaining + 1))
            if not chunk:
                break
            remaining -= len(chunk)
            if remaining < 0:
                raise RuntimeError("FSviewer bundle exceeds the byte limit")
            hasher.update(chunk)
        after = os.fstat(fd)
        if _bundle_signature(after) != _bundle_signature(before):
            raise RuntimeError("FSviewer bundle changed during verification")
        if not secrets.compare_digest(hasher.hexdigest(), EXPECTED_BUNDLE_SHA256):
            raise RuntimeError("FSviewer bundle digest mismatch; replace the paired loader and bundle")
        if _bundle_signature(os.stat(path, follow_symlinks=False)) != _bundle_signature(after):
            raise RuntimeError("FSviewer bundle was replaced during verification")
        return _bundle_signature(after)
    finally:
        os.close(fd)


def _verify_all_module_origins(bundle: Path) -> None:
    """Reject any preloaded or newly imported FSviewer component outside this ZIP."""
    for name, module in tuple(sys.modules.items()):
        if name == "airflow_fs_viewer" or name.startswith("airflow_fs_viewer."):
            if module is None:
                raise RuntimeError("FSviewer module loading is incomplete: " + name)
            _require_verified_bundle_origin(module, name, bundle)


def _module_origin(module: object) -> str | None:
    spec = getattr(module, "__spec__", None)
    origin = getattr(spec, "origin", None) if spec is not None else None
    if isinstance(origin, str) and origin:
        return origin
    file_name = getattr(module, "__file__", None)
    return file_name if isinstance(file_name, str) and file_name else None


def _require_verified_bundle_origin(module: object, name: str, bundle: Path) -> None:
    """Reject preloaded or shadowed modules that did not originate from the verified bundle."""
    origin = _module_origin(module)
    bundle_prefix = str(bundle.resolve()).replace("\\", "/").rstrip("/") + "/"
    normalized_origin = origin.replace("\\", "/") if origin is not None else ""
    from zipimport import zipimporter

    spec = getattr(module, "__spec__", None)
    loader = getattr(spec, "loader", None) if spec is not None else None
    if (
        not normalized_origin.startswith(bundle_prefix)
        or not isinstance(loader, zipimporter)
        or Path(loader.archive).resolve() != bundle.resolve()
    ):
        raise RuntimeError(
            "FSviewer source deployment detected a preloaded or shadowed module outside "
            f"the verified bundle: {name} origin={origin!r}. "
            "Remove mixed wheel/source deployments and restart the Airflow API server."
        )


def _load_verified_plugin() -> type[AirflowPlugin]:
    """Verify the local code bundle before import; never open the audit destination."""
    bundle = _bundle_path()
    signature = _verify_bundle(bundle)
    bundle_text = str(bundle)
    if bundle_text not in sys.path:
        sys.path.insert(0, bundle_text)
    importlib.invalidate_caches()
    package = importlib.import_module("airflow_fs_viewer")
    _require_verified_bundle_origin(package, "airflow_fs_viewer", bundle)
    _verify_all_module_origins(bundle)
    if getattr(package, "__version__", None) != EXPECTED_PACKAGE_VERSION:
        raise RuntimeError("FSviewer loader/package version mismatch")
    plugin = importlib.import_module("airflow_fs_viewer.plugin")
    _require_verified_bundle_origin(plugin, "airflow_fs_viewer.plugin", bundle)
    _verify_all_module_origins(bundle)
    if _bundle_signature(os.stat(bundle, follow_symlinks=False)) != signature:
        raise RuntimeError("FSviewer bundle changed while loading modules")
    plugin_class = getattr(plugin, "FilesystemViewerPlugin", None)
    if not isinstance(plugin_class, type) or not issubclass(plugin_class, AirflowPlugin):
        raise RuntimeError("FSviewer bundle has no valid Airflow plugin class")
    return plugin_class


FilesystemViewerPlugin: type[AirflowPlugin]
_enabled = os.environ.get("AIRFLOW_FS_VIEWER_ENABLED", "true").strip().lower()
if _enabled == "false":
    FilesystemViewerPlugin = _InactiveFilesystemViewerPlugin
elif _enabled != "true":
    _InactiveFilesystemViewerPlugin.load_error = "invalid-enable-setting"
    FilesystemViewerPlugin = _InactiveFilesystemViewerPlugin
elif sys.version_info < MIN_PYTHON:
    _InactiveFilesystemViewerPlugin.load_error = (
        f"unsupported-python:{sys.version_info.major}.{sys.version_info.minor};requires>=3.12"
    )
    FilesystemViewerPlugin = _InactiveFilesystemViewerPlugin
else:
    try:
        FilesystemViewerPlugin = _load_verified_plugin()
    except Exception as exc:
        # Airflow remains available; routes are absent rather than importing unverified code.
        # The plugin manager/CLI can inspect load_error without exposing exception text.
        _InactiveFilesystemViewerPlugin.load_error = "load-failed:" + type(exc).__name__
        FilesystemViewerPlugin = _InactiveFilesystemViewerPlugin

# Export exactly one class for Airflow's module-class discovery.
del _InactiveFilesystemViewerPlugin
__all__ = ["FilesystemViewerPlugin"]


def _command_main() -> int:
    """Run verified-package preflight when loader is executed administratively."""
    if sys.argv[1:] != ["--preflight"]:
        print("usage: airflow_fs_metadata_viewer_plugin.py --preflight")
        return 2
    load_error = getattr(FilesystemViewerPlugin, "load_error", None)
    if load_error is not None:
        print(f"FAIL release-loader: {load_error}")
        return 1
    from airflow_fs_viewer.preflight import main as preflight_main

    return preflight_main()


if __name__ == "__main__":
    raise SystemExit(_command_main())
