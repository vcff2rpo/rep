# SPDX-License-Identifier: Apache-2.0
"""Authenticated Airflow UI plugin for materialized and static runtime reports. Generated deterministically from modular Apache-2.0 canonical source."""
from __future__ import annotations
import logging
PLUGIN_NAME = 'airflow_runtime_report_ui'
PLUGIN_RELEASE = 'release-20261021-186'
PLUGIN_EXPECTED_RENDERER_SHA256 = 'd655352264ec758c9235601a21b9de5d781d077c06ee51600b8fc89e365f4fc8'
PLUGIN_DISPLAY_NAME = 'Report'
PLUGIN_ROUTE = 'runtime-report'
PLUGIN_URL_PREFIX = '/airflow-runtime-report'
CURRENT_REPORT_FILENAME = 'latest.html'
RENDERER_FILENAME = 'airflow_runtime_report_v3.html'
MAX_REPORT_BYTES = 128 * 1024 * 1024
STREAM_CHUNK_BYTES = 1024 * 1024
DEFAULT_LIVE_REPORT_DAYS = 2
DEFAULT_LIVE_FUTURE_DAYS = 1
REPOSITORY_GENERATION_FILENAME = '.report.generation'
INITIALIZATION_JOB_SCHEMA = 'airflow-runtime-report-initialization-job-v1'
INITIALIZATION_OPERATION_SCHEMA = 'airflow-runtime-report-initialization-operation-v1'
INITIALIZATION_STATUS_SCHEMA = 'airflow-runtime-report-initialization-status-v1'
EMPTY_REPOSITORY_IDENTITY = (0, 0, 0, 0)
LOG = logging.getLogger('airflow_runtime_report_plugin')
_REPORT_CSP = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; font-src 'none'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-src 'none'; child-src 'none'; worker-src 'none'; manifest-src 'none'; media-src 'none'; frame-ancestors 'self'"
_RESPONSE_HEADERS = {'Cache-Control': 'private, no-store, max-age=0', 'Pragma': 'no-cache', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Permissions-Policy': 'accelerometer=(), camera=(), geolocation=(), gyroscope=(), microphone=(), payment=(), usb=()', 'Content-Security-Policy': _REPORT_CSP, 'Content-Disposition': 'inline; filename="airflow-runtime-report.html"', 'X-Airflow-Runtime-Report-Plugin-Release': PLUGIN_RELEASE, 'X-Airflow-Runtime-Report-Renderer-SHA256': PLUGIN_EXPECTED_RENDERER_SHA256}
_BOOTSTRAP_CSP = _REPORT_CSP.replace("connect-src 'none'", "connect-src 'self'")
_BOOTSTRAP_HEADERS = {**_RESPONSE_HEADERS, 'Content-Security-Policy': _BOOTSTRAP_CSP}
_BOOTSTRAP_HEADERS.pop('Content-Disposition', None)
_JSON_HEADERS = {'Cache-Control': 'private, no-store, max-age=0', 'Pragma': 'no-cache', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "default-src 'none'; frame-ancestors 'self'", 'X-Airflow-Runtime-Report-Plugin-Release': PLUGIN_RELEASE}
AUTHENTICATION_NOTICE_MESSAGE = 'Authentication token expired or no longer valid. Please log in to Airflow again.'
try:
    from airflow.api_fastapi.auth.managers.base_auth_manager import COOKIE_NAME_JWT_TOKEN as COOKIE_NAME_JWT_TOKEN
    from airflow.api_fastapi.core_api.security import get_user as get_user
    from airflow.plugins_manager import AirflowPlugin as AirflowPlugin
except ImportError as exc:
    raise RuntimeError('Airflow Runtime Report requires the Airflow 3.1 FastAPI plug-in surface') from exc
import threading
from dataclasses import dataclass, field

@dataclass(frozen=True, slots=True)
class _RequestAccessContext:
    credential: object | None
    cache_partition: str
    repository_scope: str
    authorization_identity: str

@dataclass(frozen=True, slots=True)
class _LiveCacheEntry:
    payload: bytes
    etag: str
    created: float
    repository_identity: tuple[int, int, int, int] = EMPTY_REPOSITORY_IDENTITY
    repository_scope: str = ''

@dataclass(frozen=True, slots=True)
class _LiveRenderedPayload:
    payload: bytes
    repository_identity: tuple[int, int, int, int]
    repository_scope: str

@dataclass(slots=True)
class _LiveFlight:
    repository_scope: str
    completed: threading.Event = field(default_factory=threading.Event)
    entry: _LiveCacheEntry | None = None
    failure_type: str = ''

@dataclass(frozen=True, slots=True)
class _LiveRepositorySample:
    identity: tuple[int, int, int, int]
    checked_at: float

@dataclass(frozen=True, slots=True)
class _LiveCachePolicy:
    ttl: int
    max_entries: int
    max_bytes: int
    wait_seconds: int
    generation_check_seconds: float

@dataclass(frozen=True, slots=True)
class _RequestApiCredential:
    base_url: str
    bearer_token: str
    source: str

@dataclass(frozen=True, slots=True)
class _RuntimeFailureDiagnosis:
    detail: str
    operator_message: str
    category: str
    http_status: int = 503
    retryable: bool = False
    suggested_action: str = 'Inspect the API-server log using the diagnostic reference and retry after correcting the reported condition.'

class _LiveFilterError(ValueError):

    def __init__(self, message: str, fields: tuple[str, ...]=()) -> None:
        super().__init__(message)
        self.fields = fields

class _LiveAuthenticationError(RuntimeError):
    pass
import os

def _bounded_env_int(name: str, default: int, minimum: int, maximum: int) -> int:
    raw = os.getenv(f'AIRFLOW_REPORT__{name}')
    try:
        value = default if raw in (None, '') else int(str(raw))
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f'invalid AIRFLOW_REPORT__{name}') from exc
    if value < minimum or value > maximum:
        raise RuntimeError(f'AIRFLOW_REPORT__{name} must be between {minimum} and {maximum}')
    return value

def _plugin_mode() -> str:
    value = os.getenv('AIRFLOW_REPORT__PLUGIN_MODE', 'materialized').strip().lower()
    if value not in {'materialized', 'static', 'hybrid'}:
        raise RuntimeError('AIRFLOW_REPORT__PLUGIN_MODE must be materialized, static, or hybrid')
    return value

def _live_auth_source() -> str:
    value = os.getenv('AIRFLOW_REPORT__LIVE_AUTH_SOURCE', 'request').strip().lower()
    if value not in {'request', 'connection'}:
        raise RuntimeError('AIRFLOW_REPORT__LIVE_AUTH_SOURCE must be request or connection')
    return value

def _live_auth_cookie_name() -> str:
    value = os.getenv('AIRFLOW_REPORT__LIVE_AUTH_COOKIE_NAME', COOKIE_NAME_JWT_TOKEN).strip()
    if not value or len(value) > 128:
        raise RuntimeError('AIRFLOW_REPORT__LIVE_AUTH_COOKIE_NAME is invalid')
    if any((not (char.isalnum() or char in {'_', '-'}) for char in value)):
        raise RuntimeError('AIRFLOW_REPORT__LIVE_AUTH_COOKIE_NAME is invalid')
    return value

def _validated_bearer_token(value: object, source: str) -> str:
    token = str(value or '').strip()
    if not token or len(token) > 65536:
        raise _LiveAuthenticationError(f'{source} bearer token is unavailable')
    if any((char.isspace() or ord(char) < 32 or ord(char) == 127 for char in token)):
        raise _LiveAuthenticationError(f'{source} bearer token is malformed')
    return token
import re
import stat
from collections.abc import Iterator
from pathlib import Path
from urllib.parse import urlsplit
from airflow.configuration import conf

def _absolute_path_without_resolving(path: Path, label: str) -> Path:
    if any((component in {'.', '..'} for component in path.parts)):
        raise RuntimeError(f'{label} contains a traversal component')
    expanded = path.expanduser()
    if any((component in {'.', '..'} for component in expanded.parts)):
        raise RuntimeError(f'{label} contains a traversal component')
    candidate = expanded if expanded.is_absolute() else Path.cwd() / expanded
    normalized = Path(os.path.abspath(os.fspath(candidate)))
    return normalized

def _open_trusted_directory(path: Path) -> int:
    absolute = _absolute_path_without_resolving(path, 'report directory')
    flags = os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0) | getattr(os, 'O_CLOEXEC', 0)
    nofollow = getattr(os, 'O_NOFOLLOW', 0)
    descriptor: int | None = None
    keep_open = False
    try:
        descriptor = os.open('/', flags)
        for component in absolute.parts[1:]:
            if component in {'', '.', '..'}:
                raise RuntimeError('report directory contains an invalid component')
            metadata = os.stat(component, dir_fd=descriptor, follow_symlinks=False)
            if stat.S_ISLNK(metadata.st_mode):
                raise RuntimeError('report directory contains a symbolic-link component')
            if not stat.S_ISDIR(metadata.st_mode):
                raise RuntimeError('report directory component is not a directory')
            next_descriptor: int | None = None
            try:
                next_descriptor = os.open(component, flags | nofollow, dir_fd=descriptor)
                opened = os.fstat(next_descriptor)
                if not stat.S_ISDIR(opened.st_mode) or opened.st_dev != metadata.st_dev or opened.st_ino != metadata.st_ino:
                    raise RuntimeError('report directory component changed while being opened')
            except (OSError, RuntimeError):
                if next_descriptor is not None:
                    os.close(next_descriptor)
                raise
            os.close(descriptor)
            descriptor = next_descriptor
        keep_open = True
        return descriptor
    finally:
        if descriptor is not None and (not keep_open):
            os.close(descriptor)

def _base_log_folder() -> Path:
    fallback = Path(os.getenv('AIRFLOW_HOME', '~/airflow')).expanduser() / 'logs'
    configured = conf.get('logging', 'base_log_folder', fallback=str(fallback))
    return _absolute_path_without_resolving(Path(str(configured)), 'base log folder')
_AUTHORIZATION_SCOPE_RE = re.compile('^auth-[a-f0-9]{24}$')

def _materialized_repository_identity(repository_scope: str) -> tuple[int, int, int, int]:
    if _AUTHORIZATION_SCOPE_RE.fullmatch(repository_scope) is None:
        raise RuntimeError('materialized repository scope is invalid')
    scope_path = _base_log_folder() / 'report' / 'json' / repository_scope
    try:
        directory_fd = _open_trusted_directory(scope_path)
    except FileNotFoundError:
        return EMPTY_REPOSITORY_IDENTITY
    except OSError as exc:
        raise RuntimeError('materialized repository directory cannot be inspected') from exc
    try:
        metadata = os.stat(REPOSITORY_GENERATION_FILENAME, dir_fd=directory_fd, follow_symlinks=False)
    except FileNotFoundError:
        return EMPTY_REPOSITORY_IDENTITY
    except OSError as exc:
        raise RuntimeError('materialized repository generation marker cannot be inspected') from exc
    finally:
        os.close(directory_fd)
    if not stat.S_ISREG(metadata.st_mode) or not 0 < metadata.st_size <= 32:
        raise RuntimeError('materialized repository generation marker is invalid')
    return (metadata.st_dev, metadata.st_ino, metadata.st_size, metadata.st_mtime_ns)

def _current_report_path() -> Path:
    return _base_log_folder() / 'report' / CURRENT_REPORT_FILENAME

def _external_view_href() -> str:
    base_url = conf.get('api', 'base_url', fallback='')
    base_path = urlsplit(str(base_url)).path.rstrip('/')
    return f'{base_path}{PLUGIN_URL_PREFIX}/'

def _open_current_report() -> tuple[int, int, tuple[int, int, int, int]]:
    report_path = _current_report_path()
    directory_fd = _open_trusted_directory(report_path.parent)
    descriptor: int | None = None
    try:
        flags = os.O_RDONLY | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0)
        descriptor = os.open(report_path.name, flags, dir_fd=directory_fd)
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode):
            raise RuntimeError('current report is not a regular file')
        if metadata.st_size <= 0:
            raise RuntimeError('current report is empty')
        if metadata.st_size > MAX_REPORT_BYTES:
            raise RuntimeError('current report exceeds the 128 MiB hard limit')
        identity = (metadata.st_dev, metadata.st_ino, metadata.st_size, metadata.st_mtime_ns)
        opened_descriptor = descriptor
        descriptor = None
        return (opened_descriptor, metadata.st_size, identity)
    finally:
        if descriptor is not None:
            os.close(descriptor)
        os.close(directory_fd)

def _stream_descriptor(descriptor: int, expected_size: int, expected_identity: tuple[int, int, int, int]) -> Iterator[bytes]:
    remaining = expected_size
    try:
        while remaining:
            chunk = os.read(descriptor, min(STREAM_CHUNK_BYTES, remaining))
            if not chunk:
                raise RuntimeError('current report ended before its declared size')
            remaining -= len(chunk)
            yield chunk
        if os.read(descriptor, 1):
            raise RuntimeError('current report grew while it was being served')
        final = os.fstat(descriptor)
        final_identity = (final.st_dev, final.st_ino, final.st_size, final.st_mtime_ns)
        if final_identity != expected_identity:
            raise RuntimeError('current report changed while it was being served')
    finally:
        os.close(descriptor)

def _read_current_report_payload() -> bytes:
    descriptor, size, identity = _open_current_report()
    return b''.join(_stream_descriptor(descriptor, size, identity))
import hashlib
from collections.abc import Mapping
from fastapi import Request

def _request_bearer_token(request: Request) -> tuple[str | None, str]:
    authorization = str(request.headers.get('authorization') or '').strip()
    if authorization:
        scheme, separator, value = authorization.partition(' ')
        if scheme.casefold() != 'bearer' or not separator:
            raise _LiveAuthenticationError('the request Authorization header is not a Bearer credential')
        return (_validated_bearer_token(value, 'request Authorization'), 'authorization')
    cookie_name = _live_auth_cookie_name()
    cookie = request.cookies.get(cookie_name)
    if cookie:
        return (_validated_bearer_token(cookie, 'Airflow JWT cookie'), 'cookie')
    return (None, 'none')

def _request_api_base_url(_request: Request) -> str:
    configured = str(conf.get('api', 'base_url', fallback='') or '').strip()
    if not configured:
        raise _LiveAuthenticationError('Airflow [api] base_url is required for request credential forwarding')
    return configured

def _request_ui_base_path(request: Request) -> str:
    configured = str(conf.get('api', 'base_url', fallback='') or '').strip()
    if configured:
        return urlsplit(configured).path.rstrip('/')
    root_path = str(request.scope.get('root_path') or '').rstrip('/')
    if root_path.endswith(PLUGIN_URL_PREFIX):
        root_path = root_path[:-len(PLUGIN_URL_PREFIX)].rstrip('/')
    return root_path

def _request_api_credential(request: Request) -> tuple[object | None, str]:
    source = _live_auth_source()
    if source == 'connection':
        return (None, 'connection')
    token, token_source = _request_bearer_token(request)
    if token is None:
        raise _LiveAuthenticationError('the authenticated request does not contain a transferable Airflow JWT')
    base_url = _request_api_base_url(request)
    credential = _RequestApiCredential(base_url=base_url, bearer_token=token, source=f'request-{token_source}')
    fingerprint = hashlib.sha256(token.encode('utf-8')).hexdigest()[:24]
    return (credential, f'request:{fingerprint}')

def _principal_key(user: object) -> str:
    if isinstance(user, Mapping):
        values = ((key, user.get(key)) for key in ('username', 'id', 'email', 'name'))
    else:
        values = ((key, getattr(user, key, None)) for key in ('username', 'id', 'email', 'name'))
    identity = next((f'{key}={str(value).strip()}' for key, value in values if str(value or '').strip()), '')
    if not identity:
        raise _LiveAuthenticationError('the authenticated user does not expose a stable identity')
    return hashlib.sha256(identity.encode('utf-8')).hexdigest()[:24]

def _request_access_context(request: Request, principal: str) -> _RequestAccessContext:
    credential, cache_partition = _request_api_credential(request)
    if cache_partition == 'connection':
        scope_material = 'connection'
        authorization_material = 'connection'
    else:
        source = cache_partition.split(':', 1)[0]
        scope_material = f'{principal}:{source}'
        authorization_material = f'{principal}:{cache_partition}'
    repository_scope = 'auth-' + hashlib.sha256(scope_material.encode('utf-8')).hexdigest()[:24]
    authorization_identity = hashlib.sha256(authorization_material.encode('utf-8')).hexdigest()
    return _RequestAccessContext(credential=credential, cache_partition=cache_partition, repository_scope=repository_scope, authorization_identity=authorization_identity)
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

def _strict_iso_date(value: str, label: str, field: str) -> date:
    try:
        parsed = date.fromisoformat(value)
    except ValueError as exc:
        raise _LiveFilterError(f'{label} must be YYYY-MM-DD', (field,)) from exc
    if parsed.isoformat() != value:
        raise _LiveFilterError(f'{label} must be YYYY-MM-DD', (field,))
    return parsed

def _live_timezone(value: str | None) -> tuple[str, date]:
    timezone_value = str(value or 'Europe/Prague').strip()
    try:
        zone = ZoneInfo(timezone_value)
    except (ValueError, ZoneInfoNotFoundError) as exc:
        raise _LiveFilterError('timezone is invalid', ('liveFilterTimezone',)) from exc
    return (timezone_value, datetime.now(zone).date())

def _live_day_count(days_text: str, start_value: str, end_value: str) -> int:
    if days_text and (start_value or end_value):
        raise _LiveFilterError('Use Report days or Start/End dates, not both', ('liveFilterStart', 'liveFilterEnd', 'liveFilterReportDays'))
    if not days_text:
        return DEFAULT_LIVE_REPORT_DAYS if not start_value and (not end_value) else 0
    try:
        day_count = int(days_text)
    except ValueError as exc:
        raise _LiveFilterError('Report days must be an integer from 1 to 10', ('liveFilterReportDays',)) from exc
    if day_count < 1 or day_count > 10:
        raise _LiveFilterError('Report days must be between 1 and 10', ('liveFilterReportDays',))
    return day_count

def _live_history_window(start_value: str, end_value: str, day_count: int, today: date) -> tuple[str, str]:
    if day_count:
        start_value = (today - timedelta(days=day_count - 1)).isoformat()
        end_value = today.isoformat()
    if bool(start_value) != bool(end_value):
        raise _LiveFilterError('Start and End dates must be provided together', ('liveFilterEnd',) if start_value else ('liveFilterStart',))
    if not start_value:
        return (start_value, end_value)
    parsed_start = _strict_iso_date(start_value, 'Start date', 'liveFilterStart')
    parsed_end = _strict_iso_date(end_value, 'End date', 'liveFilterEnd')
    if parsed_start > parsed_end:
        raise _LiveFilterError('Start date must not follow End date', ('liveFilterStart', 'liveFilterEnd'))
    if (parsed_end - parsed_start).days + 1 > 10:
        raise _LiveFilterError('History range must not exceed 10 calendar days', ('liveFilterStart', 'liveFilterEnd'))
    if parsed_end > today:
        raise _LiveFilterError('End date must not be in the future', ('liveFilterEnd',))
    if parsed_start < today - timedelta(days=9):
        raise _LiveFilterError('History must stay within the latest 10 calendar days', ('liveFilterStart', 'liveFilterEnd'))
    return (start_value, end_value)

def _live_future_value(value: str | None, today: date) -> str:
    future_value = str(value or '').strip()
    if not future_value:
        return ''
    parsed_future = _strict_iso_date(future_value, 'Future projection end date', 'liveFilterFutureEnd')
    if parsed_future < today:
        raise _LiveFilterError('Future projection end date must include today or later', ('liveFilterFutureEnd',))
    if (parsed_future - today).days > 9:
        raise _LiveFilterError('Future projection must not exceed 10 calendar days', ('liveFilterFutureEnd',))
    return future_value

def _live_requested_future_value(value: str | None, today: date, default_view: bool) -> str:
    if default_view:
        return (today + timedelta(days=DEFAULT_LIVE_FUTURE_DAYS)).isoformat()
    return _live_future_value(value, today)

def _is_default_live_view(start_value: str, end_value: str, days_text: str, future_end: str | None) -> bool:
    return not any((start_value, end_value, days_text, str(future_end or '').strip()))

def _live_values(start: str | None, end: str | None, report_days: str | None, future_end: str | None, timezone: str | None) -> dict[str, object]:
    timezone_value, today = _live_timezone(timezone)
    start_value = str(start or '').strip()
    end_value = str(end or '').strip()
    days_text = str(report_days or '').strip()
    default_view = _is_default_live_view(start_value, end_value, days_text, future_end)
    day_count = _live_day_count(days_text, start_value, end_value)
    start_value, end_value = _live_history_window(start_value, end_value, day_count, today)
    future_value = _live_requested_future_value(future_end, today, default_view)
    values: dict[str, object] = {'_run_id': 'materialized', '_task_instance_key': 'airflow-runtime-report-ui', 'start': start_value, 'end': end_value, 'timezone': timezone_value, '_live_report_days': day_count}
    if future_value:
        values['future_end'] = future_value
    return values

def _live_cache_key(principal: str, values: Mapping[str, object], auth_partition: str, airflow_ui_base_path: str='') -> str:
    material = '\n'.join((f'{key}={values[key]}' for key in sorted(values)))
    material = f'{material}\nairflow_ui_base_path={airflow_ui_base_path}'
    digest = hashlib.sha256(material.encode('utf-8')).hexdigest()
    return f'{principal}:{auth_partition}:{digest}'
from collections.abc import Callable, Mapping
from dataclasses import replace
from typing import TYPE_CHECKING, cast
if TYPE_CHECKING:
    from airflow_report.api import RequestApiCredential

def _require_plugin_renderer_sha256(actual_sha256: str) -> None:
    if actual_sha256 != PLUGIN_EXPECTED_RENDERER_SHA256:
        raise RuntimeError(f'plugin/renderer release mismatch plugin_expected={PLUGIN_EXPECTED_RENDERER_SHA256} renderer_actual={actual_sha256}')

def _render_live_payload(values: Mapping[str, object], request_api_credential: object | None, *, repository_scope: str, authorization_identity: str, airflow_ui_base_path: str='', force_reinitialize: bool=False, filter_feedback: Mapping[str, object] | None=None, progress_callback: Callable[[str, str, Mapping[str, object] | None], None] | None=None) -> _LiveRenderedPayload:
    from airflow_report import materialized_service as report_service
    from airflow_report.configuration import parse_config
    from airflow_report.configuration_security import redact_secret_text, sha256_file
    from airflow_report.materialized import ensure_materialized_dataset
    from airflow_report.preamble import AirflowFailException
    from airflow_report.renderer_runtime import load_renderer, render_html

    def notify(stage: str, message: str, counter: Mapping[str, object] | None=None) -> None:
        if progress_callback is not None:
            progress_callback(stage, message, counter)
    renderer_path = Path(__file__).with_name(RENDERER_FILENAME)
    try:
        parsed_config = parse_config(values)
    except AirflowFailException as exc:
        raise _LiveFilterError(redact_secret_text(exc, 300)) from exc
    live_html_limit = _bounded_env_int('LIVE_MAX_HTML_BYTES', 25000000, 1000000, MAX_REPORT_BYTES)
    config = replace(parsed_config, renderer_path=renderer_path, email_to=(), max_html_bytes=min(parsed_config.max_html_bytes, live_html_limit))
    renderer = load_renderer(renderer_path)
    _require_plugin_renderer_sha256(renderer.sha256)
    notify('LOADING_DATA', 'Loading authorized DAG and runtime data...')
    dataset = ensure_materialized_dataset(config, _base_log_folder() / 'report' / 'json', cast('RequestApiCredential | None', request_api_credential), repository_scope=repository_scope, authorization_identity=authorization_identity, force_reinitialize=force_reinitialize)
    notify('BUILDING_REPORT', 'Building the report visualization...')
    report = report_service.build_materialized_report(config, dataset, renderer, sha256_file(Path(report_service.__file__)), airflow_ui_base_path=airflow_ui_base_path)
    if filter_feedback:
        report = replace(report, materialized_coverage={**dict(report.materialized_coverage), **dict(filter_feedback)})
    notify('FINALIZING', 'Finalizing tables, timeline, and interaction indexes...')
    payload = render_html(report, renderer).encode('utf-8')
    if not payload or len(payload) > min(MAX_REPORT_BYTES, config.max_html_bytes):
        raise RuntimeError('materialized report exceeded its validated HTML byte budget')
    return _LiveRenderedPayload(payload, dataset.repository_identity, repository_scope)
import time
from collections import OrderedDict
_LIVE_CACHE: OrderedDict[str, _LiveCacheEntry] = OrderedDict()
_LIVE_INFLIGHT: dict[str, _LiveFlight] = {}
_LIVE_LOCK = threading.RLock()
_LIVE_SCOPE_EPOCHS: dict[str, int] = {}
_LIVE_REPOSITORY_SAMPLES: dict[str, _LiveRepositorySample] = {}
_LIVE_BUILD_SEMAPHORE = threading.BoundedSemaphore(_bounded_env_int('LIVE_BUILD_CONCURRENCY', 2, 1, 8))
_LIVE_MAX_INFLIGHT = _bounded_env_int('LIVE_INFLIGHT_REQUESTS', 32, 1, 256)
_LIVE_GENERATION_CHECK_SECONDS = _bounded_env_int('LIVE_GENERATION_CHECK_MILLISECONDS', 10, 0, 1000) / 1000.0

def _prune_live_scope_state_locked() -> None:
    active = {entry.repository_scope for entry in _LIVE_CACHE.values()}
    active.update((flight.repository_scope for flight in _LIVE_INFLIGHT.values()))
    for scope in tuple(_LIVE_SCOPE_EPOCHS):
        if scope not in active:
            _LIVE_SCOPE_EPOCHS.pop(scope, None)
            _LIVE_REPOSITORY_SAMPLES.pop(scope, None)

def _purge_live_cache(now: float, ttl: int, max_entries: int, max_bytes: int) -> None:
    for key in tuple(_LIVE_CACHE):
        if now - _LIVE_CACHE[key].created > ttl:
            _LIVE_CACHE.pop(key, None)
    total = sum((len(entry.payload) for entry in _LIVE_CACHE.values()))
    while _LIVE_CACHE and (len(_LIVE_CACHE) > max_entries or total > max_bytes):
        _, removed = _LIVE_CACHE.popitem(last=False)
        total -= len(removed.payload)
    _prune_live_scope_state_locked()

def _invalidate_live_scope_locked(repository_scope: str) -> int:
    for key in tuple(_LIVE_CACHE):
        if _LIVE_CACHE[key].repository_scope == repository_scope:
            _LIVE_CACHE.pop(key, None)
    epoch = _LIVE_SCOPE_EPOCHS.get(repository_scope, 0) + 1
    _LIVE_SCOPE_EPOCHS[repository_scope] = epoch
    _LIVE_REPOSITORY_SAMPLES.pop(repository_scope, None)
    return epoch

def _sample_repository_identity_locked(repository_scope: str, now: float, interval_seconds: float, *, force: bool=False) -> tuple[int, int, int, int]:
    sample = _LIVE_REPOSITORY_SAMPLES.get(repository_scope)
    if force or sample is None or now - sample.checked_at >= interval_seconds:
        sample = _LiveRepositorySample(_materialized_repository_identity(repository_scope), now)
        _LIVE_REPOSITORY_SAMPLES[repository_scope] = sample
    return sample.identity

def _await_live_flight(flight: _LiveFlight | None, wait_seconds: int) -> tuple[_LiveCacheEntry, str]:
    if flight is None:
        raise RuntimeError('materialized report single-flight state is inconsistent')
    if not flight.completed.wait(wait_seconds):
        raise RuntimeError('materialized report generation wait timed out')
    if flight.failure_type:
        raise RuntimeError(f'materialized report coalesced build failed ({flight.failure_type})')
    if flight.entry is None:
        raise RuntimeError('materialized report generation did not publish a flight result')
    return (flight.entry, 'COALESCED')

def _rendered_payload_parts(rendered: object, repository_scope: str) -> tuple[bytes, tuple[int, int, int, int], str]:
    if isinstance(rendered, _LiveRenderedPayload):
        if rendered.repository_scope != repository_scope:
            raise RuntimeError('materialized renderer returned a mismatched repository scope')
        return (rendered.payload, rendered.repository_identity, rendered.repository_scope)
    if isinstance(rendered, bytes):
        return (rendered, _materialized_repository_identity(repository_scope), repository_scope)
    raise RuntimeError('materialized renderer returned a non-byte payload')

def _publish_live_entry(key: str, entry: _LiveCacheEntry, flight: _LiveFlight, build_epoch: int, force_reinitialize: bool, policy: _LiveCachePolicy) -> str:
    with _LIVE_LOCK:
        repository_current = entry.repository_identity == _sample_repository_identity_locked(entry.repository_scope, time.monotonic(), policy.generation_check_seconds, force=True)
        if force_reinitialize:
            cacheable = repository_current
            if cacheable:
                _invalidate_live_scope_locked(entry.repository_scope)
            cache_status = 'REINITIALIZED' if cacheable else 'REINIT-INVALIDATED'
        else:
            cacheable = build_epoch == _LIVE_SCOPE_EPOCHS.get(entry.repository_scope, 0) and repository_current
            cache_status = 'MISS' if cacheable else 'MISS-INVALIDATED'
        if cacheable:
            _LIVE_CACHE[key] = entry
            _LIVE_CACHE.move_to_end(key)
            _purge_live_cache(time.monotonic(), policy.ttl, policy.max_entries, policy.max_bytes)
        flight.entry = entry
        return cache_status

def _complete_live_flight(flight_key: str, flight: _LiveFlight) -> None:
    with _LIVE_LOCK:
        if _LIVE_INFLIGHT.get(flight_key) is flight:
            _LIVE_INFLIGHT.pop(flight_key, None)
        flight.completed.set()
        _prune_live_scope_state_locked()

def _coordinate_live_request(key: str, repository_scope: str, force_reinitialize: bool, policy: _LiveCachePolicy) -> tuple[_LiveCacheEntry | None, _LiveFlight | None, bool, int, str]:
    now = time.monotonic()
    flight_key = f'{key}:reinit' if force_reinitialize else key
    with _LIVE_LOCK:
        _purge_live_cache(now, policy.ttl, policy.max_entries, policy.max_bytes)
        cached = None if force_reinitialize else _LIVE_CACHE.get(key)
        if cached is not None:
            if cached.repository_scope != repository_scope:
                _LIVE_CACHE.pop(key, None)
                raise RuntimeError('materialized cache scope is inconsistent')
            sampled_identity = _sample_repository_identity_locked(repository_scope, now, policy.generation_check_seconds, force=policy.generation_check_seconds == 0)
            if cached.repository_identity == sampled_identity:
                _LIVE_CACHE.move_to_end(key)
                return (cached, None, False, 0, flight_key)
            _LIVE_CACHE.pop(key, None)
        flight = _LIVE_INFLIGHT.get(flight_key)
        if flight is None:
            if len(_LIVE_INFLIGHT) >= _LIVE_MAX_INFLIGHT:
                raise RuntimeError('materialized report in-flight request capacity is exhausted')
            owner = True
            if force_reinitialize:
                _invalidate_live_scope_locked(repository_scope)
            flight = _LiveFlight(repository_scope)
            _LIVE_INFLIGHT[flight_key] = flight
        else:
            owner = False
            if flight.repository_scope != repository_scope:
                raise RuntimeError('materialized single-flight scope is inconsistent')
        return (None, flight, owner, _LIVE_SCOPE_EPOCHS.get(repository_scope, 0), flight_key)

def _build_live_entry(key: str, values: Mapping[str, object], request_api_credential: object | None, repository_scope: str, authorization_identity: str, airflow_ui_base_path: str, force_reinitialize: bool, policy: _LiveCachePolicy, flight_key: str, flight: _LiveFlight, build_epoch: int, progress_callback: Callable[[str, str, Mapping[str, object] | None], None] | None) -> tuple[_LiveCacheEntry, str]:
    acquired = False
    try:
        if progress_callback is not None:
            progress_callback('WAITING_FOR_BUILD', 'Waiting for available report build capacity...', None)
        acquired = _LIVE_BUILD_SEMAPHORE.acquire(timeout=policy.wait_seconds)
        if not acquired:
            raise RuntimeError('materialized report build concurrency wait timed out')
        render_kwargs: dict[str, object] = {'repository_scope': repository_scope, 'authorization_identity': authorization_identity, 'airflow_ui_base_path': airflow_ui_base_path, 'force_reinitialize': force_reinitialize}
        if progress_callback is not None:
            render_kwargs['progress_callback'] = progress_callback
        rendered = _render_live_payload(values, request_api_credential, **render_kwargs)
        payload, repository_identity, rendered_scope = _rendered_payload_parts(rendered, repository_scope)
        if len(payload) > policy.max_bytes:
            raise RuntimeError('materialized report exceeds AIRFLOW_REPORT__LIVE_CACHE_BYTES')
        digest = hashlib.sha256(payload).hexdigest()
        entry = _LiveCacheEntry(payload, f'"{digest}"', time.monotonic(), repository_identity, rendered_scope)
        status = _publish_live_entry(key, entry, flight, build_epoch, force_reinitialize, policy)
        return (entry, status)
    except Exception as exc:
        with _LIVE_LOCK:
            flight.failure_type = type(exc).__name__
        raise
    finally:
        if acquired:
            _LIVE_BUILD_SEMAPHORE.release()
        _complete_live_flight(flight_key, flight)

def _cached_live_payload(key: str, values: Mapping[str, object], request_api_credential: object | None, *, repository_scope: str, authorization_identity: str, airflow_ui_base_path: str='', force_reinitialize: bool=False, progress_callback: Callable[[str, str, Mapping[str, object] | None], None] | None=None) -> tuple[_LiveCacheEntry, str]:
    policy = _LiveCachePolicy(ttl=_bounded_env_int('LIVE_CACHE_TTL_SECONDS', 30, 1, 3600), max_entries=_bounded_env_int('LIVE_CACHE_ENTRIES', 8, 1, 64), max_bytes=_bounded_env_int('LIVE_CACHE_BYTES', 64 * 1024 * 1024, 1000000, 512 * 1024 * 1024), wait_seconds=_bounded_env_int('LIVE_BUILD_WAIT_SECONDS', 120, 1, 900), generation_check_seconds=_LIVE_GENERATION_CHECK_SECONDS)
    cached, flight, owner, build_epoch, flight_key = _coordinate_live_request(key, repository_scope, force_reinitialize, policy)
    if cached is not None:
        return (cached, 'HIT')
    if flight is None:
        raise RuntimeError('materialized report single-flight state is inconsistent')
    if not owner:
        if progress_callback is not None:
            progress_callback('WAITING_FOR_BUILD', 'Another report request is already being prepared. Waiting for the shared result...', None)
        return _await_live_flight(flight, policy.wait_seconds)
    return _build_live_entry(key, values, request_api_credential, repository_scope, authorization_identity, airflow_ui_base_path, force_reinitialize, policy, flight_key, flight, build_epoch, progress_callback)
import secrets
_DEFAULT_OPERATOR_MESSAGE = 'Incremental materialized collection failed; inspect the API-server log for the diagnostic reference.'
_DEFAULT_ACTION = 'Inspect the API-server log using the diagnostic reference and retry after correcting the reported condition.'

def _diagnostic_reference() -> str:
    return secrets.token_hex(6).upper()

def _redact_plugin_failure(value: object, limit: int=320) -> str:
    text = re.sub('\\s+', ' ', str(value or '')).strip()
    key = '(?:password|passwd|pwd|passphrase|secret|client[_-]?secret|access[_-]?token|refresh[_-]?token|bearer[_-]?token|session[_-]?token|id[_-]?token|api[_-]?key|secret[_-]?key|private[_-]?key|token)'
    bounded_key = f'(?<![A-Za-z0-9_-]){key}(?![A-Za-z0-9_-])'
    text = re.sub(f"""(?i)({bounded_key}\\s*[:=]\\s*)[^\\s,;}}\\]&\\"']+""", '\\1<redacted>', text)
    text = re.sub('(?i)((?<![A-Za-z0-9_-])(?:proxy-)?authorization(?![A-Za-z0-9_-])\\s*[:=]\\s*(?:bearer|basic)\\s+)[^\\s,;}&]+', '\\1<redacted>', text)
    text = re.sub(f'(?i)([?&]{key}(?![A-Za-z0-9_-])=)[^&\\s]+', '\\1<redacted>', text)
    text = re.sub('(?i)([a-z][a-z0-9+.-]*://[^/\\s:@]+:)[^@/\\s]+(@)', '\\1<redacted>\\2', text)
    return (text or type(value).__name__)[:limit]

def _diagnosis(detail: str, operator_message: str, category: str, http_status: int, retryable: bool, suggested_action: str) -> _RuntimeFailureDiagnosis:
    return _RuntimeFailureDiagnosis(detail=detail, operator_message=operator_message, category=category, http_status=http_status, retryable=retryable, suggested_action=suggested_action)

def _exception_status(exc: Exception) -> int | None:
    raw_status = getattr(exc, 'status', getattr(exc, 'status_code', None))
    try:
        return int(raw_status) if raw_status is not None else None
    except (TypeError, ValueError):
        return None

def _status_diagnosis(exc: Exception, detail: str, status_code: int | None) -> _RuntimeFailureDiagnosis | None:
    if isinstance(exc, _LiveFilterError) or status_code == 400:
        return _diagnosis(detail, f'Invalid report filters: {detail}', 'configuration', 400, False, 'Correct the highlighted report filter values and retry.')
    if isinstance(exc, _LiveAuthenticationError):
        return _diagnosis(detail, 'Your Airflow session could not provide the configured report API credential.', 'authentication', 401, False, 'Refresh your Airflow login and verify the configured report authentication mode.')
    status_specs = {401: ('Airflow REST API authentication was rejected with HTTP 401. The current report credential is missing, expired, or not accepted.', 'api-authentication', False, 'Refresh the Airflow session or correct the report collector credential.'), 403: ('Airflow REST API authorization was rejected with HTTP 403. The current identity cannot read all required report resources.', 'api-authorization', False, 'Grant the expected DAG and DAG-run read permissions to this Airflow role.'), 429: ('The Airflow REST API temporarily rate-limited report collection.', 'airflow-api', True, 'Wait briefly and retry; inspect API rate limits if the condition repeats.')}
    if status_code in status_specs:
        message, category, retryable, action = status_specs[status_code]
        return _diagnosis(detail, message, category, int(status_code), retryable, action)
    if status_code in {502, 503, 504}:
        return _diagnosis(detail, f'The Airflow REST API is temporarily unavailable with HTTP {status_code}.', 'airflow-api', int(status_code), True, 'Check API-server health and retry after the service is available.')
    return None

def _timeout_diagnosis(detail: str, lowered: str) -> _RuntimeFailureDiagnosis:
    concurrency_tokens = ('build', 'single-flight', 'in-flight', 'wait')
    category = 'concurrency' if any((token in lowered for token in concurrency_tokens)) else 'airflow-api'
    return _diagnosis(detail, 'Report initialization reached a temporary service or concurrency timeout.', category, 503, True, 'Retry once; inspect API-server capacity and timeout relationships if it repeats.')

def _text_diagnosis(exc: Exception, detail: str, lowered: str) -> _RuntimeFailureDiagnosis | None:
    if isinstance(exc, PermissionError) or 'permission denied' in lowered:
        return _diagnosis(detail, 'The report repository cannot be accessed with the required permissions.', 'permissions', 503, False, 'Correct repository ownership, mode bits, and SELinux policy, then retry.')
    filesystem_scope_tokens = ('directory access failed', 'authorization scope access failed', 'timezone scope access failed', 'report output directory access failed', 'component mode verification failed')
    if any((token in lowered for token in filesystem_scope_tokens)):
        return _diagnosis(detail, 'The report repository could not be initialized safely.', 'repository', 503, False, 'Verify filesystem capabilities, ownership, mode bits, and SELinux policy, then retry.')
    if 'certificate verification failed' in lowered or ('ssl' in lowered and 'certificate' in lowered):
        return _diagnosis(detail, 'HTTPS certificate verification failed while contacting the Airflow API.', 'tls-verification', 503, False, 'Configure the approved CA bundle and verify the Airflow API certificate chain.')
    if 'connection' in lowered and 'not found' in lowered:
        return _diagnosis(detail, 'No transferable request JWT was available and the configured airflow_api connection was not found.', 'api-connection', 503, False, 'Create the airflow_api connection or enable valid request-JWT forwarding.')
    timeout_tokens = ('connection refused', 'temporarily unavailable', 'connection reset', 'timed out', 'timeout')
    if any((token in lowered for token in timeout_tokens)):
        return _timeout_diagnosis(detail, lowered)
    if any((token in lowered for token in ('renderer', 'render', 'html byte budget'))):
        return _diagnosis(detail, 'The report renderer could not produce a validated report document.', 'rendering', 503, False, 'Verify the deployed renderer hash and inspect the referenced server-side rendering failure.')
    if isinstance(exc, FileNotFoundError) or any((token in lowered for token in ('missing', 'repository'))):
        return _diagnosis(detail, 'A required report renderer, support package, or repository resource is unavailable.', 'repository', 503, False, 'Verify the plug-in deployment and writable report repository paths.')
    return None

def _runtime_failure_diagnosis(exc: Exception) -> _RuntimeFailureDiagnosis:
    detail = _redact_plugin_failure(exc)
    status_diagnosis = _status_diagnosis(exc, detail, _exception_status(exc))
    if status_diagnosis is not None:
        return status_diagnosis
    text_diagnosis = _text_diagnosis(exc, detail, detail.casefold())
    if text_diagnosis is not None:
        return text_diagnosis
    return _diagnosis(detail, _DEFAULT_OPERATOR_MESSAGE, 'runtime', 503, False, _DEFAULT_ACTION)
import html
import json
from starlette.responses import HTMLResponse

def _json_for_inline_script(value: object) -> str:
    return json.dumps(value, ensure_ascii=True, separators=(',', ':')).replace('&', '\\u0026').replace('<', '\\u003c').replace('>', '\\u003e').replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')
_BOOTSTRAP_DOCUMENT = '<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1">\n<title>Opening Airflow Runtime Report</title>\n<style>\n:root{font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color-scheme:light}\n*{box-sizing:border-box}\nbody{margin:0;min-height:100vh;background:#f7f8fa;color:#172033;display:grid;place-items:center;padding:24px}\nmain{width:min(720px,100%);background:#fff;border:1px solid #cfd7e3;border-radius:8px;box-shadow:0 8px 28px rgba(15,23,42,.08);padding:28px}\n.header{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:22px}\nh1{font-size:22px;line-height:1.25;margin:0 0 5px}\n.release{font:600 11px/1.4 ui-monospace,SFMono-Regular,Consolas,monospace;color:#52627a;white-space:nowrap}\n.progress-track{height:4px;background:#e6ebf2;overflow:hidden;border-radius:999px;margin:0 0 22px}\n.progress-bar{height:100%;width:36%;background:#017cee;border-radius:999px;animation:report-progress 1.8s ease-in-out infinite alternate;transform-origin:left center}\n@keyframes report-progress{from{transform:translateX(-35%) scaleX(.75)}to{transform:translateX(210%) scaleX(1.15)}}\n.status-card{border:1px solid #d7deea;border-radius:6px;background:#fbfcfe;padding:18px}\n.stage{font-size:13px;font-weight:750;letter-spacing:.035em;text-transform:uppercase;color:#174f87;margin:0 0 8px}\n.message{font-size:16px;line-height:1.45;min-height:2.9em;margin:0;color:#202b3d}\n.meta{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:16px;font-size:12px;color:#52627a}\n.meta div{border-top:1px solid #e3e8ef;padding-top:8px}\n.error{display:none;border-color:#e8b4b4;background:#fffafa}\n.error[aria-hidden="false"]{display:block}\n.error h2{font-size:18px;margin:0 0 12px;color:#991b1b}\ndl{display:grid;grid-template-columns:120px minmax(0,1fr);gap:7px 12px;margin:0;font-size:13px;line-height:1.45}\ndt{font-weight:700;color:#4a5568}dd{margin:0;overflow-wrap:anywhere}\n.actions{display:flex;flex-wrap:wrap;gap:9px;margin-top:18px}\nbutton,a.button{appearance:none;border:1px solid #9aa8ba;background:#fff;color:#172033;border-radius:5px;padding:8px 13px;font:650 13px/1.2 inherit;text-decoration:none;cursor:pointer}\nbutton.primary{background:#017cee;border-color:#017cee;color:#fff}\nbutton:hover,a.button:hover{filter:brightness(.97)}\nbutton:focus-visible,a.button:focus-visible{outline:3px solid rgba(1,124,238,.28);outline-offset:2px}\n.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}\n.report-authentication-notice{margin:0;padding:7px 12px;color:#b91c1c;background:#fff7f7;font:400 13px/1.4 system-ui,sans-serif;text-align:left;overflow-wrap:anywhere}\n.report-authentication-notice[hidden]{display:none}\nbody.authentication-required{display:block;padding:0}\n@media(max-width:560px){main{padding:20px}.header{display:block}.release{margin-top:8px}.meta{grid-template-columns:1fr}dl{grid-template-columns:1fr;gap:2px}dd{margin-bottom:8px}}\n@media(prefers-reduced-motion:reduce){.progress-bar{animation:none;width:42%}}\n</style>\n</head>\n<body>\n<p id="reportAuthenticationNotice" class="report-authentication-notice" role="alert" aria-atomic="true" hidden></p>\n<main>\n  <div class="header">\n    <div><h1>Opening Runtime Report</h1><div>Authenticated Airflow report initialization</div></div>\n    <div class="release">__PLUGIN_RELEASE__</div>\n  </div>\n  <div id="progressTrack" class="progress-track" role="progressbar" aria-label="Report initialization in progress"><div class="progress-bar"></div></div>\n  <section id="statusCard" class="status-card" role="status" aria-live="polite" aria-atomic="true">\n    <p id="stage" class="stage">Bootstrap</p>\n    <p id="message" class="message">Preparing the report interface...</p>\n    <div class="meta"><div>Elapsed: <strong id="elapsed">0.0 s</strong></div><div id="counterWrap" hidden>Progress: <strong id="counter"></strong></div></div>\n  </section>\n  <section id="errorCard" class="status-card error" role="alert" aria-hidden="true">\n    <h2>Report could not be opened</h2>\n    <dl>\n      <dt>Stage</dt><dd id="errorStage">—</dd>\n      <dt>Category</dt><dd id="errorCategory">—</dd>\n      <dt>Summary</dt><dd id="errorSummary">—</dd>\n      <dt>Reference</dt><dd id="errorReference">—</dd>\n      <dt>Suggested action</dt><dd id="errorAction">—</dd>\n    </dl>\n    <div class="actions">\n      <button id="retry" class="primary" type="button">Retry</button>\n      <a id="return" class="button" target="_top" rel="noreferrer">Return to Airflow</a>\n      <button id="copy" type="button">Copy diagnostics</button>\n    </div>\n    <p id="copyStatus" class="sr-only" role="status" aria-live="polite"></p>\n  </section>\n</main>\n<script>\n"use strict";\nconst CONFIG=__CONFIGURATION__;\nconst nodes={\n  authenticationNotice:document.getElementById("reportAuthenticationNotice"),\n  status:document.getElementById("statusCard"),error:document.getElementById("errorCard"),\n  track:document.getElementById("progressTrack"),stage:document.getElementById("stage"),\n  message:document.getElementById("message"),elapsed:document.getElementById("elapsed"),\n  counterWrap:document.getElementById("counterWrap"),counter:document.getElementById("counter"),\n  errorStage:document.getElementById("errorStage"),errorCategory:document.getElementById("errorCategory"),\n  errorSummary:document.getElementById("errorSummary"),errorReference:document.getElementById("errorReference"),\n  errorAction:document.getElementById("errorAction"),retry:document.getElementById("retry"),\n  returnLink:document.getElementById("return"),copy:document.getElementById("copy"),\n  copyStatus:document.getElementById("copyStatus")\n};\nnodes.returnLink.href=CONFIG.returnUrl;\nlet operationId="";\nlet terminal=false;\nlet pollCount=0;\nlet diagnostics={release:CONFIG.release};\nlet controller=new AbortController();\nconst stateLabels={\n  BOOTSTRAP:"Bootstrap",AUTHENTICATING:"Authenticating",RESOLVING_SCOPE:"Resolving scope",\n  CHECKING_CACHE:"Checking cache",WAITING_FOR_BUILD:"Waiting for build",LOADING_DATA:"Loading data",\n  BUILDING_REPORT:"Building report",FINALIZING:"Finalizing",RETRYING:"Retrying",\n  READY:"Ready",ERROR:"Error",CANCELLED:"Cancelled"\n};\nfunction setStatus(stage,message,elapsedMs,counter){\n  nodes.stage.textContent=stateLabels[stage]||stage||"Initializing";\n  nodes.message.textContent=message||"Preparing the report...";\n  nodes.elapsed.textContent=`${Math.max(0,Number(elapsedMs)||0)/1000}`.replace(/(\\.\\d).*/,"$1")+" s";\n  if(counter&&counter.label){nodes.counterWrap.hidden=false;nodes.counter.textContent=counter.label;}\n  else{nodes.counterWrap.hidden=true;nodes.counter.textContent="";}\n}\nfunction safeError(payload,fallback){\n  const error=payload&&payload.error&&typeof payload.error==="object"?payload.error:payload||{};\n  return{\n    stage:String(error.stage||payload?.stage||"BOOTSTRAP"),category:String(error.category||"internal"),\n    summary:String(error.summary||error.message||fallback||"The report initialization failed."),\n    reference:String(error.reference||"unavailable"),\n    action:String(error.suggestedAction||"Review the API-server log and retry after correcting the reported condition."),\n    retryable:Boolean(error.retryable),httpStatus:Number(error.httpStatus)||0\n  };\n}\nfunction showError(payload,fallback,httpStatus=0){\n  terminal=true;\n  const error=safeError(payload,fallback);\n  if(httpStatus===401||(!httpStatus&&(error.httpStatus===401||["authentication","api-authentication"].includes(error.category)))){\n    controller.abort();\n    nodes.error.remove();\n    nodes.status.remove();\n    nodes.track.remove();\n    document.querySelector("main").hidden=true;\n    document.body.classList.add("authentication-required");\n    nodes.authenticationNotice.textContent=CONFIG.authenticationNotice;\n    nodes.authenticationNotice.hidden=false;\n    return;\n  }\n  diagnostics={release:CONFIG.release,operationId, ...error};\n  nodes.status.hidden=true;nodes.track.hidden=true;nodes.error.setAttribute("aria-hidden","false");\n  nodes.errorStage.textContent=stateLabels[error.stage]||error.stage;\n  nodes.errorCategory.textContent=error.category;\n  nodes.errorSummary.textContent=error.summary;\n  nodes.errorReference.textContent=error.reference;\n  nodes.errorAction.textContent=error.action;\n  nodes.retry.focus();\n}\nasync function responseJson(response){\n  try{return await response.json();}catch(_error){return null;}\n}\nfunction pollDelay(){\n  if(document.hidden)return 2000;\n  if(pollCount<2)return 450;\n  if(pollCount<10)return 850;\n  return 1500;\n}\nfunction loadResult(url){\n  setStatus("FINALIZING","Opening the completed report document...",0,null);\n  const target=new URL(url,window.location.href);\n  if(target.origin!==window.location.origin){\n    showError(null,"The completed report URL did not match the Airflow origin.");\n    return;\n  }\n  terminal=true;\n  target.hash=window.location.hash;\n  window.location.replace(target.href);\n}\nasync function pollStatus(){\n  if(terminal||!operationId)return;\n  try{\n    const response=await fetch(CONFIG.statusPrefix+encodeURIComponent(operationId),{credentials:"same-origin",cache:"no-store",signal:controller.signal});\n    const payload=await responseJson(response);\n    if(!response.ok){showError(payload,`Initialization status failed with HTTP ${response.status}.`,response.status);return;}\n    pollCount+=1;\n    setStatus(payload.stage||payload.state,payload.message,payload.elapsedMs,payload.counter);\n    if(payload.state==="READY"){loadResult(payload.resultUrl||CONFIG.resultPrefix+encodeURIComponent(operationId));return;}\n    if(payload.state==="ERROR"||payload.state==="CANCELLED"){showError(payload);return;}\n    window.setTimeout(pollStatus,pollDelay());\n  }catch(error){\n    if(error&&error.name==="AbortError")return;\n    showError(null,"The browser could not read report initialization status.");\n  }\n}\nasync function initialize(){\n  const previousOperation=operationId;\n  if(previousOperation){\n    fetch(CONFIG.cancelPrefix+encodeURIComponent(previousOperation),{method:"POST",credentials:"same-origin",keepalive:true,headers:{"Content-Type":"application/json"},body:"{}"}).catch(()=>{});\n  }\n  terminal=false;pollCount=0;operationId="";controller.abort();controller=new AbortController();\n  nodes.error.setAttribute("aria-hidden","true");nodes.status.hidden=false;nodes.track.hidden=false;\n  setStatus("AUTHENTICATING","Verifying Airflow session and report access...",0,null);\n  try{\n    const response=await fetch(CONFIG.initializeUrl,{method:"POST",credentials:"same-origin",cache:"no-store",headers:{Accept:"application/json"},signal:controller.signal});\n    const payload=await responseJson(response);\n    if(!response.ok){showError(payload,`Report initialization failed with HTTP ${response.status}.`,response.status);return;}\n    operationId=String(payload.operationId||"");\n    if(!operationId){showError(null,"The server did not return an initialization operation identifier.");return;}\n    setStatus(payload.stage||"CHECKING_CACHE",payload.message||"Checking for an available report...",payload.elapsedMs||0,payload.counter||null);\n    window.setTimeout(pollStatus,Number(payload.pollAfterMs)||350);\n  }catch(error){\n    if(error&&error.name==="AbortError")return;\n    showError(null,"The browser could not start report initialization.");\n  }\n}\nnodes.retry.addEventListener("click",initialize);\nnodes.copy.addEventListener("click",async()=>{\n  const text=JSON.stringify(diagnostics,null,2);\n  try{await navigator.clipboard.writeText(text);nodes.copyStatus.textContent="Diagnostics copied.";}\n  catch(_error){const area=document.createElement("textarea");area.value=text;area.setAttribute("readonly","");document.body.append(area);area.select();document.execCommand("copy");area.remove();nodes.copyStatus.textContent="Diagnostics copied.";}\n});\nwindow.addEventListener("pagehide",()=>{\n  controller.abort();\n  if(operationId&&!terminal)fetch(CONFIG.cancelPrefix+encodeURIComponent(operationId),{method:"POST",credentials:"same-origin",keepalive:true,headers:{"Content-Type":"application/json"},body:"{}"}).catch(()=>{});\n},{once:true});\ninitialize();\n</script>\n</body>\n</html>'

def _bootstrap_document(configuration: str) -> str:
    return _BOOTSTRAP_DOCUMENT.replace('__PLUGIN_RELEASE__', html.escape(PLUGIN_RELEASE)).replace('__CONFIGURATION__', configuration)

def _bootstrap_response(request: Request, airflow_ui_base_path: str) -> HTMLResponse:
    return_target = f"{airflow_ui_base_path.rstrip('/')}/" or '/'
    configuration = _json_for_inline_script({'release': PLUGIN_RELEASE, 'authenticationNotice': AUTHENTICATION_NOTICE_MESSAGE, 'initializeUrl': './initialize' + (f'?{request.url.query}' if request.url.query else ''), 'statusPrefix': './status/', 'resultPrefix': './result/', 'cancelPrefix': './cancel/', 'returnUrl': return_target})
    document = _bootstrap_document(configuration)
    return HTMLResponse(document, headers=_BOOTSTRAP_HEADERS)
from dataclasses import dataclass
_INITIALIZATION_ID_RE = re.compile('^[A-Za-z0-9_-]{24,96}$')
_INITIALIZATION_TRANSITIONS: dict[str, frozenset[str]] = {'RESOLVING_SCOPE': frozenset({'CHECKING_CACHE', 'ERROR'}), 'CHECKING_CACHE': frozenset({'WAITING_FOR_BUILD', 'LOADING_DATA', 'FINALIZING', 'READY', 'RETRYING', 'ERROR'}), 'WAITING_FOR_BUILD': frozenset({'LOADING_DATA', 'BUILDING_REPORT', 'FINALIZING', 'READY', 'RETRYING', 'ERROR'}), 'LOADING_DATA': frozenset({'BUILDING_REPORT', 'FINALIZING', 'RETRYING', 'ERROR'}), 'BUILDING_REPORT': frozenset({'FINALIZING', 'RETRYING', 'ERROR'}), 'FINALIZING': frozenset({'READY', 'RETRYING', 'ERROR'}), 'RETRYING': frozenset({'CHECKING_CACHE', 'WAITING_FOR_BUILD', 'LOADING_DATA', 'ERROR'}), 'READY': frozenset(), 'ERROR': frozenset()}

@dataclass(frozen=True, slots=True)
class _InitializationLimits:
    ttl_seconds: int
    stale_seconds: int
    max_records: int
    max_result_bytes: int
    scan_limit: int

def _initialization_limits() -> _InitializationLimits:
    return _InitializationLimits(ttl_seconds=_bounded_env_int('INIT_OPERATION_TTL_SECONDS', 900, 60, 7200), stale_seconds=_bounded_env_int('INIT_STALE_SECONDS', 300, 30, 3600), max_records=_bounded_env_int('INIT_MAX_OPERATIONS', 64, 4, 512), max_result_bytes=_bounded_env_int('INIT_RESULT_BYTES', 512 * 1024 * 1024, MAX_REPORT_BYTES, 4 * 1024 * 1024 * 1024), scan_limit=_bounded_env_int('INIT_SCAN_LIMIT', 2048, 64, 16384))

def _validated_canonical_report_url(value: object) -> str:
    canonical_url = str(value or '')
    if not canonical_url or len(canonical_url) > 4096:
        raise ValueError('canonical report URL is missing or exceeds 4096 bytes')
    parsed = urlsplit(canonical_url)
    if parsed.scheme or parsed.netloc or parsed.fragment or ('\\' in canonical_url) or any((ord(character) < 32 for character in canonical_url)):
        raise ValueError('canonical report URL must be a same-origin path')
    if not parsed.path.startswith('/') or not parsed.path.endswith('/'):
        raise ValueError('canonical report URL must target the mounted report root')
    return canonical_url

def _validated_initialization_id(value: str, label: str) -> str:
    identifier = str(value or '')
    if _INITIALIZATION_ID_RE.fullmatch(identifier) is None:
        raise ValueError(f'invalid report initialization {label}')
    return identifier
import fcntl
import tempfile
from collections.abc import Iterator, Mapping
from contextlib import contextmanager
from typing import Any
_INITIALIZATION_FILE_LIMIT = 128 * 1024
_INITIALIZATION_ROOT_CACHE: tuple[Path, float] | None = None
_INITIALIZATION_ROOT_LOCK = threading.Lock()

def _initialization_root() -> Path:
    global _INITIALIZATION_ROOT_CACHE
    root = _base_log_folder() / 'report' / '.plugin-init'
    recheck_seconds = _bounded_env_int('INIT_ROOT_RECHECK_SECONDS', 30, 1, 300)
    now = time.monotonic()
    cached = _INITIALIZATION_ROOT_CACHE
    if cached is not None and cached[0] == root and (now - cached[1] <= recheck_seconds):
        return root
    with _INITIALIZATION_ROOT_LOCK:
        cached = _INITIALIZATION_ROOT_CACHE
        if cached is not None and cached[0] == root and (now - cached[1] <= recheck_seconds):
            return root
        for path in (root, root / 'jobs', root / 'operations', root / 'results'):
            path.mkdir(mode=488, parents=True, exist_ok=True)
            metadata = path.lstat()
            if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISDIR(metadata.st_mode):
                raise RuntimeError('report initialization path is not a trusted directory')
            os.chmod(path, 488)
        _INITIALIZATION_ROOT_CACHE = (root, now)
        return root

def _record_path(kind: str, identifier: str, suffix: str='.json') -> Path:
    if kind not in {'jobs', 'operations', 'results'}:
        raise ValueError('invalid report initialization record kind')
    identifier = _validated_initialization_id(identifier, 'identifier')
    return _initialization_root() / kind / f'{identifier}{suffix}'

def _atomic_write(path: Path, payload: bytes, maximum: int) -> None:
    if not payload or len(payload) > maximum:
        raise RuntimeError('report initialization record exceeds its byte limit')
    descriptor, temporary_name = tempfile.mkstemp(prefix=f'.{path.name}.', suffix='.tmp', dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 416)
        os.replace(temporary, path)
        directory_fd = os.open(path.parent, os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        temporary.unlink(missing_ok=True)

def _write_json_record(path: Path, payload: Mapping[str, object]) -> None:
    _atomic_write(path, (json.dumps(dict(payload), sort_keys=True, separators=(',', ':')) + '\n').encode('utf-8'), _INITIALIZATION_FILE_LIMIT)

def _read_regular_bytes(path: Path, maximum: int) -> bytes:
    flags = os.O_RDONLY | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_NOFOLLOW', 0)
    descriptor = os.open(path, flags)
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode) or metadata.st_size <= 0 or metadata.st_size > maximum:
            raise RuntimeError('report initialization file is invalid')
        chunks: list[bytes] = []
        remaining = metadata.st_size
        while remaining:
            chunk = os.read(descriptor, min(1024 * 1024, remaining))
            if not chunk:
                raise RuntimeError('report initialization file ended unexpectedly')
            chunks.append(chunk)
            remaining -= len(chunk)
        return b''.join(chunks)
    finally:
        os.close(descriptor)

def _read_json_record(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(_read_regular_bytes(path, _INITIALIZATION_FILE_LIMIT))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RuntimeError('report initialization record cannot be read') from exc
    if not isinstance(value, dict):
        raise RuntimeError('report initialization record is not an object')
    return value

def _safe_unlink(path: Path) -> None:
    try:
        metadata = path.lstat()
    except FileNotFoundError:
        return
    if stat.S_ISREG(metadata.st_mode):
        path.unlink(missing_ok=True)

def _bounded_regular_records(directory: Path, suffix: str, scan_limit: int) -> list[tuple[Path, os.stat_result]]:
    records: list[tuple[Path, os.stat_result]] = []
    scanned = 0
    with os.scandir(directory) as entries:
        for entry in entries:
            scanned += 1
            if scanned > scan_limit:
                raise RuntimeError('report initialization record scan limit was exceeded')
            if not entry.name.endswith(suffix):
                continue
            try:
                metadata = entry.stat(follow_symlinks=False)
            except FileNotFoundError:
                continue
            if not stat.S_ISREG(metadata.st_mode):
                continue
            records.append((Path(entry.path), metadata))
    records.sort(key=lambda item: item[1].st_mtime)
    return records

def _remove_job_artifacts(job_path: Path) -> None:
    job_id = job_path.stem
    _safe_unlink(job_path)
    _safe_unlink(job_path.with_suffix('.lock'))
    try:
        _safe_unlink(_record_path('results', job_id, '.html'))
    except (OSError, RuntimeError, ValueError):
        pass

def _retained_operation_records(root: Path, current: float, limits: _InitializationLimits) -> list[tuple[Path, os.stat_result]]:
    retained: list[tuple[Path, os.stat_result]] = []
    records = _bounded_regular_records(root / 'operations', '.json', limits.scan_limit)
    for path, metadata in records:
        if current - metadata.st_mtime > limits.ttl_seconds:
            _safe_unlink(path)
        else:
            retained.append((path, metadata))
    return retained

def _operation_is_removable(path: Path) -> bool:
    try:
        operation = _read_json_record(path)
        if bool(operation.get('cancelled')):
            return True
        job_id = _validated_initialization_id(str(operation.get('jobId') or ''), 'job')
        state = str(_job_record(job_id).get('state') or '')
        return state in {'READY', 'ERROR'}
    except (OSError, RuntimeError, TypeError, ValueError):
        return True

def _trim_excess_operations(operations: list[tuple[Path, os.stat_result]], maximum: int) -> list[tuple[Path, os.stat_result]]:
    retained = list(operations)
    excess = max(0, len(retained) - maximum)
    if not excess:
        return retained
    removed: set[Path] = set()
    for path, _metadata in retained:
        if not _operation_is_removable(path):
            continue
        _safe_unlink(path)
        removed.add(path)
        excess -= 1
        if not excess:
            break
    return [item for item in retained if item[0] not in removed]

def _referenced_job_ids(operations: list[tuple[Path, os.stat_result]]) -> set[str]:
    referenced: set[str] = set()
    for path, _metadata in operations:
        try:
            job_id = str(_read_json_record(path).get('jobId') or '')
            referenced.add(_validated_initialization_id(job_id, 'job'))
        except (OSError, RuntimeError, TypeError, ValueError):
            _safe_unlink(path)
    return referenced

def _retained_job_records(root: Path, current: float, limits: _InitializationLimits, referenced_jobs: set[str]) -> list[tuple[Path, os.stat_result, str]]:
    retained: list[tuple[Path, os.stat_result, str]] = []
    records = _bounded_regular_records(root / 'jobs', '.json', limits.scan_limit)
    for path, metadata in records:
        try:
            state = str(_read_json_record(path).get('state') or '')
        except (OSError, RuntimeError, TypeError, ValueError):
            state = 'ERROR'
        expired = current - metadata.st_mtime > limits.ttl_seconds
        unreferenced_terminal = state in {'READY', 'ERROR'} and path.stem not in referenced_jobs
        if expired and unreferenced_terminal:
            _remove_job_artifacts(path)
        else:
            retained.append((path, metadata, state))
    return retained

def _trim_excess_jobs(jobs: list[tuple[Path, os.stat_result, str]], referenced_jobs: set[str], maximum: int) -> None:
    excess = max(0, len(jobs) - maximum)
    if not excess:
        return
    removable = [item for item in jobs if item[0].stem not in referenced_jobs and item[2] in {'READY', 'ERROR'}]
    for path, _metadata, _state in removable[:excess]:
        _remove_job_artifacts(path)

def _remove_orphan_results(root: Path, scan_limit: int) -> None:
    existing_jobs = {path.stem for path, _metadata in _bounded_regular_records(root / 'jobs', '.json', scan_limit)}
    for path, _metadata in _bounded_regular_records(root / 'results', '.html', scan_limit):
        if path.stem not in existing_jobs:
            _safe_unlink(path)

def _cleanup_initialization_records(now: float | None=None, *, reserve_operation_slots: int=0) -> None:
    current = time.time() if now is None else now
    limits = _initialization_limits()
    root = _initialization_root()
    operations = _retained_operation_records(root, current, limits)
    maximum_operations = max(0, limits.max_records - reserve_operation_slots)
    operations = _trim_excess_operations(operations, maximum_operations)
    referenced_jobs = _referenced_job_ids(operations)
    jobs = _retained_job_records(root, current, limits, referenced_jobs)
    _trim_excess_jobs(jobs, referenced_jobs, limits.max_records)
    _remove_orphan_results(root, limits.scan_limit)

def _current_result_bytes() -> int:
    limits = _initialization_limits()
    records = _bounded_regular_records(_initialization_root() / 'results', '.html', limits.scan_limit)
    return sum((metadata.st_size for _path, metadata in records))

@contextmanager
def _locked_job(job_id: str) -> Iterator[None]:
    lock_path = _record_path('jobs', job_id, '.lock')
    flags = os.O_RDWR | os.O_CREAT | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_NOFOLLOW', 0)
    descriptor = os.open(lock_path, flags, 416)
    try:
        os.fchmod(descriptor, 416)
        fcntl.flock(descriptor, fcntl.LOCK_EX)
        yield
    finally:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_UN)
        finally:
            os.close(descriptor)

@contextmanager
def _locked_capacity() -> Iterator[None]:
    path = _initialization_root() / '.capacity.lock'
    flags = os.O_RDWR | os.O_CREAT | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_NOFOLLOW', 0)
    descriptor = os.open(path, flags, 416)
    try:
        os.fchmod(descriptor, 416)
        fcntl.flock(descriptor, fcntl.LOCK_EX)
        yield
    finally:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_UN)
        finally:
            os.close(descriptor)

def _job_record(job_id: str) -> dict[str, Any]:
    return _read_json_record(_record_path('jobs', job_id))

def _operation_record(operation_id: str) -> dict[str, Any]:
    return _read_json_record(_record_path('operations', operation_id))

def _create_job_record(job_id: str, payload: Mapping[str, object]) -> bool:
    path = _record_path('jobs', job_id)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_NOFOLLOW', 0)
    try:
        descriptor = os.open(path, flags, 416)
    except FileExistsError:
        return False
    try:
        data = (json.dumps(dict(payload), sort_keys=True, separators=(',', ':')) + '\n').encode('utf-8')
        if len(data) > _INITIALIZATION_FILE_LIMIT:
            raise RuntimeError('report initialization record exceeds its byte limit')
        os.write(descriptor, data)
        os.fsync(descriptor)
        os.fchmod(descriptor, 416)
    finally:
        os.close(descriptor)
    return True
from concurrent.futures import ThreadPoolExecutor
from fastapi import status
_INITIALIZATION_EXECUTOR: ThreadPoolExecutor | None = None
_INITIALIZATION_EXECUTOR_LOCK = threading.Lock()
_INITIALIZATION_SUBMITTED: set[str] = set()
_INITIALIZATION_SUBMITTED_LOCK = threading.Lock()
_INITIALIZATION_LOCAL_CAPACITY = threading.BoundedSemaphore(_bounded_env_int('INIT_LOCAL_QUEUE', 8, 1, 64))

def _initialization_executor() -> ThreadPoolExecutor:
    global _INITIALIZATION_EXECUTOR
    with _INITIALIZATION_EXECUTOR_LOCK:
        if _INITIALIZATION_EXECUTOR is None:
            _INITIALIZATION_EXECUTOR = ThreadPoolExecutor(max_workers=_bounded_env_int('LIVE_BUILD_CONCURRENCY', 2, 1, 8), thread_name_prefix='airflow-report-init')
        return _INITIALIZATION_EXECUTOR

def _transition_job(job_id: str, stage: str, message: str, *, counter: Mapping[str, object] | None=None, extra: Mapping[str, object] | None=None, allow_terminal_update: bool=False) -> dict[str, Any]:
    with _locked_job(job_id):
        record = _job_record(job_id)
        previous = str(record.get('state') or '')
        if previous != stage:
            allowed = _INITIALIZATION_TRANSITIONS.get(previous, frozenset())
            terminal_override = allow_terminal_update and previous in {'READY', 'ERROR'}
            if stage not in allowed and (not terminal_override):
                raise RuntimeError(f'invalid report initialization transition {previous}->{stage}')
        now = time.time()
        record.update({'state': stage, 'stage': stage, 'message': str(message)[:240], 'updatedAt': now, 'counter': dict(counter) if counter else None})
        if extra:
            record.update(dict(extra))
        _write_json_record(_record_path('jobs', job_id), record)
        return record

def _job_progress_callback(job_id: str) -> Callable[[str, str, Mapping[str, object] | None], None]:

    def update(stage: str, message: str, counter: Mapping[str, object] | None=None) -> None:
        _transition_job(job_id, stage, message, counter=counter)
    return update

def _result_payload(job_id: str) -> bytes:
    return _read_regular_bytes(_record_path('results', job_id, '.html'), MAX_REPORT_BYTES)

def _publish_result(job_id: str, payload: bytes, cache_status: str, mode: str, *, etag: str, auth_source: str, history_days: int, future_end: str) -> None:
    limits = _initialization_limits()
    result_path = _record_path('results', job_id, '.html')
    with _locked_capacity():
        existing_size = 0
        try:
            existing_size = result_path.stat().st_size
        except FileNotFoundError:
            pass
        projected_size = _current_result_bytes() - existing_size + len(payload)
        if projected_size > limits.max_result_bytes:
            raise RuntimeError('report initialization result storage byte limit was exceeded')
        _atomic_write(result_path, payload, MAX_REPORT_BYTES)
    _transition_job(job_id, 'READY', 'The report is ready.', extra={'cacheStatus': cache_status, 'mode': mode, 'resultBytes': len(payload), 'etag': etag, 'authSource': auth_source, 'historyDays': history_days, 'futureEnd': future_end, 'finishedAt': time.time(), 'error': None})

def _mark_stale_job_error(job_id: str, observed_updated_at: float, stale_seconds: int, error: Mapping[str, object]) -> dict[str, Any]:
    with _locked_job(job_id):
        record = _job_record(job_id)
        state = str(record.get('state') or '')
        if state in {'READY', 'ERROR'}:
            return record
        current_updated_at = float(record.get('updatedAt') or 0)
        if current_updated_at != observed_updated_at:
            return record
        if time.time() - current_updated_at <= stale_seconds:
            return record
        now = time.time()
        record.update({'state': 'ERROR', 'stage': 'ERROR', 'message': str(error['summary'])[:240], 'updatedAt': now, 'finishedAt': now, 'counter': None, 'error': dict(error)})
        _write_json_record(_record_path('jobs', job_id), record)
        return record

def _safe_failure_payload(exc: Exception, stage: str) -> tuple[dict[str, object], int, bool]:
    diagnosis = _runtime_failure_diagnosis(exc)
    reference = _diagnostic_reference()
    LOG.error('Runtime report initialization failed reference=%s stage=%s category=%s detail=%s', reference, stage, diagnosis.category, diagnosis.detail)
    error = {'stage': stage, 'category': diagnosis.category, 'summary': diagnosis.operator_message, 'reference': reference, 'suggestedAction': diagnosis.suggested_action, 'retryable': diagnosis.retryable, 'httpStatus': diagnosis.http_status}
    return (error, diagnosis.http_status, diagnosis.retryable)

def _render_filter_feedback(values: Mapping[str, object], access: _RequestAccessContext, airflow_ui_base_path: str, filter_feedback: Mapping[str, object], progress_callback: Callable[[str, str, Mapping[str, object] | None], None]) -> bytes:
    acquired = _LIVE_BUILD_SEMAPHORE.acquire(timeout=_bounded_env_int('LIVE_BUILD_WAIT_SECONDS', 90, 1, 900))
    if not acquired:
        raise RuntimeError('materialized report build concurrency wait timed out')
    try:
        rendered = _render_live_payload(values, access.credential, repository_scope=access.repository_scope, authorization_identity=access.authorization_identity, airflow_ui_base_path=airflow_ui_base_path, filter_feedback=filter_feedback, progress_callback=progress_callback)
    finally:
        _LIVE_BUILD_SEMAPHORE.release()
    payload = rendered.payload if isinstance(rendered, _LiveRenderedPayload) else rendered
    if not isinstance(payload, bytes):
        raise RuntimeError('materialized renderer returned a non-byte payload')
    return payload

def _build_initialization_result(key: str, values: Mapping[str, object], access: _RequestAccessContext, airflow_ui_base_path: str, force_reinitialize: bool, filter_feedback: Mapping[str, object] | None, callback: Callable[[str, str, Mapping[str, object] | None], None]) -> tuple[bytes, str, str]:
    if filter_feedback:
        callback('WAITING_FOR_BUILD', 'Waiting for available report build capacity...', None)
        payload = _render_filter_feedback(values, access, airflow_ui_base_path, filter_feedback, callback)
        return (payload, 'FILTER-VALIDATION', f'"{hashlib.sha256(payload).hexdigest()}"')
    entry, cache_status = _cached_live_payload(key, values, access.credential, repository_scope=access.repository_scope, authorization_identity=access.authorization_identity, airflow_ui_base_path=airflow_ui_base_path, force_reinitialize=force_reinitialize, progress_callback=callback)
    return (entry.payload, cache_status, entry.etag)

def _result_metadata(access: _RequestAccessContext, values: Mapping[str, object]) -> dict[str, object]:
    return {'auth_source': access.cache_partition.split(':', 1)[0], 'history_days': int(values.get('_live_report_days') or 0), 'future_end': str(values.get('future_end') or '')}

def _static_fallback_allowed(mode: str, access: _RequestAccessContext, category: object) -> bool:
    denied = {'authentication', 'api-authentication', 'authorization', 'api-authorization'}
    return mode == 'hybrid' and access.cache_partition == 'connection' and (category not in denied)

def _try_static_fallback(job_id: str, access: _RequestAccessContext, values: Mapping[str, object], callback: Callable[[str, str, Mapping[str, object] | None], None]) -> bool:
    try:
        callback('FINALIZING', 'Opening the latest validated static report fallback...', None)
        payload = _read_current_report_payload()
        _publish_result(job_id, payload, 'STATIC-FALLBACK', 'hybrid-static', etag=f'"{hashlib.sha256(payload).hexdigest()}"', **_result_metadata(access, values))
        return True
    except (FileNotFoundError, OSError, RuntimeError):
        return False

def _publish_terminal_job_error(job_id: str, error: Mapping[str, object]) -> None:
    _transition_job(job_id, 'ERROR', str(error['summary']), extra={'error': dict(error), 'finishedAt': time.time()})

def _execute_initialization_job(job_id: str, key: str, values: Mapping[str, object], access: _RequestAccessContext, airflow_ui_base_path: str, force_reinitialize: bool, mode: str, filter_feedback: Mapping[str, object] | None) -> None:
    callback = _job_progress_callback(job_id)
    attempts = 0
    try:
        while True:
            try:
                _transition_job(job_id, 'CHECKING_CACHE', 'Checking for an available report...')
                payload, cache_status, etag = _build_initialization_result(key, values, access, airflow_ui_base_path, force_reinitialize, filter_feedback, callback)
                _publish_result(job_id, payload, cache_status, 'materialized', etag=etag, **_result_metadata(access, values))
                return
            except Exception as exc:
                stage = str(_job_record(job_id).get('stage') or 'CHECKING_CACHE')
                error, _http_status, retryable = _safe_failure_payload(exc, stage)
                if retryable and attempts == 0:
                    attempts = 1
                    _transition_job(job_id, 'RETRYING', 'The Airflow API is temporarily unavailable. Retrying once...', extra={'retryCount': attempts, 'lastErrorReference': error['reference']})
                    time.sleep(1.0)
                    continue
                if _static_fallback_allowed(mode, access, error.get('category')):
                    if _try_static_fallback(job_id, access, values, callback):
                        return
                _publish_terminal_job_error(job_id, error)
                return
    finally:
        with _INITIALIZATION_SUBMITTED_LOCK:
            _INITIALIZATION_SUBMITTED.discard(job_id)

def _job_identifier(key: str, force_reinitialize: bool) -> str:
    material = f'{PLUGIN_RELEASE}:{key}:{int(force_reinitialize)}'.encode('utf-8')
    return hashlib.sha256(material).hexdigest()[:48]

def _initial_job_payload(job_id: str, repository_scope: str, key_digest: str) -> dict[str, object]:
    now = time.time()
    return {'schema': INITIALIZATION_JOB_SCHEMA, 'release': PLUGIN_RELEASE, 'jobId': job_id, 'repositoryScope': repository_scope, 'keyDigest': key_digest, 'state': 'RESOLVING_SCOPE', 'stage': 'RESOLVING_SCOPE', 'message': 'Resolving your authorized report scope...', 'createdAt': now, 'updatedAt': now, 'startedAt': now, 'finishedAt': None, 'retryCount': 0, 'counter': None, 'error': None}

def _select_or_create_job(key: str, repository_scope: str, force_reinitialize: bool) -> tuple[str, bool]:
    limits = _initialization_limits()
    stale_seconds = limits.stale_seconds
    base = _job_identifier(key, force_reinitialize)
    if force_reinitialize:
        candidates = [f'{base}-{secrets.token_hex(6)}']
    else:
        candidates = [base, f'{base}-{secrets.token_hex(6)}']
    for index, job_id in enumerate(candidates):
        payload = _initial_job_payload(job_id, repository_scope, hashlib.sha256(key.encode('utf-8')).hexdigest())
        job_records = _bounded_regular_records(_initialization_root() / 'jobs', '.json', limits.scan_limit)
        candidate_exists = any((path.stem == job_id for path, _metadata in job_records))
        if not candidate_exists and len(job_records) >= limits.max_records:
            raise RuntimeError('report initialization shared job capacity is exhausted')
        created = _create_job_record(job_id, payload)
        if created:
            return (job_id, True)
        if index == 0 and (not force_reinitialize):
            try:
                existing = _job_record(job_id)
                state = str(existing.get('state') or '')
                same_scope = existing.get('repositoryScope') == repository_scope
                age = time.time() - float(existing.get('updatedAt') or 0)
                if same_scope and state == 'READY':
                    _result_payload(job_id)
                    return (job_id, False)
                if same_scope and state not in {'READY', 'ERROR'} and (age <= stale_seconds):
                    return (job_id, False)
            except (OSError, RuntimeError, TypeError, ValueError):
                pass
    raise RuntimeError('report initialization job could not be created')

def _create_operation(job_id: str, principal: str, access: _RequestAccessContext, canonical_url: str) -> str:
    validated_canonical_url = _validated_canonical_report_url(canonical_url)
    operation_id = secrets.token_urlsafe(24)
    now = time.time()
    limits = _initialization_limits()
    operation_records = _bounded_regular_records(_initialization_root() / 'operations', '.json', limits.scan_limit)
    if len(operation_records) >= limits.max_records:
        raise RuntimeError('report initialization viewer operation capacity is exhausted')
    _write_json_record(_record_path('operations', operation_id), {'schema': INITIALIZATION_OPERATION_SCHEMA, 'release': PLUGIN_RELEASE, 'operationId': operation_id, 'jobId': job_id, 'principal': principal, 'repositoryScope': access.repository_scope, 'canonicalUrl': validated_canonical_url, 'createdAt': now, 'updatedAt': now, 'expiresAt': now + limits.ttl_seconds, 'cancelled': False})
    return operation_id

def _execute_submitted_job(job_id: str, key: str, values: Mapping[str, object], access: _RequestAccessContext, airflow_ui_base_path: str, force_reinitialize: bool, mode: str, filter_feedback: Mapping[str, object] | None) -> None:
    try:
        _execute_initialization_job(job_id, key, values, access, airflow_ui_base_path, force_reinitialize, mode, filter_feedback)
    finally:
        _INITIALIZATION_LOCAL_CAPACITY.release()

def _submission_failure(job_id: str, exc: Exception) -> None:
    error, _http_status, _retryable = _safe_failure_payload(exc, 'WAITING_FOR_BUILD')
    _transition_job(job_id, 'ERROR', str(error['summary']), extra={'error': error, 'finishedAt': time.time()})

def _submit_job(job_id: str, key: str, values: Mapping[str, object], access: _RequestAccessContext, airflow_ui_base_path: str, force_reinitialize: bool, mode: str, filter_feedback: Mapping[str, object] | None) -> None:
    with _INITIALIZATION_SUBMITTED_LOCK:
        if job_id in _INITIALIZATION_SUBMITTED:
            return
        _INITIALIZATION_SUBMITTED.add(job_id)
    acquired = _INITIALIZATION_LOCAL_CAPACITY.acquire(blocking=False)
    if not acquired:
        with _INITIALIZATION_SUBMITTED_LOCK:
            _INITIALIZATION_SUBMITTED.discard(job_id)
        _submission_failure(job_id, RuntimeError('report initialization local queue capacity is exhausted'))
        return
    try:
        _initialization_executor().submit(_execute_submitted_job, job_id, key, dict(values), access, airflow_ui_base_path, force_reinitialize, mode, dict(filter_feedback) if filter_feedback else None)
    except Exception as exc:
        _INITIALIZATION_LOCAL_CAPACITY.release()
        with _INITIALIZATION_SUBMITTED_LOCK:
            _INITIALIZATION_SUBMITTED.discard(job_id)
        _submission_failure(job_id, exc)

def _start_initialization(*, key: str, values: Mapping[str, object], principal: str, access: _RequestAccessContext, airflow_ui_base_path: str, force_reinitialize: bool, mode: str, canonical_url: str, filter_feedback: Mapping[str, object] | None=None) -> dict[str, object]:
    with _locked_capacity():
        _cleanup_initialization_records(reserve_operation_slots=1)
        job_id, owner = _select_or_create_job(key, access.repository_scope, force_reinitialize)
        operation_id = _create_operation(job_id, principal, access, canonical_url)
    if owner:
        _submit_job(job_id, key, values, access, airflow_ui_base_path, force_reinitialize, mode, filter_feedback)
    job = _job_record(job_id)
    return {'schema': INITIALIZATION_STATUS_SCHEMA, 'operationId': operation_id, 'state': job['state'], 'stage': job['stage'], 'message': job['message'], 'elapsedMs': max(0, int((time.time() - float(job['createdAt'])) * 1000)), 'pollAfterMs': 350}

def _authorized_operation(operation_id: str, principal: str, access: _RequestAccessContext) -> tuple[dict[str, Any], dict[str, Any]]:
    operation = _operation_record(_validated_initialization_id(operation_id, 'operation'))
    if operation.get('schema') != INITIALIZATION_OPERATION_SCHEMA:
        raise RuntimeError('report initialization operation schema mismatch')
    if operation.get('principal') != principal or operation.get('repositoryScope') != access.repository_scope:
        raise PermissionError('report initialization operation is outside the authorized scope')
    if time.time() > float(operation.get('expiresAt') or 0):
        raise FileNotFoundError('report initialization operation expired')
    job = _job_record(str(operation['jobId']))
    return (operation, job)

def _status_payload(operation_id: str, principal: str, access: _RequestAccessContext) -> dict[str, object]:
    operation, job = _authorized_operation(operation_id, principal, access)
    if bool(operation.get('cancelled')):
        return {'schema': INITIALIZATION_STATUS_SCHEMA, 'operationId': operation_id, 'state': 'CANCELLED', 'stage': 'CANCELLED', 'message': 'This report view was cancelled.', 'elapsedMs': max(0, int((time.time() - float(job['createdAt'])) * 1000)), 'counter': None}
    state = str(job.get('state') or 'ERROR')
    limits = _initialization_limits()
    stale_seconds = limits.stale_seconds
    observed_updated_at = float(job.get('updatedAt') or 0)
    if state not in {'READY', 'ERROR'} and time.time() - observed_updated_at > stale_seconds:
        error = {'stage': str(job.get('stage') or 'CHECKING_CACHE'), 'category': 'concurrency', 'summary': 'The report initialization worker stopped updating its shared status.', 'reference': _diagnostic_reference(), 'suggestedAction': 'Retry the report and inspect the API-server worker lifecycle if the condition repeats.', 'retryable': True, 'httpStatus': status.HTTP_503_SERVICE_UNAVAILABLE}
        job = _mark_stale_job_error(str(job['jobId']), observed_updated_at, stale_seconds, error)
        state = str(job.get('state') or 'ERROR')
    payload: dict[str, object] = {'schema': INITIALIZATION_STATUS_SCHEMA, 'operationId': operation_id, 'state': state, 'stage': str(job.get('stage') or state), 'message': str(job.get('message') or 'Preparing the report...'), 'elapsedMs': max(0, int((time.time() - float(job['createdAt'])) * 1000)), 'counter': job.get('counter'), 'retryCount': int(job.get('retryCount') or 0)}
    if state == 'READY':
        payload['resultUrl'] = f'./result/{operation_id}'
        payload['cacheStatus'] = str(job.get('cacheStatus') or 'UNKNOWN')
        payload['resultBytes'] = int(job.get('resultBytes') or 0)
    elif state == 'ERROR':
        payload['error'] = dict(job.get('error') or {})
    return payload

def _cancel_operation(operation_id: str, principal: str, access: _RequestAccessContext) -> None:
    operation, _job = _authorized_operation(operation_id, principal, access)
    operation['cancelled'] = True
    operation['updatedAt'] = time.time()
    _write_json_record(_record_path('operations', operation_id), operation)

def _operation_result(operation_id: str, principal: str, access: _RequestAccessContext) -> tuple[bytes, dict[str, Any], str]:
    operation, job = _authorized_operation(operation_id, principal, access)
    if operation.get('cancelled'):
        raise FileNotFoundError('report initialization operation was cancelled')
    if job.get('state') != 'READY':
        raise RuntimeError('report initialization result is not ready')
    try:
        canonical_url = _validated_canonical_report_url(operation.get('canonicalUrl'))
    except ValueError as exc:
        raise RuntimeError('report initialization canonical URL is invalid') from exc
    return (_result_payload(str(job['jobId'])), job, canonical_url)
from urllib.parse import parse_qsl, urlencode, urlsplit
from starlette.responses import HTMLResponse, JSONResponse, Response, StreamingResponse

def _static_report_response() -> Response:
    descriptor, size, identity = _open_current_report()
    headers = dict(_RESPONSE_HEADERS)
    headers['Content-Length'] = str(size)
    headers['X-Airflow-Runtime-Report-Mode'] = 'static'
    return StreamingResponse(_stream_descriptor(descriptor, size, identity), media_type='text/html', headers=headers)

def _safe_error_return_url(value: object) -> str:
    candidate = str(value or '')
    if not candidate or len(candidate) > 4096:
        return './'
    parsed = urlsplit(candidate)
    if parsed.scheme or parsed.netloc or parsed.fragment or ('\\' in candidate):
        return './'
    if candidate.startswith(('/', './', '?')):
        return candidate
    return './'

def _authentication_notice_response() -> HTMLResponse:
    message = html.escape(AUTHENTICATION_NOTICE_MESSAGE, quote=True)
    document = f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Airflow Runtime Report</title><style>body{{margin:0;background:#fff;font-family:system-ui,sans-serif}}.report-authentication-notice{{margin:0;padding:7px 12px;color:#b91c1c;background:#fff7f7;font-size:13px;line-height:1.4;text-align:left;overflow-wrap:anywhere}}</style></head><body><p id="reportAuthenticationNotice" class="report-authentication-notice" role="alert" aria-atomic="true">{message}</p></body></html>'
    return HTMLResponse(document, status_code=401, headers=_RESPONSE_HEADERS)

def _error_response(message: str, status_code: int, return_url: str, *, stage: str='BOOTSTRAP', category: str='runtime', reference: str | None=None, suggested_action: str='Inspect the API-server log and retry after correcting the reported condition.', retryable: bool=True) -> HTMLResponse:
    if status_code == 401:
        return _authentication_notice_response()
    safe_message = html.escape(str(message), quote=True)
    safe_stage = html.escape(str(stage), quote=True)
    safe_category = html.escape(str(category), quote=True)
    raw_reference = reference or _diagnostic_reference()
    safe_reference = html.escape(raw_reference, quote=True)
    safe_action = html.escape(str(suggested_action), quote=True)
    recovery_url = _safe_error_return_url(return_url)
    safe_return = html.escape(recovery_url, quote=True)
    retry_target = json.dumps(recovery_url, ensure_ascii=True, separators=(',', ':')).replace('&', '\\u0026').replace('<', '\\u003c').replace('>', '\\u003e')
    retry_button = '<button id="retry" class="primary" type="button">Retry</button>' if retryable else ''
    retry_script = 'document.getElementById("retry")?.addEventListener("click",()=>window.location.assign(' + retry_target + '));' if retryable else ''
    diagnostics = json.dumps({'stage': stage, 'category': category, 'summary': str(message), 'reference': raw_reference, 'suggestedAction': suggested_action, 'httpStatus': status_code}, ensure_ascii=True, separators=(',', ':')).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
    document = f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Airflow Runtime Report error</title><style>:root{{font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}}*{{box-sizing:border-box}}body{{margin:0;min-height:100vh;display:grid;place-items:center;background:#f7f8fa;color:#20242c;padding:24px}}main{{width:min(760px,100%);border:1px solid #e1b7b7;border-radius:8px;background:#fff;padding:28px;box-shadow:0 8px 28px rgba(15,23,42,.08)}}h1{{margin:0 0 18px;font-size:21px;color:#991b1b}}dl{{display:grid;grid-template-columns:130px minmax(0,1fr);gap:8px 12px;margin:0;line-height:1.45}}dt{{font-weight:700;color:#52627a}}dd{{margin:0;overflow-wrap:anywhere}}.actions{{display:flex;flex-wrap:wrap;gap:9px;margin-top:20px}}button,a{{border:1px solid #9aa8ba;border-radius:5px;background:#fff;color:#172033;padding:8px 13px;font:650 13px/1.2 inherit;text-decoration:none;cursor:pointer}}button.primary{{background:#017cee;border-color:#017cee;color:#fff}}:focus-visible{{outline:3px solid rgba(1,124,238,.28);outline-offset:2px}}@media(max-width:560px){{dl{{grid-template-columns:1fr;gap:2px}}dd{{margin-bottom:8px}}}}</style></head><body><main role="alert"><h1>Report could not be opened</h1><dl><dt>Stage</dt><dd>{safe_stage}</dd><dt>Category</dt><dd>{safe_category}</dd><dt>Summary</dt><dd>{safe_message}</dd><dt>Reference</dt><dd>{safe_reference}</dd><dt>Suggested action</dt><dd>{safe_action}</dd></dl><div class="actions">{retry_button}<a href="{safe_return}" target="_top" rel="noreferrer">Return to Airflow</a><button id="copy" type="button">Copy diagnostics</button></div><span id="copyStatus" role="status" aria-live="polite"></span></main><script>const diagnostics={diagnostics};{retry_script}document.getElementById("copy")?.addEventListener("click",async()=>{{const text=JSON.stringify(diagnostics,null,2);try{{await navigator.clipboard.writeText(text);}}catch(_error){{const node=document.createElement("textarea");node.value=text;document.body.append(node);node.select();document.execCommand("copy");node.remove();}}document.getElementById("copyStatus").textContent=" Diagnostics copied.";}});</script></body></html>'
    return HTMLResponse(document, status_code=status_code, headers=_RESPONSE_HEADERS)

def _json_error_response(exc: Exception, stage: str) -> JSONResponse:
    diagnosis = _runtime_failure_diagnosis(exc)
    reference = _diagnostic_reference()
    LOG.error('Runtime report initialization request failed reference=%s stage=%s category=%s detail=%s', reference, stage, diagnosis.category, diagnosis.detail)
    headers = dict(_JSON_HEADERS)
    if diagnosis.retryable:
        headers['Retry-After'] = '1'
    return JSONResponse({'error': {'stage': stage, 'category': diagnosis.category, 'summary': diagnosis.operator_message, 'reference': reference, 'suggestedAction': diagnosis.suggested_action, 'retryable': diagnosis.retryable, 'httpStatus': diagnosis.http_status}}, status_code=diagnosis.http_status, headers=headers)

def _exception_error_response(exc: Exception, stage: str, return_url: str, *, status_override: int | None=None) -> HTMLResponse:
    response = _json_error_response(exc, stage)
    error = json.loads(response.body)['error']
    status_code = status_override or response.status_code
    return _error_response(str(error['summary']), status_code, return_url, stage=str(error['stage']), category=str(error['category']), reference=str(error['reference']), suggested_action=str(error['suggestedAction']), retryable=bool(error['retryable']))

def _canonical_result_payload(payload: bytes, canonical_url: str) -> bytes:
    validated = _validated_canonical_report_url(canonical_url)
    marker = b'</head>'
    index = payload.find(marker)
    if index < 0:
        raise RuntimeError('completed report document is missing the head terminator')
    serialized = json.dumps(validated, ensure_ascii=True, separators=(',', ':')).replace('&', '\\u0026').replace('<', '\\u003c').replace('>', '\\u003e').replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')
    script = ('<script data-airflow-runtime-report-canonical-url>history.replaceState(history.state,"",' + serialized + '+window.location.hash);</script>').encode('ascii')
    return payload[:index] + script + payload[index:]

def _initialization_result_response(payload: bytes, job: dict[str, object] | Mapping[str, object], canonical_url: str) -> Response:
    response_payload = _canonical_result_payload(payload, canonical_url)
    response_payload = response_payload.replace(b"connect-src 'none'", b"connect-src 'self'", 1)
    headers = dict(_RESPONSE_HEADERS)
    headers['Content-Security-Policy'] = headers['Content-Security-Policy'].replace("connect-src 'none'", "connect-src 'self'")
    headers['Content-Length'] = str(len(response_payload))
    headers['X-Airflow-Runtime-Report-Mode'] = str(job.get('mode') or 'materialized')
    headers['X-Airflow-Runtime-Report-Cache'] = str(job.get('cacheStatus') or 'UNKNOWN')
    headers['X-Airflow-Runtime-Report-Auth'] = str(job.get('authSource') or 'unknown')
    headers['X-Airflow-Runtime-Report-History-Days'] = str(job.get('historyDays') or 0)
    headers['X-Airflow-Runtime-Report-Future-End'] = str(job.get('futureEnd') or '')
    etag = str(job.get('etag') or '').strip('"')
    if etag:
        canonical_digest = hashlib.sha256(canonical_url.encode('utf-8')).hexdigest()[:16]
        headers['ETag'] = f'W/"{etag}-{canonical_digest}"'
    return Response(response_payload, media_type='text/html', headers=headers)

def _initial_report_url(request: Request) -> str:
    return _canonical_request_url_without_reinit(request)

def _canonical_query_without_reinit(request: Request) -> str:
    return urlencode([(key, value) for key, value in parse_qsl(request.scope.get('query_string', b'').decode('latin-1'), keep_blank_values=True) if key != 'reinit'])

def _canonical_request_url_without_reinit(request: Request) -> str:
    query = _canonical_query_without_reinit(request)
    return f'?{query}' if query else './'

def _canonical_report_url_from_initialize(request: Request) -> str:
    visible_path = request.url.path
    suffix = '/initialize'
    if not visible_path.endswith(suffix):
        raise RuntimeError('report initialization request path is not canonical')
    report_root = visible_path[:-len('initialize')]
    query = _canonical_query_without_reinit(request)
    return _validated_canonical_report_url(report_root + (f'?{query}' if query else ''))

def _canonical_report_root_from_result(request: Request) -> str:
    visible_path = request.url.path
    marker = '/result/'
    prefix, separator, operation_id = visible_path.rpartition(marker)
    if not separator or not prefix or (not operation_id):
        raise RuntimeError('report result request path is not canonical')
    return _validated_canonical_report_url(prefix + '/')
from threading import BoundedSemaphore
if TYPE_CHECKING:
    from airflow_report.api import RequestApiCredential
    from airflow_report.task_timeline import DagTaskTimelinePayload
_TASK_TIMELINE_SLOTS = BoundedSemaphore(4)

def _dag_task_timeline(credential: object | None, dag_id: str, run_ids: list[str]) -> DagTaskTimelinePayload:
    from airflow_report.api import ApiClient
    from airflow_report.configuration import parse_config
    from airflow_report.task_timeline import MAX_API_BYTES, MAX_API_CALLS, TIMELINE_SECONDS, collect_dag_task_timeline
    config = replace(parse_config(_live_values(None, None, None, None, None)), api_timeout=5, api_retries=0, max_rows=5000, max_pages=50, page_limit=100, max_response_bytes=4 * 1024 * 1024)
    client = ApiClient.create(config, cast('RequestApiCredential | None', credential))
    client.request_deadline = time.monotonic() + TIMELINE_SECONDS
    client.request_limit = MAX_API_CALLS
    client.response_byte_limit = MAX_API_BYTES
    try:
        return collect_dag_task_timeline(client, dag_id, run_ids)
    finally:
        client.close()
from fastapi import Depends, FastAPI, HTTPException, Query, Request, status
from fastapi.exception_handlers import http_exception_handler
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.responses import JSONResponse, Response
report_app = FastAPI(title='Airflow Runtime Report UI', docs_url=None, redoc_url=None, openapi_url=None, dependencies=[Depends(get_user)])

@report_app.exception_handler(StarletteHTTPException)
async def report_http_exception_handler(request: Request, exc: StarletteHTTPException) -> Response:
    if exc.status_code == 401 and 'text/html' in request.headers.get('accept', ''):
        response = _authentication_notice_response()
        if exc.headers:
            response.headers.update(exc.headers)
        return response
    return await http_exception_handler(request, exc)

def _health_headers() -> dict[str, str]:
    headers = dict(_RESPONSE_HEADERS)
    headers.pop('Content-Disposition', None)
    return headers

@report_app.get('/health', include_in_schema=False)
def runtime_report_health() -> Response:
    return JSONResponse({'status': 'ok', 'service': 'airflow-runtime-report', 'release': PLUGIN_RELEASE, 'rendererSha256': PLUGIN_EXPECTED_RENDERER_SHA256, 'mountPath': f'{PLUGIN_URL_PREFIX}/', 'uiPath': f'/plugin/{PLUGIN_ROUTE}', 'initialization': 'bootstrap-v1'}, headers=_health_headers())

@report_app.get('/', include_in_schema=False)
def current_runtime_report(request: Request) -> Response:
    try:
        mode = _plugin_mode()
        if mode == 'static':
            return _static_report_response()
        return _bootstrap_response(request, _request_ui_base_path(request))
    except HTTPException:
        raise
    except Exception as exc:
        return _exception_error_response(exc, 'BOOTSTRAP', _initial_report_url(request))

@report_app.post('/initialize', include_in_schema=False)
def initialize_runtime_report(request: Request, start: str | None=None, end: str | None=None, report_days: str | None=None, future_end: str | None=None, timezone: str | None=None, reinit: str | None=None, user: object=Depends(get_user)) -> Response:
    try:
        mode = _plugin_mode()
        if mode == 'static':
            raise RuntimeError('static mode does not use report initialization')
        principal = _principal_key(user)
        access = _request_access_context(request, principal)
    except HTTPException:
        raise
    except Exception as exc:
        return _json_error_response(exc, 'AUTHENTICATING')
    try:
        airflow_ui_base_path = _request_ui_base_path(request)
        force_reinitialize = str(reinit or '').strip().lower() in {'1', 'true', 'yes'}
        filter_feedback: dict[str, object] | None = None
        try:
            values = _live_values(start, end, report_days, future_end, timezone)
        except _LiveFilterError as exc:
            fallback_timezone = None if 'liveFilterTimezone' in exc.fields else timezone
            values = _live_values(None, None, None, None, fallback_timezone)
            filter_feedback = {'filterMessage': str(exc), 'invalidFields': list(exc.fields), 'submittedFilters': {'start': str(start or ''), 'end': str(end or ''), 'reportDays': str(report_days or ''), 'futureEnd': str(future_end or '')}}
        key = _live_cache_key(principal, values, access.cache_partition, airflow_ui_base_path)
        if filter_feedback:
            key += ':filter:' + hashlib.sha256(json.dumps(filter_feedback, sort_keys=True).encode('utf-8')).hexdigest()[:24]
        payload = _start_initialization(key=key, values=values, principal=principal, access=access, airflow_ui_base_path=airflow_ui_base_path, force_reinitialize=force_reinitialize, mode=mode, canonical_url=_canonical_report_url_from_initialize(request), filter_feedback=filter_feedback)
        return JSONResponse(payload, headers=_JSON_HEADERS)
    except HTTPException:
        raise
    except Exception as exc:
        return _json_error_response(exc, 'CHECKING_CACHE')

@report_app.get('/status/{operation_id}', include_in_schema=False)
def runtime_report_status(operation_id: str, request: Request, user: object=Depends(get_user)) -> Response:
    try:
        principal = _principal_key(user)
        access = _request_access_context(request, principal)
        return JSONResponse(_status_payload(operation_id, principal, access), headers=_JSON_HEADERS)
    except FileNotFoundError as exc:
        response = _json_error_response(exc, 'CHECKING_CACHE')
        response.status_code = status.HTTP_404_NOT_FOUND
        return response
    except PermissionError as exc:
        response = _json_error_response(exc, 'AUTHENTICATING')
        response.status_code = status.HTTP_403_FORBIDDEN
        return response
    except HTTPException:
        raise
    except Exception as exc:
        return _json_error_response(exc, 'CHECKING_CACHE')

@report_app.get('/result/{operation_id}', include_in_schema=False)
def runtime_report_result(operation_id: str, request: Request, user: object=Depends(get_user)) -> Response:
    try:
        principal = _principal_key(user)
        access = _request_access_context(request, principal)
        payload, job, canonical_url = _operation_result(operation_id, principal, access)
        return _initialization_result_response(payload, job, canonical_url)
    except FileNotFoundError as exc:
        return _exception_error_response(exc, 'FINALIZING', _canonical_report_root_from_result(request), status_override=status.HTTP_404_NOT_FOUND)
    except PermissionError as exc:
        return _exception_error_response(exc, 'AUTHENTICATING', _canonical_report_root_from_result(request), status_override=status.HTTP_403_FORBIDDEN)
    except HTTPException:
        raise
    except Exception as exc:
        return _exception_error_response(exc, 'FINALIZING', _canonical_report_root_from_result(request))

@report_app.post('/cancel/{operation_id}', include_in_schema=False)
def cancel_runtime_report(operation_id: str, request: Request, user: object=Depends(get_user)) -> Response:
    try:
        principal = _principal_key(user)
        access = _request_access_context(request, principal)
        _cancel_operation(operation_id, principal, access)
        return Response(status_code=status.HTTP_204_NO_CONTENT, headers=_JSON_HEADERS)
    except FileNotFoundError:
        return Response(status_code=status.HTTP_204_NO_CONTENT, headers=_JSON_HEADERS)
    except PermissionError as exc:
        response = _json_error_response(exc, 'AUTHENTICATING')
        response.status_code = status.HTTP_403_FORBIDDEN
        return response
    except HTTPException:
        raise
    except Exception as exc:
        return _json_error_response(exc, 'CANCELLED')

@report_app.get('/task-timeline', include_in_schema=False)
def dag_task_timeline(request: Request, dag_id: str, dag_run_id: list[str]=Query(...), user: object=Depends(get_user)) -> Response:
    try:
        from airflow_report.task_timeline import validate_timeline_identifier, validate_timeline_run_ids
        validate_timeline_identifier(dag_id, 250)
        validate_timeline_run_ids(dag_run_id)
        access = _request_access_context(request, _principal_key(user))
        if not _TASK_TIMELINE_SLOTS.acquire(blocking=False):
            return JSONResponse({'error': 'Task timeline is busy; collapse and retry.'}, status_code=429, headers=_JSON_HEADERS)
        try:
            payload = _dag_task_timeline(access.credential, dag_id, dag_run_id)
        finally:
            _TASK_TIMELINE_SLOTS.release()
        return JSONResponse(payload, headers=_JSON_HEADERS)
    except HTTPException:
        raise
    except _LiveAuthenticationError:
        return JSONResponse({'error': 'Task timeline authentication required.'}, status_code=401, headers=_JSON_HEADERS)
    except PermissionError:
        return JSONResponse({'error': 'Task timeline access denied.'}, status_code=403, headers=_JSON_HEADERS)
    except ValueError:
        return JSONResponse({'error': 'Invalid or incomplete task timeline.'}, status_code=422, headers=_JSON_HEADERS)
    except Exception as exc:
        code = getattr(exc, 'status', 503)
        code = code if code in {401, 403, 404, 429} else 503
        return JSONResponse({'error': 'Task timeline unavailable; collapse and retry.'}, status_code=code, headers=_JSON_HEADERS)
from typing import ClassVar

def _validate_plugin_registration(plugin_class: type[AirflowRuntimeReportPlugin]) -> None:
    expected_app = {'app': report_app, 'url_prefix': PLUGIN_URL_PREFIX, 'name': 'Airflow Runtime Report Server'}
    expected_view = {'name': PLUGIN_DISPLAY_NAME, 'href': _external_view_href(), 'destination': 'nav', 'url_route': PLUGIN_ROUTE, 'category': 'browse'}
    if plugin_class.fastapi_apps != [expected_app]:
        raise RuntimeError('runtime-report FastAPI registration metadata is invalid')
    if plugin_class.external_views != [expected_view]:
        raise RuntimeError('runtime-report external-view metadata is invalid')
    registered_paths: set[str] = set()
    for route in report_app.routes:
        path = getattr(route, 'path', None)
        if isinstance(path, str):
            registered_paths.add(path)
    missing = {'/', '/health', '/initialize', '/status/{operation_id}', '/result/{operation_id}', '/cancel/{operation_id}', '/task-timeline'} - registered_paths
    if missing:
        raise RuntimeError('runtime-report FastAPI application is missing required routes: ' + ', '.join(sorted(missing)))

class AirflowRuntimeReportPlugin(AirflowPlugin):
    name = PLUGIN_NAME
    fastapi_apps: ClassVar[list[dict[str, object]]] = [{'app': report_app, 'url_prefix': PLUGIN_URL_PREFIX, 'name': 'Airflow Runtime Report Server'}]
    external_views: ClassVar[list[dict[str, object]]] = [{'name': PLUGIN_DISPLAY_NAME, 'href': _external_view_href(), 'destination': 'nav', 'url_route': PLUGIN_ROUTE, 'category': 'browse'}]

    @classmethod
    def on_load(cls, *args: object, **kwargs: object) -> None:
        del args, kwargs
        _validate_plugin_registration(cls)
        LOG.info('Loaded Airflow Runtime Report release=%s ui_path=/plugin/%s mount_path=%s/', PLUGIN_RELEASE, PLUGIN_ROUTE, PLUGIN_URL_PREFIX)
