# SPDX-License-Identifier: Apache-2.0
"""Bounded Airflow 3 REST API v2 client."""

from __future__ import annotations

from .api_connection import (
    RequestApiCredential,
    api_url_candidate,
    normalized_api_netloc,
    normalized_api_path,
    split_api_url,
    validate_api_origin,
    validate_full_url_connection_fields,
    validated_api_base_url,
)
from .api_pagination import (
    page_complete,
    page_window_complete,
    pagination_request_limit,
    record_page,
    remember_page,
    valid_page_members,
    validated_page_total,
    validated_row_limit,
)
from .configuration_errors import ApiError, fail, size_text
from .configuration_security import (
    absolute_path_without_resolving,
    canonical_query,
    query_pairs,
    read_bounded_regular_file,
    redact_secret_text,
    request_fingerprint,
    safe_problem_detail_bytes,
)
from .api_contract import API_PREFIX, API_VERSION
from .models import ApiStats, Config
from .preamble import (
    LOG,
    MAX_CA_BUNDLE_BYTES,
    AirflowFailException,
    Any,
    Connection,
    HTTPAdapter,
    Mapping,
    NoReturn,
    OrderedDict,
    Path,
    Retry,
    Sequence,
    cast,
    conf,
    copy,
    dataclass,
    field,
    hashlib,
    json,
    os,
    re,
    requests,
    tempfile,
    time,
    urlsplit,
    urlunsplit,
)


@dataclass(slots=True)
class ApiClient:
    """Provide bounded, authenticated access to the Airflow REST API v2."""

    config: Config
    session: requests.Session
    stats: ApiStats = field(default_factory=ApiStats)
    request_credential: RequestApiCredential | None = None
    _connection: Connection | None = None
    _base_url: str | None = None
    _token: str | None = None
    request_deadline: float | None = None
    request_limit: int | None = None
    response_byte_limit: int | None = None
    _api_validated: bool = False
    _tls_verify: bool | str | None = None
    _tls_verify_source: str | None = None
    _tls_snapshot_dir: tempfile.TemporaryDirectory[str] | None = None
    _small_cache: OrderedDict[str, tuple[dict[str, Any], int]] = field(
        default_factory=OrderedDict
    )

    @classmethod
    def create(
        cls,
        config: Config,
        request_credential: RequestApiCredential | None = None,
    ) -> "ApiClient":
        """Create an API client with bounded retry and transport settings."""
        retry = Retry(
            total=config.api_retries,
            connect=config.api_retries,
            read=config.api_retries,
            status=config.api_retries,
            other=0,
            backoff_factor=config.api_backoff,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset({"GET"}),
            raise_on_status=False,
        )
        session = requests.Session()
        session.trust_env = config.api_trust_env
        adapter = HTTPAdapter(max_retries=retry)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        client = cls(
            config=config,
            session=session,
            request_credential=request_credential,
        )
        client.stats.environment_proxy_enabled = config.api_trust_env
        return client

    def validate_api_v2(self) -> None:
        """Validate the mandatory API v2 endpoint once without fallback."""
        if self._api_validated:
            return
        try:
            response, content = self._request(
                "GET", f"{API_PREFIX}/version", refresh_token=False
            )
            self._validate_v2_version_document(response, content)
        except (ApiError, AirflowFailException):
            self._api_validated = False
            raise
        self._api_validated = True
        self.stats.api_probe_status = "v2-validated"
        LOG.debug(
            "REPORT | API_CONTRACT | version=%s | status=%s",
            API_VERSION,
            self.stats.api_probe_status,
        )

    @staticmethod
    def _validate_v2_version_document(
        response: requests.Response, content: bytes
    ) -> None:
        """Require the documented Airflow v2 version JSON response shape."""
        payload = ApiClient._json_object(response, content, "Airflow API v2 version")
        version = payload.get("version")
        git_version = payload.get("git_version")
        if not isinstance(version, str) or not version.strip():
            fail("Airflow API v2 version response is missing non-empty 'version'")
        if not isinstance(git_version, str) or not git_version.strip():
            fail("Airflow API v2 version response is missing non-empty 'git_version'")
        match = re.match(r"^3\.(\d+)\.(\d+)", version.strip())
        if match is None or tuple(map(int, match.groups())) < (1, 7):
            fail("Airflow API v2 target must be Airflow 3.1.7+ within major version 3")

    def connection(self) -> Connection:
        """Load and cache the configured Airflow connection at task execution time."""
        if self._connection is None:
            self._connection = Connection.get(self.config.api_conn_id)
            extra = self._connection.extra_dejson or {}
            LOG.debug(
                "REPORT | API_CONNECTION | conn_id=%s | login_present=%s | token_present=%s | "
                "tls_options_present=%s",
                self._connection.conn_id,
                bool(self._connection.login),
                any(
                    bool(extra.get(key))
                    for key in ("bearer_token", "access_token", "token")
                ),
                any(
                    key in extra
                    for key in (
                        "verify",
                        "ca_cert",
                        "ca_bundle",
                        "ssl_ca_file",
                        "tls_ca_bundle",
                    )
                ),
            )
        return self._connection

    @staticmethod
    def _validated_base_url(connection: Connection) -> str:
        """Construct one unambiguous normalized API origin and optional prefix."""
        candidate, full_url_host = api_url_candidate(connection)
        parsed, hostname, port = split_api_url(candidate)
        validate_full_url_connection_fields(connection, parsed, port, full_url_host)
        validate_api_origin(parsed, hostname, port)
        path = normalized_api_path(parsed.path)
        netloc = normalized_api_netloc(hostname, port)
        return urlunsplit((parsed.scheme, netloc, path, "", ""))

    def base_url(self) -> str:
        """Return the cached validated API base URL."""
        if self._base_url is None:
            if self.request_credential is not None:
                self._base_url = validated_api_base_url(
                    self.request_credential.base_url
                )
            else:
                self._base_url = self._validated_base_url(self.connection())
            parsed = urlsplit(self._base_url)
            LOG.debug(
                "REPORT | API_BASE | scheme=%s | host=%s | path_present=%s | source=%s",
                parsed.scheme,
                parsed.hostname,
                bool(parsed.path),
                self.request_credential.source
                if self.request_credential is not None
                else "connection",
            )
        return self._base_url

    def enforce_transport_policy(self, mode: str) -> None:
        """Enforce HTTPS unless an explicit local exception is configured."""
        scheme = urlsplit(self.base_url()).scheme
        if scheme == "https":
            return
        if not self.config.allow_insecure_http_auth:
            fail(
                "API traffic requires HTTPS; set ALLOW_INSECURE_HTTP_AUTH=true "
                "only for an explicitly approved local exception"
            )
        self.stats.insecure_http_auth = True
        LOG.warning(
            "SECURITY WARNING: API traffic is using plaintext HTTP by explicit "
            "override auth_mode=%s",
            mode,
        )

    def _snapshot_ca_path(self, value: object, source: str) -> str:
        """Copy one verified CA bundle into a private immutable snapshot."""
        text = str(value or "").strip()
        if not text:
            fail(f"{source} must contain a non-empty CA bundle path")
        source_path = absolute_path_without_resolving(text, source)
        payload, _device, _inode = read_bounded_regular_file(
            source_path,
            MAX_CA_BUNDLE_BYTES,
            f"TLS CA bundle from {source}",
            verify_stable_content=True,
        )
        if not payload.strip():
            fail(f"TLS CA bundle from {source} is empty")
        if self._tls_snapshot_dir is None:
            self._tls_snapshot_dir = tempfile.TemporaryDirectory(
                prefix="airflow-runtime-report-ca-"
            )
        snapshot = Path(self._tls_snapshot_dir.name) / (
            "ca-" + hashlib.sha256(payload).hexdigest()[:16] + ".pem"
        )
        if not snapshot.exists():
            descriptor = os.open(
                snapshot,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
                0o600,
            )
            try:
                view = memoryview(payload)
                while view:
                    written = os.write(descriptor, view)
                    if written <= 0:
                        raise OSError("CA snapshot write made no forward progress")
                    view = view[written:]
                os.fsync(descriptor)
            except OSError as exc:
                raise AirflowFailException(
                    f"TLS CA snapshot creation failed: {redact_secret_text(exc, 300)}"
                ) from exc
            finally:
                os.close(descriptor)
        return str(snapshot)

    @staticmethod
    def _verify_boolean(value: object) -> bool | None:
        """Interpret a connection-extra value as an optional Boolean."""
        if isinstance(value, bool):
            return value
        if isinstance(value, int) and value in {0, 1}:
            return bool(value)
        normalized = str(value or "").strip().lower()
        if normalized in {"", "1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
        return None

    def _connection_ca_candidates(
        self, extra: Mapping[str, Any]
    ) -> tuple[list[tuple[str, str]], bool | None]:
        """Collect CA snapshots in declared precedence without choosing a winner."""
        candidates: list[tuple[str, str]] = []
        for key in ("ca_cert", "ca_bundle", "ssl_ca_file", "tls_ca_bundle"):
            if key in extra and extra.get(key) not in (None, ""):
                candidates.append(
                    (
                        key,
                        self._snapshot_ca_path(extra[key], f"connection extra {key!r}"),
                    )
                )

        verify_value = extra.get("verify") if "verify" in extra else None
        verify_boolean = (
            self._verify_boolean(verify_value) if "verify" in extra else None
        )
        if "verify" in extra and verify_boolean is None:
            candidates.append(
                (
                    "verify",
                    self._snapshot_ca_path(verify_value, "connection extra 'verify'"),
                )
            )
        return candidates, verify_boolean

    def _connection_tls_setting(self) -> tuple[bool | str | None, str | None]:
        """Resolve TLS settings after checking all explicit sources for conflicts."""
        if self.request_credential is not None:
            return None, None
        candidates, verify_boolean = self._connection_ca_candidates(
            self.connection().extra_dejson or {}
        )

        distinct_paths = {path for _, path in candidates}
        if len(distinct_paths) > 1:
            sources = ", ".join(source for source, _ in candidates)
            fail(f"conflicting TLS CA bundle paths configured in {sources}")
        if verify_boolean is False and candidates:
            fail(
                "connection TLS configuration conflicts: verify=false with a CA bundle"
            )
        if candidates:
            sources = ",".join(source for source, _ in candidates)
            return candidates[0][1], f"connection-extra:{sources}"
        if verify_boolean is not None:
            return verify_boolean, "connection-extra:verify"
        return None, None

    def _airflow_api_ssl_cert(self) -> str | None:
        """Resolve the Airflow API CA bundle setting when configured."""
        value = str(conf.get("api", "ssl_cert", fallback="") or "").strip()
        if not value:
            return None
        return self._snapshot_ca_path(value, "Airflow [api] ssl_cert")

    def _resolved_tls_setting(self) -> tuple[bool | str, str]:
        """Resolve the final TLS verification value and provenance."""
        explicit, source = self._connection_tls_setting()
        if explicit is False:
            return False, source or "connection-extra:verify"
        if isinstance(explicit, str):
            return explicit, source or "connection-extra:ca-bundle"

        airflow_cert = self._airflow_api_ssl_cert()
        if airflow_cert:
            return airflow_cert, "airflow-config:[api] ssl_cert"
        return True, source or "system-trust-store"

    def verify_setting(self) -> bool | str:
        """Return the cached Requests TLS verification setting."""
        if self._tls_verify is not None:
            return self._tls_verify
        verified, source = self._resolved_tls_setting()
        if verified is False:
            if not self.config.allow_insecure_tls:
                fail(
                    "TLS verification is disabled; set ALLOW_INSECURE_TLS=true "
                    "only for an explicitly approved exception"
                )
            self.stats.insecure_tls = True
            LOG.warning(
                "SECURITY WARNING: API TLS certificate verification is disabled "
                "by explicit override"
            )
        self._tls_verify = verified
        self._tls_verify_source = source
        LOG.debug(
            "REPORT | API_TLS | mode=%s | source=%s",
            "disabled"
            if verified is False
            else ("ca-bundle" if isinstance(verified, str) else "system-store"),
            source,
        )
        return verified

    def _tls_failure_message(
        self, method: str, endpoint: str, exc: requests.exceptions.SSLError
    ) -> str:
        """Build an actionable, redacted TLS verification failure message."""
        source = self._tls_verify_source or "unresolved"
        if self._tls_verify is True:
            remediation = (
                "configure a readable PEM CA bundle in connection extra 'ca_cert' "
                "or configure Airflow [api] ssl_cert for the self-signed API certificate"
            )
        else:
            remediation = (
                "verify that the configured PEM bundle contains the issuing CA or "
                "self-signed server certificate and that the URL hostname matches "
                "the certificate SAN"
            )
        return (
            f"{method} {endpoint} TLS certificate verification failed "
            f"(trust_source={source}); {remediation}: "
            f"{redact_secret_text(exc, 240)}"
        )

    def auth_mode(self) -> str:
        """Resolve the effective API authentication mode."""
        if self.request_credential is not None:
            return "bearer"
        if self.config.auth_mode != "auto":
            return self.config.auth_mode
        connection = self.connection()
        extra = connection.extra_dejson or {}
        if any(
            str(extra.get(key) or "").strip()
            for key in ("bearer_token", "access_token", "token")
        ):
            return "bearer"
        if connection.login and connection.password:
            return "password_token"
        return "none"

    def bearer(self) -> str:
        """Return the configured bearer token or fail closed."""
        if self.request_credential is not None:
            return self.request_credential.bearer_token
        extra = self.connection().extra_dejson or {}
        for key in ("bearer_token", "access_token", "token"):
            value = str(extra.get(key) or "").strip()
            if value:
                return value
        fail("bearer authentication requires a token in connection extra")

    def password_token(self) -> str:
        """Acquire and cache an Airflow password-token credential."""
        if self._token:
            return self._token
        connection = self.connection()
        if not connection.login or not connection.password:
            fail("password_token authentication requires connection login and password")
        self.enforce_transport_policy("password_token")
        body = {"username": connection.login, "password": connection.password}
        provider_key = str(
            (connection.extra_dejson or {}).get("provider_key") or ""
        ).strip()
        if provider_key:
            body["provider_key"] = provider_key
        response, content = self._request(
            "POST", self.config.token_endpoint, body=body, use_auth=False
        )
        payload = self._json_object(response, content, "token response")
        token = str(payload.get("access_token") or "").strip()
        if not token:
            fail("token response did not contain access_token")
        self._token = token
        return token

    @staticmethod
    def _json_object(
        response: requests.Response, content: bytes, label: str
    ) -> dict[str, Any]:
        """Decode one response as a JSON object and close the response."""
        try:
            try:
                payload = json.loads(content)
            except (UnicodeDecodeError, ValueError) as exc:
                raise AirflowFailException(f"{label} returned invalid JSON") from exc
            if not isinstance(payload, dict):
                fail(f"{label} returned a non-object JSON payload")
            return payload
        finally:
            ApiClient._close_response(response)

    def _auth_context(
        self, use_auth: bool
    ) -> tuple[dict[str, str], str, tuple[str, str] | None]:
        """Build headers and optional basic credentials for one request."""
        headers = {"Accept": "application/json"}
        mode = self.auth_mode() if use_auth else "none"
        basic_auth: tuple[str, str] | None = None
        if mode == "password_token":
            headers["Authorization"] = f"Bearer {self.password_token()}"
        elif mode == "bearer":
            headers["Authorization"] = f"Bearer {self.bearer()}"
        elif mode == "basic":
            connection = self.connection()
            if not connection.login or not connection.password:
                fail("basic authentication requires login/password")
            basic_auth = (connection.login, connection.password)
        elif mode != "none":
            fail(f"unsupported authentication mode {mode!r}")
        self.enforce_transport_policy(mode)
        return headers, mode, basic_auth

    def _response_limit_failure(
        self, endpoint: str, response: requests.Response | None = None
    ) -> NoReturn:
        """Record and raise an API response-size failure."""
        self.stats.response_byte_limit_hits += 1
        if response is not None:
            close = getattr(response, "close", None)
            if callable(close):
                close()
        raise AirflowFailException(
            f"API response exceeded byte budget endpoint={endpoint} "
            f"limit=({size_text(self.config.max_response_bytes)})"
        )

    def _response_byte_budget(self) -> int:
        """Keep an optional multi-request operation inside its remaining bytes."""
        limit = self.config.max_response_bytes
        if self.response_byte_limit is not None:
            limit = min(limit, max(0, self.response_byte_limit - self.stats.response_bytes))
        return limit

    def _stream_response_content(
        self, response: requests.Response, endpoint: str
    ) -> bytes:
        """Read one bounded response into a single growable byte buffer."""
        content = bytearray()
        try:
            for chunk in response.iter_content(chunk_size=64 * 1024):
                if self.request_deadline is not None:
                    self._request_timeout(True)
                if not chunk:
                    continue
                if len(content) + len(chunk) > self._response_byte_budget():
                    self._response_limit_failure(endpoint, response)
                content.extend(chunk)
        except TimeoutError:
            self._close_response(response)
            raise
        except requests.RequestException as exc:
            self._close_response(response)
            raise AirflowFailException(
                f"API response stream failed endpoint={endpoint}: "
                f"{redact_secret_text(exc, 300)}"
            ) from exc
        return bytes(content)

    def _bounded_content(self, response: requests.Response, endpoint: str) -> bytes:
        """Read response content while enforcing the configured byte limit."""
        headers = getattr(response, "headers", {}) or {}
        length_text = str(headers.get("Content-Length") or "").strip()
        if length_text.isdigit() and int(length_text) > self._response_byte_budget():
            self._response_limit_failure(endpoint, response)
        if hasattr(response, "iter_content"):
            return self._stream_response_content(response, endpoint)
        content = bytes(getattr(response, "content", b"") or b"")
        if len(content) > self._response_byte_budget():
            self._response_limit_failure(endpoint, response)
        return content

    @staticmethod
    def _operation_name(endpoint: str, pairs: Sequence[tuple[str, object]]) -> str:
        """Classify an API request for summarized operator logging."""
        if endpoint.endswith("/auth/token") or endpoint == "/auth/token":
            return "auth_token"
        if endpoint.endswith("/version"):
            return "version"
        if endpoint.endswith("/dags/~/dagRuns"):
            states = {str(value).lower() for key, value in pairs if key == "state"}
            return "active_runs" if states else "historical_runs"
        if endpoint.endswith("/dags"):
            return "dag_inventory"
        if endpoint.endswith("/details"):
            return "dag_details"
        if endpoint.endswith("/taskInstances"):
            return "task_instances"
        return "other"

    def _record_response(
        self,
        method: str,
        endpoint: str,
        pairs: Sequence[tuple[str, object]],
        response: requests.Response,
        started: float,
        size: int,
    ) -> None:
        """Record bounded request telemetry and a redacted debug record."""
        elapsed = int((time.monotonic() - started) * 1000)
        fingerprint = request_fingerprint(method, endpoint, pairs)
        self.stats.requests += 1
        self.stats.elapsed_ms += elapsed
        self.stats.response_bytes += size
        query = redact_secret_text(canonical_query(pairs), 300) or "-"
        operation = self._operation_name(endpoint, pairs)
        status_class = (
            f"{response.status_code // 100}xx"
            if 100 <= response.status_code <= 599
            else "other"
        )
        self.stats.response_status_classes[status_class] += 1
        self.stats.operation_requests[operation] += 1
        LOG.debug(
            "REPORT | API_DETAIL | operation=%s | method=%s | endpoint=%s | "
            "status=%s | elapsed_ms=%s | size=%s | query=%s | fingerprint=%s",
            operation,
            method,
            endpoint,
            response.status_code,
            elapsed,
            size_text(size),
            query,
            fingerprint[:16],
        )

    def _request_timeout(self, use_auth: bool) -> float:
        """Respect an optional per-operation deadline without changing defaults."""
        configured = self.config.api_timeout if use_auth else self.config.token_timeout
        if self.request_deadline is None:
            return float(configured)
        remaining = self.request_deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("Airflow API operation deadline exceeded")
        return min(float(configured), remaining)

    def _send_once(
        self,
        method: str,
        path: str,
        pairs: Sequence[tuple[str, object]],
        body: Mapping[str, Any] | None,
        headers: Mapping[str, str],
        basic_auth: tuple[str, str] | None,
        use_auth: bool,
    ) -> requests.Response:
        """Send one non-redirecting streamed HTTP request."""
        return self.session.request(
            method,
            self.base_url() + path,
            params=cast(Any, list(pairs)),
            json=dict(body) if body is not None else None,
            headers=dict(headers),
            auth=basic_auth,
            timeout=self._request_timeout(use_auth),
            verify=self.verify_setting(),
            stream=True,
            allow_redirects=False,
        )

    @staticmethod
    def _close_response(response: requests.Response) -> None:
        """Close a Requests response when the object supports closing."""
        close = getattr(response, "close", None)
        if callable(close):
            close()

    def _request_retry_delay(self, attempt: int) -> None:
        """Apply exponential delay between explicit token-request retries."""
        time.sleep(self.config.api_backoff * (2**attempt))

    def _send_with_retries(
        self,
        method: str,
        endpoint: str,
        path: str,
        pairs: Sequence[tuple[str, object]],
        body: Mapping[str, Any] | None,
        headers: Mapping[str, str],
        basic_auth: tuple[str, str] | None,
        use_auth: bool,
    ) -> requests.Response:
        """Send a request with the configured bounded retry policy."""
        attempts = 1 + (
            self.config.token_retries if method == "POST" and not use_auth else 0
        )
        for attempt in range(attempts):
            try:
                response = self._send_once(
                    method, path, pairs, body, headers, basic_auth, use_auth
                )
            except requests.exceptions.SSLError as exc:
                raise AirflowFailException(
                    self._tls_failure_message(method, endpoint, exc)
                ) from exc
            except requests.RequestException as exc:
                if attempt + 1 >= attempts:
                    raise AirflowFailException(
                        f"{method} {endpoint} request failed: "
                        f"{redact_secret_text(exc, 300)}"
                    ) from exc
                self._request_retry_delay(attempt)
                continue
            retryable = response.status_code in {429, 500, 502, 503, 504}
            if not retryable or attempt + 1 >= attempts:
                return response
            self._close_response(response)
            self._request_retry_delay(attempt)
        raise AirflowFailException(f"{method} {endpoint} exhausted request attempts")

    def _checked_response(
        self,
        response: requests.Response,
        method: str,
        endpoint: str,
        pairs: Sequence[tuple[str, object]],
        body: Mapping[str, Any] | None,
        mode: str,
        use_auth: bool,
        refresh_token: bool,
        started: float,
    ) -> tuple[requests.Response, bytes]:
        """Read, account for, refresh, and validate one HTTP response."""
        content = self._bounded_content(response, endpoint)
        self._record_response(method, endpoint, pairs, response, started, len(content))
        should_refresh = (
            use_auth
            and mode == "password_token"
            and response.status_code == 401
            and refresh_token
        )
        if should_refresh:
            self._token = None
            self._close_response(response)
            return self._request(
                method,
                endpoint,
                pairs=pairs,
                body=body,
                use_auth=True,
                refresh_token=False,
            )
        if 300 <= response.status_code < 400:
            self._close_response(response)
            raise ApiError(
                method,
                endpoint,
                response.status_code,
                "HTTP redirects are prohibited for Airflow API requests",
                "redirect_prohibited",
            )
        if response.status_code >= 400:
            try:
                code, detail = safe_problem_detail_bytes(content, response.reason)
            finally:
                self._close_response(response)
            raise ApiError(method, endpoint, response.status_code, detail, code)
        return response, content

    def _request(
        self,
        method: str,
        endpoint: str,
        *,
        pairs: Sequence[tuple[str, object]] = (),
        body: Mapping[str, Any] | None = None,
        use_auth: bool = True,
        refresh_token: bool = True,
    ) -> tuple[requests.Response, bytes]:
        """Execute one authenticated API request and return bounded content."""
        headers, mode, basic_auth = self._auth_context(use_auth)
        if self.request_limit is not None and self.stats.requests >= self.request_limit:
            raise ValueError("Airflow API operation request limit exceeded")
        if (
            self.response_byte_limit is not None
            and self.stats.response_bytes >= self.response_byte_limit
        ):
            raise ValueError("Airflow API operation byte limit exceeded")
        path = endpoint if endpoint.startswith("/") else "/" + endpoint
        started = time.monotonic()
        response = self._send_with_retries(
            method, endpoint, path, pairs, body, headers, basic_auth, use_auth
        )
        return self._checked_response(
            response,
            method,
            endpoint,
            pairs,
            body,
            mode,
            use_auth,
            refresh_token,
            started,
        )

    @staticmethod
    def _bounded_json_size(payload: Mapping[str, Any], limit: int) -> int | None:
        """Return compact JSON byte size without materializing a full JSON buffer."""
        total = 0
        encoder = json.JSONEncoder(separators=(",", ":"), default=str)
        for chunk in encoder.iterencode(payload):
            total += len(chunk.encode("utf-8"))
            if total > limit:
                return None
        return total

    def _cache_put(self, fingerprint: str, payload: dict[str, Any]) -> None:
        """Store a bounded deep copy in the small response cache."""
        if self.config.max_cache_entries <= 0 or self.config.max_cache_bytes <= 0:
            return
        size = self._bounded_json_size(payload, self.config.max_cache_bytes)
        if size is None:
            return
        stored = copy.deepcopy(payload)
        while self._small_cache and (
            len(self._small_cache) >= self.config.max_cache_entries
            or self.stats.cache_bytes + size > self.config.max_cache_bytes
        ):
            _, (_, removed) = self._small_cache.popitem(last=False)
            self.stats.cache_bytes -= removed
        self._small_cache[fingerprint] = (stored, size)
        self.stats.cache_bytes += size
        self.stats.cache_entries = len(self._small_cache)

    def get(
        self,
        resource: str,
        query: Mapping[str, object] | Sequence[tuple[str, object]] | None = None,
        *,
        cache: bool = True,
    ) -> dict[str, Any]:
        """Fetch one JSON object through the mandatory API v2 contract."""
        self.validate_api_v2()
        endpoint = f"{API_PREFIX}/{resource.lstrip('/')}"
        pairs = query_pairs(query)
        fingerprint = request_fingerprint("GET", endpoint, pairs)
        if cache and fingerprint in self._small_cache:
            self.stats.cache_hits += 1
            self.stats.duplicate_requests_prevented += 1
            payload, size = self._small_cache.pop(fingerprint)
            self._small_cache[fingerprint] = (payload, size)
            return copy.deepcopy(payload)
        response, content = self._request("GET", endpoint, pairs=pairs)
        payload = self._json_object(response, content, endpoint)
        if cache:
            self._cache_put(fingerprint, payload)
        if resource == "dags/~/dagRuns":
            self.stats.global_run_calls += 1
        elif resource.endswith("/dagRuns"):
            self.stats.per_dag_run_calls += 1
        elif resource.endswith("/details"):
            self.stats.dag_detail_calls += 1
        elif resource.endswith("/taskInstances"):
            self.stats.task_instance_calls += 1
        return payload

    def close(self) -> None:
        """Close network and private TLS-snapshot resources."""
        try:
            self.session.close()
        finally:
            if self._tls_snapshot_dir is not None:
                self._tls_snapshot_dir.cleanup()
                self._tls_snapshot_dir = None

    def _paginate(
        self,
        resource: str,
        collection_key: str,
        query: Mapping[str, object] | Sequence[tuple[str, object]] | None,
        *,
        row_limit: int | None,
    ) -> tuple[list[dict[str, Any]], int, bool]:
        """Run one bounded, fail-closed offset-pagination state machine."""
        row_limit = validated_row_limit(self.config, resource, row_limit)
        if row_limit == 0:
            return [], 0, True

        base = query_pairs(query)
        rows: list[dict[str, Any]] = []
        offset = 0
        seen_pages: set[str] = set()
        expected_total: int | None = None
        mode = "window" if row_limit is not None else "complete"

        for page_number in range(self.config.max_pages):
            if row_limit is not None and len(rows) >= row_limit:
                total = expected_total if expected_total is not None else len(rows)
                return rows, total, len(rows) >= total
            global_remaining, request_limit = pagination_request_limit(
                self.config, self.stats, resource, rows, row_limit
            )
            payload = self.get(
                resource,
                [*base, ("limit", request_limit), ("offset", offset)],
                cache=False,
            )
            valid, chunk, rejected = valid_page_members(
                self.stats,
                payload,
                collection_key,
                resource,
                global_remaining,
            )
            remember_page(self.config, self.stats, chunk, seen_pages, resource)
            rows.extend(valid)
            record_page(self.stats, valid)
            offset += len(chunk)
            total = validated_page_total(
                self.stats, payload, resource, offset, expected_total
            )
            expected_total = total
            complete = offset == total
            stop = (
                page_complete(
                    self.stats,
                    chunk,
                    request_limit,
                    offset,
                    total,
                    resource,
                )
                if row_limit is None
                else page_window_complete(
                    self.stats,
                    chunk,
                    request_limit,
                    offset,
                    total,
                    len(rows),
                    row_limit,
                    resource,
                )
            )
            LOG.debug(
                "REPORT | PAGE | mode=%s | resource=%s | page=%s | "
                "accepted=%s/%s | rejected=%s | complete=%s | cap=%s",
                mode,
                resource,
                page_number + 1,
                len(rows),
                total,
                rejected,
                complete,
                row_limit if row_limit is not None else self.config.max_rows,
            )
            if stop:
                return rows, total, complete

        self.stats.mark_incomplete(f"{resource}:max_pages")
        fail(f"{resource} exceeded max_pages={self.config.max_pages}")

    def page_window(
        self,
        resource: str,
        collection_key: str,
        row_limit: int,
        query: Mapping[str, object] | Sequence[tuple[str, object]] | None = None,
    ) -> tuple[list[dict[str, Any]], int, bool]:
        """Collect a bounded prefix of one paginated resource."""
        return ApiClient._paginate(
            self,
            resource,
            collection_key,
            query,
            row_limit=row_limit,
        )

    def page(
        self,
        resource: str,
        collection_key: str,
        query: Mapping[str, object] | Sequence[tuple[str, object]] | None = None,
    ) -> list[dict[str, Any]]:
        """Collect one complete bounded paginated resource."""
        rows, _total, _complete = ApiClient._paginate(
            self,
            resource,
            collection_key,
            query,
            row_limit=None,
        )
        return rows
