# SPDX-License-Identifier: Apache-2.0
"""Bounded, read-only task and attempt data for a DAG run or complete DAG-lane run scope.

No credentials, executor metadata, caches or materialized report partitions are
included in this contract. REST history is an unpaginated collection; the current
instance list uses the existing client's complete offset pagination.
"""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime, timezone
from time import monotonic
from typing import TYPE_CHECKING, Any, Literal, TypedDict
from urllib.parse import quote

MAX_RUNS = 64
MAX_API_CALLS = 512
MAX_API_BYTES = 16 * 1024 * 1024
MAX_TASKS = 5000
MAX_ATTEMPTS = 20000
MAX_HISTORY_CALLS = 256
TIMELINE_SECONDS = 30
TASK_STATES = frozenset(
    "success failed running queued scheduled up_for_retry up_for_reschedule "
    "deferred skipped upstream_failed restarting removed none awaiting_input no_status".split()
)

if TYPE_CHECKING:
    from .api import ApiClient


class TaskAttempt(TypedDict):
    """An actual execution interval or an authoritative timestamp marker."""

    tryNumber: int
    state: str
    start: str | None
    end: str | None
    marker: str | None


class TimelineTask(TypedDict):
    """One task instance; mapped instances always remain separate."""

    taskId: str
    mapIndex: int
    current: TaskAttempt
    attempts: list[TaskAttempt]


class TaskTimelinePayload(TypedDict):
    """Complete task identity set and explicitly qualified attempt coverage."""

    schema: Literal["task-timeline-v2"]
    dagId: str
    dagRunId: str
    complete: bool
    historyComplete: bool
    tasks: list[TimelineTask]


class DagTaskTimelinePayload(TypedDict):
    """Every requested run is enumerated before this payload is published."""

    schema: Literal["dag-task-timeline-v2"]
    dagId: str
    complete: bool
    runs: list[TaskTimelinePayload]


@dataclass(slots=True)
class TimelineBudget:
    """One shared task, attempt, history and time budget for a DAG expansion."""

    deadline: float = field(default_factory=lambda: monotonic() + TIMELINE_SECONDS)
    tasks: int = 0
    attempts: int = 0
    history_calls: int = 0


def validate_timeline_run_ids(run_ids: list[str]) -> list[str]:
    """Reject ambiguous or excessive scope before making any upstream request."""
    if not isinstance(run_ids, list) or not 1 <= len(run_ids) <= MAX_RUNS:
        raise ValueError('Invalid task timeline run scope')
    validated = [validate_timeline_identifier(run, 1024) for run in run_ids]
    if len(set(validated)) != len(validated):
        raise ValueError('Duplicate task timeline run identity')
    return sorted(validated)


def collect_dag_task_timeline(
    client: ApiClient, dag_id: str, run_ids: list[str]
) -> DagTaskTimelinePayload:
    """Collect a complete authorized run set using one shared bounded client."""
    validate_timeline_identifier(dag_id, 250)
    ids = validate_timeline_run_ids(run_ids)
    budget = TimelineBudget()
    runs = [collect_task_timeline(client, dag_id, run, budget=budget) for run in ids]
    _check_timeline_deadline(budget.deadline)
    return {'schema': 'dag-task-timeline-v2', 'dagId': dag_id, 'complete': True, 'runs': runs}


def validate_timeline_identifier(value: str, maximum: int) -> str:
    """Reject collection wildcards, path traversal and unbounded identifiers."""
    if (
        not isinstance(value, str)
        or not value
        or len(value) > maximum
        or value in {"~", ".", ".."}
        or any(ord(c) < 32 or ord(c) == 127 for c in value)
    ):
        raise ValueError('Invalid task timeline identity')
    return value


def _timeline_integer(value: object, minimum: int) -> int:
    if (
        isinstance(value, bool)
        or not isinstance(value, int)
        or not minimum <= value <= 2147483647
    ):
        raise ValueError('Invalid task timeline integer')
    return value


def _timeline_timestamp(value: object) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or len(value) > 64:
        raise ValueError('Invalid task timeline timestamp')
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError('Task timeline timestamps require an offset')
    return parsed.astimezone(timezone.utc).isoformat()


def _instance_identity(
    row: Mapping[str, Any], dag_id: str, run_id: str
) -> tuple[str, int]:
    if row.get('dag_id') != dag_id or row.get('dag_run_id') != run_id:
        raise ValueError('Task timeline identity mismatch')
    return (
        validate_timeline_identifier(row.get("task_id"), 250),
        _timeline_integer(row.get("map_index"), -1),
    )


def _attempt(row: Mapping[str, Any]) -> TaskAttempt:
    number = _timeline_integer(row.get('try_number'), 0)
    state = row.get('state')
    state = 'none' if state is None else state
    state = state if isinstance(state, str) and state in TASK_STATES else 'unknown'
    start = _timeline_timestamp(row.get('start_date'))
    end = _timeline_timestamp(row.get('end_date'))
    if end is not None and (start is None or end < start):
        raise ValueError('Invalid task execution interval')
    marker_field = {'queued': 'queued_when', 'scheduled': 'scheduled_when'}.get(state)
    marker = (
        _timeline_timestamp(row.get(marker_field))
        if marker_field and start is None
        else None
    )
    return {
        "tryNumber": number,
        "state": state,
        "start": start,
        "end": end,
        "marker": marker,
    }


def _check_timeline_deadline(deadline: float) -> None:
    if monotonic() >= deadline:
        raise TimeoutError('Task timeline request deadline exceeded')


def _history_attempts(
    client: ApiClient,
    resource: str,
    current: Mapping[str, Any],
    identity: tuple[str, int],
    dag_id: str,
    run_id: str,
) -> tuple[list[TaskAttempt], bool]:
    """Prefer authoritative history; qualify only explicitly unavailable routes."""
    task_id, map_index = identity
    task_path = quote(task_id, safe='')
    suffix = (
        f"/{task_path}/{map_index}/tries"
        if map_index >= 0
        else f"/{task_path}/tries"
    )
    try:
        payload = client.get(resource + suffix, cache=False)
    except Exception as exc:
        if getattr(exc, 'status', None) not in {404, 405, 501}:
            raise
        return [_attempt(current)], False
    history, total = payload.get('task_instances'), payload.get('total_entries')
    if (
        not isinstance(history, list)
        or isinstance(total, bool)
        or not isinstance(total, int)
        or total != len(history)
        or total > MAX_ATTEMPTS
    ):
        raise ValueError('Incomplete task attempt history')
    by_try: dict[int, TaskAttempt] = {}
    for row in history:
        if (
            not isinstance(row, Mapping)
            or _instance_identity(row, dag_id, run_id) != identity
        ):
            raise ValueError('Task attempt identity mismatch')
        attempt = _attempt(row)
        previous = by_try.get(attempt['tryNumber'])
        if previous is not None and previous != attempt:
            raise ValueError('Conflicting task attempt records')
        by_try[attempt['tryNumber']] = attempt
    current_attempt = _attempt(current)
    by_try.setdefault(current_attempt['tryNumber'], current_attempt)
    numbers = set(by_try)
    last = max(numbers, default=0)
    complete = last <= MAX_ATTEMPTS and all(
        n in numbers for n in range(1, min(last, MAX_ATTEMPTS) + 1)
    )
    return [by_try[n] for n in sorted(by_try)], complete


def collect_task_timeline(
    client: ApiClient, dag_id: str, run_id: str, *, budget: TimelineBudget | None = None
) -> TaskTimelinePayload:
    """Return a complete bounded task list, with only authoritative intervals."""
    budget = budget if budget is not None else TimelineBudget()
    deadline = budget.deadline
    validate_timeline_identifier(dag_id, 250)
    validate_timeline_identifier(run_id, 1024)
    resource = f'dags/{quote(dag_id, safe="")}/dagRuns/{quote(run_id, safe="")}'
    _check_timeline_deadline(deadline)
    run = client.get(resource, cache=False)
    if run.get('dag_id') != dag_id or run.get('dag_run_id') != run_id:
        raise ValueError('DAG run identity mismatch')
    resource += '/taskInstances'
    _check_timeline_deadline(deadline)
    rows = client.page(resource, 'task_instances', [("order_by", "id")])
    if getattr(getattr(client, 'stats', None), 'incomplete_reasons', ()):
        raise ValueError('Incomplete task instance list')
    budget.tasks += len(rows)
    if budget.tasks > MAX_TASKS:
        raise ValueError('Task timeline row limit exceeded')
    tasks: list[TimelineTask] = []
    seen: set[tuple[str, int]] = set()
    history_complete = True
    for row in rows:
        _check_timeline_deadline(deadline)
        if not isinstance(row, Mapping):
            raise ValueError('Invalid task instance record')
        identity = _instance_identity(row, dag_id, run_id)
        if identity in seen:
            raise ValueError('Duplicate task instance identity')
        seen.add(identity)
        current = _attempt(row)
        complete = True
        needs_history = current["tryNumber"] > 1 or current["state"] in {
            "up_for_retry", "up_for_reschedule", "deferred", "restarting"
        }
        if needs_history:
            budget.history_calls += 1
            if budget.history_calls > MAX_HISTORY_CALLS:
                raise ValueError('Task timeline history request limit exceeded')
            attempts, complete = _history_attempts(
                client, resource, row, identity, dag_id, run_id
            )
        else:
            attempts = [current]
        budget.attempts += len(attempts)
        if budget.attempts > MAX_ATTEMPTS:
            raise ValueError('Task timeline attempt limit exceeded')
        history_complete = history_complete and complete
        tasks.append(
            {"taskId": identity[0], "mapIndex": identity[1], "current": current, "attempts": attempts}
        )
    _check_timeline_deadline(deadline)
    tasks.sort(key=lambda item: (item['taskId'], item['mapIndex']))
    return {
        "schema": "task-timeline-v2",
        "dagId": dag_id,
        "dagRunId": run_id,
        "complete": True,
        "historyComplete": history_complete,
        "tasks": tasks,
    }
