# SPDX-License-Identifier: Apache-2.0
"""Dynamic 10-day capacity planning and effective-window reconciliation."""

from __future__ import annotations

from .calendar_windows import calendar_intervals
from .configuration_windows import nice_bucket
from .models import CapacityPlan, Config, DagInfo, Run
from .preamble import (
    MAX_BUCKETS,
    MAX_TOTAL_TIMELINE_ITEMS_HARD,
    Mapping,
    Sequence,
    cast,
    math,
    pendulum,
    replace,
)
from .scheduling import future_demand


def _history_options(
    config: Config,
) -> dict[int, tuple[pendulum.DateTime, pendulum.DateTime, tuple[str, ...]]]:
    """Return effective history windows keyed by retained calendar-day count."""
    if config.selected_days:
        values: dict[
            int, tuple[pendulum.DateTime, pendulum.DateTime, tuple[str, ...]]
        ] = {}
        for count in range(1, len(config.selected_days) + 1):
            selected = config.selected_days[-count:]
            start = cast(
                pendulum.DateTime, pendulum.parse(selected[0], tz=config.timezone)
            ).start_of("day")
            end = min(
                cast(
                    pendulum.DateTime,
                    pendulum.parse(selected[-1], tz=config.timezone),
                )
                .start_of("day")
                .add(days=1),
                config.history_end,
            )
            values[count] = start, end, selected
        return values
    intervals = calendar_intervals(config.history_start, config.history_end)
    return {
        count: (intervals[-count][0], config.history_end, ())
        for count in range(1, len(intervals) + 1)
    }


def _future_options(config: Config) -> dict[int, pendulum.DateTime | None]:
    """Return future end boundaries keyed by retained calendar-day count."""
    if not config.future_enabled or config.future_effective_end is None:
        return {0: None}
    values: dict[int, pendulum.DateTime | None] = {0: None}
    cursor = config.trigger_time.start_of("day")
    count = 0
    while cursor < config.future_effective_end:
        count += 1
        cursor = cursor.add(days=1)
        values[count] = min(cursor, config.future_effective_end)
    return values


def _history_count(
    runs: Sequence[Run],
    start: pendulum.DateTime,
    end: pendulum.DateTime,
    selected_days: Sequence[str],
) -> int:
    """Count rendered historical segments in one candidate history window."""
    selected = frozenset(selected_days)
    if selected:
        return sum(run.selected_day in selected for run in runs)
    return sum(
        (run.start == run.end and start <= run.start < end)
        or (run.end > start and run.start < end)
        for run in runs
    )


def _requested_history_days(config: Config) -> int:
    """Return the raw requested history calendar-day count."""
    if config.requested_selected_days:
        return len(config.requested_selected_days)
    return len(
        calendar_intervals(
            config.requested_history_start,
            config.requested_history_end,
        )
    )


def _requested_future_days(config: Config) -> int:
    """Return the raw requested future calendar-day count."""
    if not config.future_enabled or config.future_requested_end is None:
        return 0
    return len(calendar_intervals(config.trigger_time, config.future_requested_end))


def _candidate_score(
    history_days: int,
    future_days: int,
    requested_history_days: int,
    requested_future_days: int,
) -> tuple[float, float, int, int, int]:
    """Return the deterministic equal-ratio score for one candidate pair."""
    history_ratio = history_days / max(1, requested_history_days)
    future_ratio = future_days / max(1, requested_future_days)
    return (
        min(history_ratio, future_ratio),
        -abs(history_ratio - future_ratio),
        history_days + future_days,
        history_days,
        future_days,
    )


def _capacity_demand_tables(
    config: Config,
    dags: Mapping[str, DagInfo],
    collected_runs: Sequence[Run],
) -> tuple[
    dict[int, tuple[pendulum.DateTime, pendulum.DateTime, tuple[str, ...]]],
    dict[int, pendulum.DateTime | None],
    dict[int, int],
    dict[int, int],
    dict[int, int],
]:
    """Return history/future window options and their bounded item demand."""
    history_options = _history_options(config)
    future_options = _future_options(config)
    history_counts = {
        days: _history_count(collected_runs, start, end, selected)
        for days, (start, end, selected) in history_options.items()
    }
    future_counts: dict[int, int] = {0: 0}
    future_dag_counts: dict[int, int] = {0: 0}
    for days, end in future_options.items():
        if days == 0:
            continue
        count, dag_count = future_demand(
            config,
            dags,
            end,
            stop_after=config.max_future_occurrences,
        )
        future_counts[days] = count
        future_dag_counts[days] = dag_count
    return (
        history_options,
        future_options,
        history_counts,
        future_counts,
        future_dag_counts,
    )


def _feasible_history_days(config: Config, history_counts: Mapping[int, int]) -> int:
    """Return the largest history-day count that fits standalone item budgets."""
    feasible = [
        days
        for days, count in history_counts.items()
        if count <= config.max_rendered_runs and count <= MAX_TOTAL_TIMELINE_ITEMS_HARD
    ]
    return max(feasible, default=1)


def _select_capacity_days(
    config: Config,
    history_counts: Mapping[int, int],
    future_counts: Mapping[int, int],
    clamped_history_days: int,
    clamped_future_days: int,
) -> tuple[int, int]:
    """Select deterministic equal-ratio complete-day windows within all budgets."""
    if clamped_future_days == 0:
        return _feasible_history_days(config, history_counts), 0
    candidates: list[tuple[tuple[float, float, int, int, int], int, int]] = []
    for history_days, history_count in history_counts.items():
        for future_days, future_count in future_counts.items():
            if future_days == 0:
                continue
            if history_count > config.max_rendered_runs:
                continue
            if future_count > config.max_future_occurrences:
                continue
            if history_count + future_count > MAX_TOTAL_TIMELINE_ITEMS_HARD:
                continue
            score = _candidate_score(
                history_days,
                future_days,
                clamped_history_days,
                clamped_future_days,
            )
            candidates.append((score, history_days, future_days))
    if candidates:
        _, history_days, future_days = max(candidates)
        return history_days, future_days
    return _feasible_history_days(config, history_counts), 0


def _capacity_reasons(
    config: Config,
    *,
    chosen_history_days: int,
    chosen_future_days: int,
    clamped_history_days: int,
    clamped_future_days: int,
    historical_rendered: int,
    future_available: int,
    combined_available: int,
) -> tuple[str, ...]:
    """Return canonical capacity-recalculation reasons without duplicates."""
    reasons: list[str] = []
    if config.history_clamped:
        reasons.append("history day limit")
    if config.future_clamped:
        reasons.append("future day limit")
    if (
        chosen_history_days < clamped_history_days
        or historical_rendered > config.max_rendered_runs
    ):
        reasons.append("historical item budget")
    if chosen_future_days < clamped_future_days:
        if chosen_future_days == 0 and clamped_future_days:
            reasons.append("no complete future day fits")
        elif future_available > config.max_future_occurrences:
            reasons.append("future occurrence budget")
        else:
            reasons.append("combined timeline budget")
    if (
        combined_available > MAX_TOTAL_TIMELINE_ITEMS_HARD
        and "combined timeline budget" not in reasons
    ):
        reasons.append("combined timeline budget")
    return tuple(dict.fromkeys(reasons))


def _capacity_retention_ratio(
    chosen_history_days: int,
    chosen_future_days: int,
    requested_history_days: int,
    requested_future_days: int,
) -> float:
    """Return the retained equal-ratio fraction of the raw requested windows."""
    history_ratio = chosen_history_days / max(1, requested_history_days)
    if not requested_future_days:
        return history_ratio
    future_ratio = chosen_future_days / max(1, requested_future_days)
    return min(history_ratio, future_ratio)


def plan_capacity(
    config: Config,
    dags: Mapping[str, DagInfo],
    collected_runs: Sequence[Run],
) -> CapacityPlan:
    """Select the largest complete-day windows satisfying all item budgets."""
    (
        history_options,
        future_options,
        history_counts,
        future_counts,
        future_dag_counts,
    ) = _capacity_demand_tables(config, dags, collected_runs)
    clamped_history_days = max(history_options)
    clamped_future_days = max(future_options)
    chosen_history_days, chosen_future_days = _select_capacity_days(
        config,
        history_counts,
        future_counts,
        clamped_history_days,
        clamped_future_days,
    )
    history_start, history_end, _ = history_options[chosen_history_days]
    future_end = future_options[chosen_future_days]
    historical_available = history_counts[clamped_history_days]
    historical_rendered = history_counts[chosen_history_days]
    future_available = future_counts[clamped_future_days]
    future_rendered = future_counts[chosen_future_days]
    combined_available = historical_available + future_available
    combined_rendered = historical_rendered + future_rendered
    reasons = _capacity_reasons(
        config,
        chosen_history_days=chosen_history_days,
        chosen_future_days=chosen_future_days,
        clamped_history_days=clamped_history_days,
        clamped_future_days=clamped_future_days,
        historical_rendered=historical_rendered,
        future_available=future_available,
        combined_available=combined_available,
    )
    requested_history_days = _requested_history_days(config)
    requested_future_days = _requested_future_days(config)
    retention_ratio = _capacity_retention_ratio(
        chosen_history_days,
        chosen_future_days,
        requested_history_days,
        requested_future_days,
    )
    return CapacityPlan(
        requested_history_start=config.requested_history_start,
        requested_history_end=config.requested_history_end,
        effective_history_start=history_start,
        effective_history_end=history_end,
        requested_future_end=config.future_requested_end,
        effective_future_end=future_end,
        requested_history_days=requested_history_days,
        clamped_history_days=clamped_history_days,
        effective_history_days=chosen_history_days,
        requested_future_days=requested_future_days,
        clamped_future_days=clamped_future_days,
        effective_future_days=chosen_future_days,
        historical_available=historical_available,
        historical_rendered=historical_rendered,
        historical_omitted=max(0, historical_available - historical_rendered),
        future_available=future_available,
        future_rendered=future_rendered,
        future_omitted=max(0, future_available - future_rendered),
        combined_available=combined_available,
        combined_rendered=combined_rendered,
        retention_ratio=retention_ratio,
        recalculated=bool(reasons),
        reasons=reasons,
        configured_future_target=config.future_target_per_dag,
        effective_future_target=config.future_target_per_dag,
        future_target_met_dags=0,
        future_target_total_dags=future_dag_counts.get(chosen_future_days, 0),
    )


def apply_capacity_plan(config: Config, plan: CapacityPlan) -> Config:
    """Return configuration updated with the selected effective windows."""
    selected_days = (
        config.selected_days[-plan.effective_history_days :]
        if config.selected_days
        else ()
    )
    duration = (
        plan.effective_history_end - plan.effective_history_start
    ).total_seconds()
    bucket_seconds = (
        config.requested_bucket_seconds
        if math.ceil(duration / config.requested_bucket_seconds)
        <= config.max_html_buckets
        else nice_bucket(duration / config.max_html_buckets)
    )
    if math.ceil(duration / bucket_seconds) > MAX_BUCKETS:
        bucket_seconds = nice_bucket(duration / MAX_BUCKETS)
    return replace(
        config,
        history_start=plan.effective_history_start,
        history_end=plan.effective_history_end,
        history_clamped=config.history_clamped
        or plan.effective_history_days < plan.clamped_history_days,
        selected_days=selected_days,
        future_effective_end=plan.effective_future_end,
        future_clamped=config.future_clamped
        or plan.effective_future_days < plan.clamped_future_days,
        bucket_seconds=bucket_seconds,
        bucket_auto_scaled=bucket_seconds != config.requested_bucket_seconds,
    )


def trim_runs_to_config(runs: Sequence[Run], config: Config) -> tuple[Run, ...]:
    """Clip normalized segments to the effective history window and reindex them."""
    selected = frozenset(config.selected_days)
    retained: list[Run] = []
    for run in runs:
        if selected and run.selected_day not in selected:
            continue
        if run.start == run.end:
            if config.history_start <= run.start < config.history_end:
                retained.append(run)
            continue
        start = max(run.start, config.history_start)
        end = min(run.end, config.history_end)
        if end <= start:
            continue
        retained.append(replace(run, start=start, end=end))
    grouped: dict[str, list[Run]] = {}
    for run in retained:
        grouped.setdefault(run.source_run_id, []).append(run)
    normalized: list[Run] = []
    for source_id in sorted(grouped):
        rows = sorted(
            grouped[source_id],
            key=lambda row: (row.start, row.end, row.segment_index),
        )
        count = len(rows)
        normalized.extend(
            replace(row, segment_index=index, segment_count=count)
            for index, row in enumerate(rows, start=1)
        )
    return tuple(
        sorted(
            normalized,
            key=lambda row: (
                row.start,
                row.end,
                row.dag_id.casefold(),
                row.run_id,
                row.segment_index,
            ),
        )
    )
