# SPDX-License-Identifier: Apache-2.0
"""Canonical DAG-run normalization and selected-day segmentation."""

from __future__ import annotations

from typing import NamedTuple

from .api import ApiClient
from .configuration_errors import ApiError
from .configuration_values import dt_or_none, first_text, normalize_state, stable_id
from .configuration_windows import selected_day_intervals
from .models import Config, DagInfo, Run, TaskEnrichmentResult
from .normalization_records import run_key
from .preamble import (
    ACTIVE_RAW_STATES,
    LOG,
    MIN_BUCKET_SECONDS,
    OPEN_TASK_STATES,
    AirflowFailException,
    Any,
    Counter,
    Iterable,
    Mapping,
    Sequence,
    TaskEnrichmentStatus,
    dataclass,
    field,
    pendulum,
    quote,
)


@dataclass(slots=True)
class TaskCounter:
    """Bound and cache task-instance enrichment requests."""

    client: ApiClient
    remaining: int
    cache: dict[tuple[str, str], TaskEnrichmentResult] = field(default_factory=dict)

    def states(self, dag_id: str, run_id: str) -> TaskEnrichmentResult:
        """Cache bounded state counts; preserve unavailable enrichment explicitly."""
        key = (dag_id, run_id)
        if key in self.cache:
            return self.cache[key]
        if self.remaining <= 0:
            result = TaskEnrichmentResult("skipped")
        else:
            self.remaining -= 1
            resource = (
                f"dags/{quote(dag_id, safe='')}/dagRuns/"
                f"{quote(run_id, safe='')}/taskInstances"
            )
            try:
                rows = self.client.page(resource, "task_instances")
            except AirflowFailException as exc:
                code = exc.code if isinstance(exc, ApiError) else "transport_error"
                LOG.warning(
                    "task-instance enrichment unavailable dag_id=%s run_id=%s code=%s",
                    dag_id,
                    run_id,
                    code,
                )
                result = TaskEnrichmentResult("error")
            else:
                counts = Counter(
                    (first_text(row, "state") or "none").lower() for row in rows
                )
                result = TaskEnrichmentResult(
                    status="ok",
                    state_counts=counts,
                    task_count=sum(counts.values()),
                    open_count=sum(counts.get(name, 0) for name in OPEN_TASK_STATES),
                )
        self.cache[key] = result
        return result


def resolve_open_run(
    row_state: str,
    info: DagInfo,
    config: Config,
    task_counter: TaskCounter,
    dag_id: str,
    run_id: str,
    start: pendulum.DateTime,
    now: pendulum.DateTime,
    marker_seconds: float,
) -> tuple[str, pendulum.DateTime | None, TaskEnrichmentResult, bool, bool]:
    """Resolve or mark an open DAG run using bounded task evidence."""
    state = normalize_state(row_state)
    enrichment = TaskEnrichmentResult("unknown")
    if row_state.lower() not in ACTIVE_RAW_STATES:
        return state, None, enrichment, False, True
    if info.stale:
        if config.open_run_mode == "skip":
            return state, None, enrichment, False, True
        return "other", start.add(seconds=marker_seconds), enrichment, True, False
    if row_state.lower() == "running" and config.verify_open_runs:
        enrichment = task_counter.states(dag_id, run_id)
        if enrichment.status == "ok" and enrichment.open_count == 0:
            if config.open_run_mode == "skip":
                return state, None, enrichment, False, True
            if config.open_run_mode == "marker":
                return (
                    "other",
                    start.add(seconds=marker_seconds),
                    enrichment,
                    True,
                    False,
                )
    end = min(config.history_end, now)
    if config.open_run_max_hours > 0:
        end = min(
            end,
            start.add(microseconds=round(config.open_run_max_hours * 3_600_000_000)),
        )
    return state, end, enrichment, False, False


class NormalizedRunContext(NamedTuple):
    """Store row-derived values shared by every selected-day segment."""

    dag_id: str
    run_id: str
    source_run_id: str
    state: str
    raw_state: str
    run_type: str
    queued_at: pendulum.DateTime | None
    effective_start_source: str
    logical_date: pendulum.DateTime | None
    interval_start: pendulum.DateTime | None
    interval_end: pendulum.DateTime | None
    tags: tuple[str, ...]
    owner: str
    paused: bool
    stale: bool
    task_count: int | None
    task_enrichment_status: TaskEnrichmentStatus
    synthetic_end: bool
    segment_count: int


def build_run_context(
    row: Mapping[str, Any],
    info: DagInfo,
    dag_id: str,
    run_id: str,
    state: str,
    raw_state: str,
    queued_at: pendulum.DateTime | None,
    effective_start_source: str,
    enrichment: TaskEnrichmentResult,
    synthetic_end: bool,
    timezone: str,
    segment_count: int,
) -> NormalizedRunContext:
    """Derive immutable run metadata once before segment construction."""
    return NormalizedRunContext(
        dag_id=dag_id,
        run_id=run_id,
        source_run_id=stable_id(dag_id, run_id),
        state=state,
        raw_state=raw_state,
        run_type=first_text(row, "run_type", "runType") or "unknown",
        queued_at=queued_at,
        effective_start_source=effective_start_source,
        logical_date=dt_or_none(
            row,
            timezone,
            "logical_date",
            "logicalDate",
            "execution_date",
            "executionDate",
        ),
        interval_start=dt_or_none(
            row, timezone, "data_interval_start", "dataIntervalStart"
        ),
        interval_end=dt_or_none(row, timezone, "data_interval_end", "dataIntervalEnd"),
        tags=info.tags,
        owner=info.owner,
        paused=info.paused,
        stale=info.stale,
        task_count=enrichment.task_count if enrichment.status == "ok" else None,
        task_enrichment_status=enrichment.status,
        synthetic_end=synthetic_end,
        segment_count=segment_count,
    )


def build_normalized_run(
    context: NormalizedRunContext,
    start: pendulum.DateTime,
    end: pendulum.DateTime,
    segment_index: int,
    selected_day: str | None,
) -> Run:
    """Construct one canonical run segment from precomputed row metadata."""
    return Run(
        dag_id=context.dag_id,
        run_id=context.run_id,
        source_run_id=context.source_run_id,
        segment_index=segment_index,
        segment_count=context.segment_count,
        selected_day=selected_day,
        state=context.state,
        raw_state=context.raw_state,
        run_type=context.run_type,
        start=start,
        end=end,
        queued_at=context.queued_at,
        effective_start_source=context.effective_start_source,
        logical_date=context.logical_date,
        interval_start=context.interval_start,
        interval_end=context.interval_end,
        tags=context.tags,
        owner=context.owner,
        paused=context.paused,
        stale=context.stale,
        task_count=context.task_count,
        task_enrichment_status=context.task_enrichment_status,
        synthetic_end=context.synthetic_end,
    )


def initial_run_context(
    row: Mapping[str, Any], config: Config, dags: Mapping[str, DagInfo]
) -> (
    tuple[
        str,
        str,
        pendulum.DateTime,
        pendulum.DateTime | None,
        pendulum.DateTime | None,
        str,
        DagInfo,
    ]
    | None
):
    """Derive initial timestamps and state context from one API row."""
    dag_id, run_id = run_key(row)
    start = dt_or_none(row, config.timezone, "start_date", "startDate")
    queued_at = dt_or_none(row, config.timezone, "queued_at", "queuedAt")
    if start is not None:
        effective = start
        source = "start_date"
    elif queued_at is not None:
        effective = queued_at
        source = "queued_at"
    else:
        return None
    explicit_end = dt_or_none(row, config.timezone, "end_date", "endDate")
    if not dag_id or not run_id:
        return None
    info = dags.get(dag_id)
    if info is None:
        return None
    return dag_id, run_id, effective, explicit_end, queued_at, source, info


def clamp_run_windows(
    start: pendulum.DateTime, end: pendulum.DateTime, config: Config
) -> tuple[tuple[pendulum.DateTime, pendulum.DateTime, str | None], ...]:
    """Clip a run to the selected historical intervals."""
    if end <= start or end <= config.history_start or start >= config.history_end:
        return ()
    windows: list[tuple[pendulum.DateTime, pendulum.DateTime, str | None]] = []
    for interval_start, interval_end, selected_day in selected_day_intervals(config):
        clamped_start = max(start, interval_start)
        clamped_end = min(end, interval_end)
        if clamped_end > clamped_start:
            windows.append((clamped_start, clamped_end, selected_day))
    return tuple(windows)


def normalize_run_row(
    row: Mapping[str, Any],
    config: Config,
    dags: Mapping[str, DagInfo],
    task_counter: TaskCounter,
    now: pendulum.DateTime,
    marker_seconds: float,
) -> tuple[tuple[Run, ...], str]:
    """Normalize and segment one API DAG-run row."""
    initial = initial_run_context(row, config, dags)
    if initial is None:
        return (), "invalid-identity-or-timestamp"
    dag_id, run_id, start, explicit_end, queued_at, start_source, info = initial
    if explicit_end is not None and explicit_end <= start:
        return (), "invalid-run-interval"
    if start >= config.history_end or (
        explicit_end is not None and explicit_end <= config.history_start
    ):
        return (), "outside-window"
    raw_state = first_text(row, "state") or "other"
    state = normalize_state(raw_state)
    enrichment = TaskEnrichmentResult("unknown")
    synthetic_end = False
    end = explicit_end
    if end is None:
        state, end, enrichment, synthetic_end, rejected = resolve_open_run(
            raw_state,
            info,
            config,
            task_counter,
            dag_id,
            run_id,
            start,
            now,
            marker_seconds,
        )
        if rejected or end is None:
            return (), "open-run-policy"
    windows = clamp_run_windows(start, end, config)
    if not windows:
        return (
            (),
            "outside-selected-days"
            if config.selected_days
            else "invalid-or-outside-window",
        )
    if config.count_task_instances and enrichment.status == "unknown":
        enrichment = task_counter.states(dag_id, run_id)
    context = build_run_context(
        row,
        info,
        dag_id,
        run_id,
        state,
        raw_state,
        queued_at,
        start_source,
        enrichment,
        synthetic_end,
        config.timezone,
        len(windows),
    )
    return (
        tuple(
            build_normalized_run(
                context, window_start, window_end, segment_index, selected_day
            )
            for segment_index, (window_start, window_end, selected_day) in enumerate(
                windows, start=1
            )
        ),
        "accepted",
    )


def normalize_runs(
    client: ApiClient,
    rows: Iterable[Mapping[str, Any]],
    dags: Mapping[str, DagInfo],
) -> tuple[Run, ...]:
    """Normalize all deduplicated rows into deterministic run segments."""
    config = client.config
    task_counter = TaskCounter(client, config.max_task_instance_calls)
    result: list[Run] = []
    reasons: Counter[str] = Counter()
    now = pendulum.now(config.timezone)
    marker_seconds = max(MIN_BUCKET_SECONDS, min(config.bucket_seconds, 60.0))
    input_count: int | str = len(rows) if isinstance(rows, Sequence) else "stream"
    for row in rows:
        segments, reason = normalize_run_row(
            row, config, dags, task_counter, now, marker_seconds
        )
        reasons[reason] += 1
        if segments:
            result.extend(segments)
            client.stats.selected_day_segments += len(segments)
        elif reason == "outside-selected-days":
            client.stats.selected_day_rejections += 1
        elif reason not in {"outside-window", "invalid-or-outside-window"}:
            client.stats.normalization_rejections += 1
            client.stats.mark_incomplete(f"dagRuns:normalization:{reason}")
    LOG.debug(
        "REPORT | NORMALIZATION | input=%s | retained_segments=%s | source_runs=%s | reasons=%s | "
        "task_calls=%s | remaining_task_budget=%s",
        input_count,
        len(result),
        len({run.source_run_id for run in result}),
        dict(reasons),
        client.stats.task_instance_calls,
        task_counter.remaining,
    )
    return tuple(
        sorted(
            result,
            key=lambda item: (
                item.start,
                item.end,
                item.dag_id.casefold(),
                item.run_id,
                item.segment_index,
            ),
        )
    )
