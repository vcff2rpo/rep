# SPDX-License-Identifier: Apache-2.0
"""Generated constants from contracts/report_feature_contract_v3.json.

Do not edit manually. Run ``python tools/generate_contract_bindings.py``.
"""

from __future__ import annotations

from typing import Final

FEATURE_CONTRACT_SCHEMA: Final[str] = "airflow-runtime-report-feature-contract-v1"
PAYLOAD_SCHEMA_GENERATED: Final[str] = "payload_v3"
TRANSPORT_SCHEMA_GENERATED: Final[str] = "report-transport-v1"
HISTORICAL_TRANSPORT_SCHEMA_GENERATED: Final[str] = "historical-columnar-v1"
HISTORICAL_ANALYTICS_SCHEMA: Final[str] = "historical-analytics-v1"
ANALYTICS_PERCENTILES: Final[tuple[int, ...]] = (
    50,
    90,
    95,
)
ANALYTICS_MINIMUM_SAMPLES: Final[int] = 5
ANALYTICS_MEDIUM_MINIMUM_SAMPLES: Final[int] = 12
ANALYTICS_HIGH_MINIMUM_SAMPLES: Final[int] = 30
ANOMALY_WATCH_SCORE: Final[int] = 40
ANOMALY_HIGH_SCORE: Final[int] = 65
ANOMALY_CRITICAL_SCORE: Final[int] = 85
TASK_INSPECTOR_PAGE_SIZE: Final[int] = 64
TASK_INSPECTOR_MAX_MOUNTED: Final[int] = 65
