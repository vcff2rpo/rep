# SPDX-License-Identifier: Apache-2.0
"""Pure Airflow API connection URL normalization and validation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from urllib.parse import urlsplit, urlunsplit

from .configuration_errors import fail
from .configuration_security import safe_url_path_segments
from .preamble import AirflowFailException, Connection


@dataclass(frozen=True, slots=True)
class RequestApiCredential:
    """Carry one request-scoped bearer credential without persistence."""

    base_url: str
    bearer_token: str
    source: str

    def __post_init__(self) -> None:
        candidate = str(self.base_url or "").strip()
        token = str(self.bearer_token or "").strip()
        source = str(self.source or "").strip()
        if not candidate:
            fail("request API base URL is empty")
        if not token or len(token) > 65536:
            fail("request bearer token is missing or exceeds the size limit")
        if any(char.isspace() or ord(char) < 32 or ord(char) == 127 for char in token):
            fail(
                "request bearer token contains prohibited whitespace or control characters"
            )
        if not source or len(source) > 80:
            fail("request credential source is invalid")


def api_url_candidate(connection: Connection) -> tuple[str, bool]:
    """Return the configured URL candidate and whether host carried a full URL."""
    host = str(connection.host or "").strip()
    if not host or any(ord(char) < 32 or char.isspace() for char in host):
        fail(f"invalid API host in connection {connection.conn_id!r}")
    if "://" in host:
        return host.rstrip("/"), True
    candidate = f"{connection.schema or 'https'}://{host}"
    if connection.port:
        candidate += f":{connection.port}"
    return candidate, False


def split_api_url(candidate: str) -> tuple[Any, str, int | None]:
    """Parse a URL and convert invalid host/port syntax to one task failure."""
    try:
        parsed = urlsplit(candidate)
        return parsed, parsed.hostname or "", parsed.port
    except ValueError as exc:
        raise AirflowFailException(
            "API base URL contains an invalid hostname or port"
        ) from exc


def validate_full_url_connection_fields(
    connection: Connection, parsed: Any, port: int | None, full_url_host: bool
) -> None:
    """Reject conflicts between a full-URL host and separate connection fields."""
    if not full_url_host:
        return
    configured_schema = str(connection.schema or "").strip().lower()
    if configured_schema and configured_schema != parsed.scheme:
        fail("API connection full-URL host conflicts with the schema field")
    if connection.port is not None and connection.port != port:
        fail("API connection full-URL host conflicts with the port field")


def validate_api_origin(parsed: Any, hostname: str, port: int | None) -> None:
    """Validate scheme, hostname, port, userinfo, query, and fragment fields."""
    if parsed.scheme not in {"http", "https"} or not hostname:
        fail("API base URL must use http or https and include a hostname")
    if port is not None and not 1 <= port <= 65535:
        fail("API base URL port must be between 1 and 65535")
    if parsed.username or parsed.password:
        fail("API base URL must not contain userinfo")
    if parsed.query or parsed.fragment:
        fail("API base URL must not contain query parameters or fragments")


def normalized_api_path(path_value: str) -> str:
    """Normalize a reverse-proxy prefix and remove API-version suffixes."""
    path_segments = safe_url_path_segments(path_value, "API base URL")
    path = "/" + "/".join(path_segments) if path_segments else ""
    if path.endswith("/api/v1"):
        fail("REST API v1 is unsupported; configure the Airflow 3 API origin")
    return path.removesuffix("/api/v2").rstrip("/")


def normalized_api_netloc(hostname: str, port: int | None) -> str:
    """Format a normalized IPv4, hostname, or bracketed IPv6 network location."""
    netloc = f"[{hostname}]" if ":" in hostname else hostname
    return f"{netloc}:{port}" if port is not None else netloc


def validated_api_base_url(candidate: str) -> str:
    """Normalize one explicit API base URL without a Connection object."""
    parsed, hostname, port = split_api_url(str(candidate or "").strip().rstrip("/"))
    validate_api_origin(parsed, hostname, port)
    return urlunsplit(
        (
            parsed.scheme,
            normalized_api_netloc(hostname, port),
            normalized_api_path(parsed.path),
            "",
            "",
        )
    )
