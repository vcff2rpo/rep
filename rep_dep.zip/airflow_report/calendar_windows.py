# SPDX-License-Identifier: Apache-2.0
"""Shared local-calendar interval construction for report window planning."""

from __future__ import annotations

from .preamble import pendulum


def calendar_intervals(
    start: pendulum.DateTime, end: pendulum.DateTime
) -> tuple[tuple[pendulum.DateTime, pendulum.DateTime], ...]:
    """Return clipped local-calendar intervals intersecting ``[start, end)``."""
    values: list[tuple[pendulum.DateTime, pendulum.DateTime]] = []
    cursor = start.start_of("day")
    while cursor < end:
        next_day = cursor.add(days=1)
        bounded_start = max(start, cursor)
        bounded_end = min(end, next_day)
        if bounded_end > bounded_start:
            values.append((bounded_start, bounded_end))
        cursor = next_day
    return tuple(values)
