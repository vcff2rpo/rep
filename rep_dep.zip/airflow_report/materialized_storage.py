# SPDX-License-Identifier: Apache-2.0
"""Bounded storage, integrity, and partition primitives for materialized reports."""

from __future__ import annotations

import fcntl
import hashlib
import json
import os
import re
import stat
import tempfile
import time
from collections.abc import Callable, Mapping, Sequence
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import pendulum

from .api_contract import API_VERSION
from .configuration_security import (
    absolute_path_without_resolving,
    open_trusted_directory,
    read_bounded_regular_file,
    redact_secret_text,
)
from .models import ApiStats, DagInfo
from .preamble import LOG, AirflowFailException

PARTITION_SCHEMA = "airflow-runtime-report-daily-v3"
PARTITION_RE = re.compile(r"^[0-9]{6}\.json$")
INVALID_PARTITION_RE = re.compile(r"^\.[0-9]{6}\.json\.[0-9]+\.invalid$")
TIMEZONE_SCOPE_RE = re.compile(r"^tz-[a-f0-9]{24}$")
AUTHORIZATION_SCOPE_RE = re.compile(r"^auth-[a-f0-9]{24}$")
AUTHORIZATION_IDENTITY_RE = re.compile(r"^[a-f0-9]{64}$")
TRANSIENT_PARTITION_RE = re.compile(r"^\.[0-9]{6}\.json\..+\.tmp$")
MAX_PARTITION_BYTES = 64 * 1024 * 1024
MAX_RETAINED_DAYS = 10
MAX_INVALID_PARTITION_QUARANTINE = 4
DEFAULT_MAX_TIMEZONE_SCOPES = 16
DEFAULT_MAX_AUTHORIZATION_SCOPES = 64
CURRENT_DAY_OVERLAP_SECONDS = 300
DEFAULT_CURRENT_DAY_MAX_AGE_SECONDS = 60
REPOSITORY_GENERATION_FILENAME = ".report.generation"
AUTHORIZATION_IDENTITY_FILENAME = ".authorization"
EMPTY_REPOSITORY_IDENTITY = (0, 0, 0, 0)
NON_TERMINAL_STATES = frozenset(
    {
        "queued",
        "running",
        "scheduled",
        "deferred",
        "up_for_retry",
        "up_for_reschedule",
        "restarting",
    }
)


@dataclass(frozen=True, slots=True)
class MaterializedDataset:
    """Contain validated selected partitions and current DAG metadata."""

    dags: Mapping[str, DagInfo]
    raw_runs: tuple[dict[str, Any], ...]
    complete: bool
    coverage: Mapping[str, Any]
    stats: ApiStats
    repository_identity: tuple[int, int, int, int]


@dataclass(frozen=True, slots=True)
class _Partition:
    """Contain one validated local daily partition."""

    date: str
    timezone: str
    generated_at: pendulum.DateTime
    collected_through: pendulum.DateTime
    complete: bool
    runs: tuple[dict[str, Any], ...]
    nonterminal_rows: tuple[dict[str, Any], ...]
    dags: Mapping[str, DagInfo]
    source_rows: int
    accepted_rows: int
    api_requests: int
    response_bytes: int
    discarded_nonterminal_rows: int
    content_sha256: str


def _bounded_env_int(name: str, default: int, minimum: int, maximum: int) -> int:
    raw = os.getenv(f"AIRFLOW_REPORT__{name}")
    try:
        value = default if raw in (None, "") else int(str(raw))
    except (TypeError, ValueError) as exc:
        raise AirflowFailException(f"invalid AIRFLOW_REPORT__{name}") from exc
    if value < minimum or value > maximum:
        raise AirflowFailException(
            f"AIRFLOW_REPORT__{name} must be between {minimum} and {maximum}"
        )
    return value


def _canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _date_key(day: pendulum.DateTime) -> str:
    return day.format("YYMMDD") + ".json"


def _timezone_scope_name(timezone: str) -> str:
    """Return one opaque stable partition namespace for an IANA timezone."""
    digest = hashlib.sha256(timezone.encode("utf-8")).hexdigest()[:24]
    return f"tz-{digest}"


def _ensure_timezone_store(scope: Path) -> None:
    """Create one already-validated timezone scope under the repository lock."""
    descriptor = open_trusted_directory(
        scope,
        0o750,
        create=True,
        label="report JSON timezone scope",
    )
    os.close(descriptor)


def _timezone_store(root: Path, timezone: str) -> Path:
    """Resolve one bounded timezone partition namespace under the root lock."""
    scope_name = _timezone_scope_name(timezone)
    scope = root / scope_name
    try:
        metadata = os.stat(scope, follow_symlinks=False)
    except FileNotFoundError:
        limit = _bounded_env_int(
            "LIVE_TIMEZONE_SCOPES",
            DEFAULT_MAX_TIMEZONE_SCOPES,
            1,
            64,
        )
        scopes: list[str] = []
        for entry in root.iterdir():
            if not TIMEZONE_SCOPE_RE.fullmatch(entry.name):
                continue
            entry_metadata = os.stat(entry, follow_symlinks=False)
            if not stat.S_ISDIR(entry_metadata.st_mode):
                raise AirflowFailException(
                    "report JSON timezone scope is not a regular directory"
                )
            scopes.append(entry.name)
        if len(scopes) >= limit:
            raise AirflowFailException("report JSON timezone scope limit is exhausted")
    else:
        if not stat.S_ISDIR(metadata.st_mode):
            raise AirflowFailException(
                "report JSON timezone scope is not a regular directory"
            )
        descriptor = open_trusted_directory(
            scope,
            label="report JSON timezone scope",
        )
        os.close(descriptor)
    return scope


def _parse_datetime(value: object, timezone: str, label: str) -> pendulum.DateTime:
    text = str(value or "").strip()
    if not text:
        raise AirflowFailException(f"partition {label} is missing")
    try:
        parsed = pendulum.parse(text, strict=True)
    except (TypeError, ValueError, OverflowError) as exc:
        raise AirflowFailException(f"partition {label} is invalid") from exc
    if isinstance(parsed, pendulum.DateTime):
        return parsed.in_timezone(timezone)
    if isinstance(parsed, pendulum.Date):
        return pendulum.datetime(parsed.year, parsed.month, parsed.day, tz=timezone)
    raise AirflowFailException(f"partition {label} must contain a date or datetime")


def _dag_to_json(value: DagInfo) -> dict[str, Any]:
    payload = asdict(value)
    payload["next_run"] = value.next_run.to_iso8601_string() if value.next_run else None
    payload["tags"] = list(value.tags)
    return payload


def _required_boolean(
    value: Mapping[str, Any],
    key: str,
    label: str,
) -> bool:
    """Return one required JSON Boolean without truthiness coercion."""
    candidate = value.get(key)
    if not isinstance(candidate, bool):
        raise AirflowFailException(f"{label} must be a Boolean")
    return candidate


def _required_string(
    value: Mapping[str, Any],
    key: str,
    label: str,
    *,
    allow_empty: bool = True,
) -> str:
    """Return one required bounded JSON string without container coercion."""
    candidate = value.get(key)
    if not isinstance(candidate, str) or len(candidate) > MAX_PARTITION_BYTES:
        raise AirflowFailException(f"{label} must be a string")
    if not allow_empty and not candidate.strip():
        raise AirflowFailException(f"{label} must not be empty")
    return candidate


def _required_nonnegative_integer(
    value: Mapping[str, Any],
    key: str,
    label: str,
) -> int:
    """Return one required nonnegative JSON integer, excluding Booleans."""
    candidate = value.get(key)
    if isinstance(candidate, bool) or not isinstance(candidate, int) or candidate < 0:
        raise AirflowFailException(f"{label} must be a nonnegative integer")
    return candidate


def _dag_from_json(value: Mapping[str, Any], timezone: str) -> DagInfo:
    next_run = value.get("next_run")
    if next_run is not None and not isinstance(next_run, str):
        raise AirflowFailException("partition DAG next_run must be a string or null")
    tags_value = value.get("tags")
    if not isinstance(tags_value, list) or not all(
        isinstance(item, str) for item in tags_value
    ):
        raise AirflowFailException("partition DAG tags must be an array of strings")
    timezone_source = _required_string(
        value,
        "schedule_timezone_source",
        "partition DAG schedule timezone source",
        allow_empty=False,
    ).strip()
    return DagInfo(
        dag_id=_required_string(value, "dag_id", "partition DAG identity"),
        tags=tuple(item for item in tags_value if item),
        owner=_required_string(value, "owner", "partition DAG owner"),
        fileloc=_required_string(value, "fileloc", "partition DAG file location"),
        paused=_required_boolean(value, "paused", "partition DAG paused"),
        stale=_required_boolean(value, "stale", "partition DAG stale"),
        schedule_kind=_required_string(
            value,
            "schedule_kind",
            "partition DAG schedule kind",
        ),
        schedule_expression=_required_string(
            value,
            "schedule_expression",
            "partition DAG schedule expression",
        ),
        schedule_summary=_required_string(
            value,
            "schedule_summary",
            "partition DAG schedule summary",
        ),
        schedule_timezone=_required_string(
            value,
            "schedule_timezone",
            "partition DAG schedule timezone",
        ),
        schedule_timezone_source=timezone_source,
        schedule_source=_required_string(
            value,
            "schedule_source",
            "partition DAG schedule source",
        ),
        next_run=_parse_datetime(next_run, timezone, "dag next_run")
        if isinstance(next_run, str) and next_run
        else None,
        eligible=_required_boolean(value, "eligible", "partition DAG eligible"),
        exclusion_reason=_required_string(
            value,
            "exclusion_reason",
            "partition DAG exclusion reason",
        ),
        detail_status=_required_string(
            value,
            "detail_status",
            "partition DAG detail status",
        ),
    )


def _integrity_material(payload: Mapping[str, Any]) -> dict[str, Any]:
    result = dict(payload)
    integrity = dict(result.get("integrity") or {})
    integrity["contentSha256"] = ""
    result["integrity"] = integrity
    return result


def _partition_payload(
    day: pendulum.DateTime,
    collected_through: pendulum.DateTime,
    complete: bool,
    runs: Sequence[Mapping[str, Any]],
    dags: Mapping[str, DagInfo],
    stats: ApiStats,
    *,
    generated_at: pendulum.DateTime | None = None,
    discarded_nonterminal_rows: int = 0,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "schemaVersion": PARTITION_SCHEMA,
        "date": day.to_date_string(),
        "timezone": day.timezone_name,
        "windowStart": day.start_of("day").to_iso8601_string(),
        "windowEnd": day.start_of("day").add(days=1).to_iso8601_string(),
        "generatedAt": (
            generated_at or pendulum.now(day.timezone_name)
        ).to_iso8601_string(),
        "collectedThrough": collected_through.to_iso8601_string(),
        "complete": complete,
        "apiVersion": API_VERSION,
        "runs": [dict(row) for row in runs],
        "dagMetadata": [
            _dag_to_json(dags[key]) for key in sorted(dags, key=str.casefold)
        ],
        "collection": {
            "apiRequests": stats.requests,
            "sourceRows": stats.raw_run_rows,
            "acceptedRows": len(runs),
            "responseBytes": stats.response_bytes,
            "discardedNonterminalRows": discarded_nonterminal_rows,
        },
        "integrity": {
            "recordCount": len(runs) + len(dags),
            "contentSha256": "",
        },
    }
    digest = hashlib.sha256(_canonical_bytes(_integrity_material(payload))).hexdigest()
    payload["integrity"]["contentSha256"] = digest
    return payload


def _ensure_root(root: Path) -> Path:
    absolute = absolute_path_without_resolving(root, "report JSON directory")
    descriptor = open_trusted_directory(
        absolute,
        0o750,
        create=True,
        label="report JSON directory",
    )
    os.close(descriptor)
    return absolute


def _reclaim_inactive_authorization_scope(scope: Path) -> bool:
    """Remove one unlocked scope that has never published repository data."""
    lock_path = scope / ".report.lock"
    try:
        descriptor = os.open(
            lock_path,
            os.O_RDWR | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0),
        )
    except OSError:
        return False
    try:
        opened = os.fstat(descriptor)
        inspected = os.stat(lock_path, follow_symlinks=False)
        if (
            not stat.S_ISREG(opened.st_mode)
            or not stat.S_ISREG(inspected.st_mode)
            or opened.st_dev != inspected.st_dev
            or opened.st_ino != inspected.st_ino
        ):
            return False
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return False
        entries = sorted(scope.iterdir(), key=lambda item: item.name)
        for entry in entries:
            metadata = os.stat(entry, follow_symlinks=False)
            if entry.name not in {".report.lock", AUTHORIZATION_IDENTITY_FILENAME}:
                return False
            if not stat.S_ISREG(metadata.st_mode):
                return False
        for entry in entries:
            if entry.name == AUTHORIZATION_IDENTITY_FILENAME:
                entry.unlink()
        inspected = os.stat(lock_path, follow_symlinks=False)
        if (
            inspected.st_dev != opened.st_dev
            or inspected.st_ino != opened.st_ino
            or not stat.S_ISREG(inspected.st_mode)
        ):
            return False
        lock_path.unlink()
        scope.rmdir()
        return True
    except OSError:
        return False
    finally:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_UN)
        finally:
            os.close(descriptor)


def _ensure_authorization_store(root: Path, repository_scope: str) -> Path:
    """Return one bounded opaque authorization repository under the root lock."""
    if AUTHORIZATION_SCOPE_RE.fullmatch(repository_scope) is None:
        raise AirflowFailException("materialized repository scope is invalid")
    scope = root / repository_scope
    try:
        metadata = os.stat(scope, follow_symlinks=False)
    except FileNotFoundError:
        limit = _bounded_env_int(
            "LIVE_AUTHORIZATION_SCOPES",
            DEFAULT_MAX_AUTHORIZATION_SCOPES,
            1,
            1024,
        )
        scopes: list[Path] = []
        for entry in root.iterdir():
            if not AUTHORIZATION_SCOPE_RE.fullmatch(entry.name):
                continue
            entry_metadata = os.stat(entry, follow_symlinks=False)
            if not stat.S_ISDIR(entry_metadata.st_mode):
                raise AirflowFailException(
                    "materialized authorization scope is not a directory"
                )
            scopes.append(entry)
        if len(scopes) >= limit:
            for inactive in sorted(scopes, key=lambda item: item.name):
                if _reclaim_inactive_authorization_scope(inactive):
                    scopes.remove(inactive)
                    if len(scopes) < limit:
                        break
        if len(scopes) >= limit:
            raise AirflowFailException(
                "materialized authorization scope limit is exhausted"
            )
        descriptor = open_trusted_directory(
            scope,
            0o750,
            create=True,
            label="materialized authorization scope",
        )
        os.close(descriptor)
    else:
        if not stat.S_ISDIR(metadata.st_mode):
            raise AirflowFailException(
                "materialized authorization scope is not a directory"
            )
        descriptor = open_trusted_directory(
            scope,
            label="materialized authorization scope",
        )
        os.close(descriptor)
    return scope


def _read_authorization_identity(scope: Path) -> str | None:
    """Read one stable authorization identity marker from a trusted scope."""
    marker = scope / AUTHORIZATION_IDENTITY_FILENAME
    try:
        metadata = os.stat(marker, follow_symlinks=False)
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise AirflowFailException(
            "materialized authorization marker cannot be inspected"
        ) from exc
    if not stat.S_ISREG(metadata.st_mode):
        raise AirflowFailException(
            "materialized authorization marker is not a regular file"
        )
    raw, _device, _inode = read_bounded_regular_file(
        marker,
        128,
        "materialized authorization marker",
        verify_stable_content=True,
    )
    try:
        identity = raw.decode("ascii").strip()
    except UnicodeDecodeError as exc:
        raise AirflowFailException(
            "materialized authorization marker is malformed"
        ) from exc
    if AUTHORIZATION_IDENTITY_RE.fullmatch(identity) is None:
        raise AirflowFailException("materialized authorization marker is invalid")
    return identity


def _remove_timezone_scope(scope: Path) -> None:
    """Delete one known internal timezone scope without following links."""
    metadata = os.stat(scope, follow_symlinks=False)
    if not stat.S_ISDIR(metadata.st_mode):
        raise AirflowFailException("materialized timezone scope is not a directory")
    entries = sorted(scope.iterdir(), key=lambda item: item.name)
    for entry in entries:
        entry_metadata = os.stat(entry, follow_symlinks=False)
        allowed = (
            PARTITION_RE.fullmatch(entry.name)
            or INVALID_PARTITION_RE.fullmatch(entry.name)
            or TRANSIENT_PARTITION_RE.fullmatch(entry.name)
        )
        if not stat.S_ISREG(entry_metadata.st_mode) or not allowed:
            raise AirflowFailException(
                "materialized timezone scope contains an unexpected entry"
            )
    for entry in entries:
        entry.unlink()
    scope.rmdir()


def _authorization_reset_entries(
    scope: Path,
) -> tuple[tuple[Path, ...], tuple[Path, ...]]:
    """Validate a complete authorization scope before any destructive mutation."""
    timezone_scopes: list[Path] = []
    files: list[Path] = []
    for entry in sorted(scope.iterdir(), key=lambda item: item.name):
        metadata = os.stat(entry, follow_symlinks=False)
        if entry.name == ".report.lock" and stat.S_ISREG(metadata.st_mode):
            continue
        if TIMEZONE_SCOPE_RE.fullmatch(entry.name) and stat.S_ISDIR(metadata.st_mode):
            entries = sorted(entry.iterdir(), key=lambda item: item.name)
            for child in entries:
                child_metadata = os.stat(child, follow_symlinks=False)
                allowed = (
                    PARTITION_RE.fullmatch(child.name)
                    or INVALID_PARTITION_RE.fullmatch(child.name)
                    or TRANSIENT_PARTITION_RE.fullmatch(child.name)
                )
                if not stat.S_ISREG(child_metadata.st_mode) or not allowed:
                    raise AirflowFailException(
                        "materialized timezone scope contains an unexpected entry"
                    )
            timezone_scopes.append(entry)
            continue
        if entry.name in {
            AUTHORIZATION_IDENTITY_FILENAME,
            REPOSITORY_GENERATION_FILENAME,
        } and stat.S_ISREG(metadata.st_mode):
            files.append(entry)
            continue
        raise AirflowFailException(
            "materialized authorization scope contains an unexpected entry"
        )
    return tuple(timezone_scopes), tuple(files)


def _reset_authorization_store(scope: Path, authorization_identity: str) -> bool:
    """Remove stale authorized data and report whether repository data changed."""
    if AUTHORIZATION_IDENTITY_RE.fullmatch(authorization_identity) is None:
        raise AirflowFailException("materialized authorization identity is invalid")
    timezone_scopes, files = _authorization_reset_entries(scope)
    had_repository_data = bool(timezone_scopes) or any(
        entry.name == REPOSITORY_GENERATION_FILENAME for entry in files
    )
    if had_repository_data:
        _advance_repository_generation(scope)
    for timezone_scope in timezone_scopes:
        _remove_timezone_scope(timezone_scope)
    for entry in files:
        if entry.name != REPOSITORY_GENERATION_FILENAME:
            entry.unlink()
    _atomic_write(
        scope / AUTHORIZATION_IDENTITY_FILENAME,
        authorization_identity.encode("ascii"),
    )
    return had_repository_data


def _synchronize_authorization_identity(
    scope: Path,
    authorization_identity: str,
) -> bool:
    """Reset one repository scope when its effective authorization changes."""
    if AUTHORIZATION_IDENTITY_RE.fullmatch(authorization_identity) is None:
        raise AirflowFailException("materialized authorization identity is invalid")
    if _read_authorization_identity(scope) == authorization_identity:
        return False
    _reset_authorization_store(
        scope,
        authorization_identity,
    )
    return True


def _atomic_write(path: Path, payload: bytes) -> None:
    descriptor, name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.write(b"\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 0o640)
        os.replace(temporary, path)
        directory = os.open(path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        temporary.unlink(missing_ok=True)


def _write_partition(path: Path, payload: Mapping[str, Any]) -> None:
    _atomic_write(path, _canonical_bytes(payload))


def materialized_repository_identity(root: Path) -> tuple[int, int, int, int]:
    """Return the atomic generation marker identity used by worker caches."""
    path = root / REPOSITORY_GENERATION_FILENAME
    try:
        metadata = os.stat(path, follow_symlinks=False)
    except FileNotFoundError:
        return EMPTY_REPOSITORY_IDENTITY
    except OSError as exc:
        raise AirflowFailException(
            "report JSON generation marker cannot be inspected"
        ) from exc
    if not stat.S_ISREG(metadata.st_mode) or not 0 < metadata.st_size <= 32:
        raise AirflowFailException("report JSON generation marker is invalid")
    return (
        metadata.st_dev,
        metadata.st_ino,
        metadata.st_size,
        metadata.st_mtime_ns,
    )


def _advance_repository_generation(root: Path) -> tuple[int, int, int, int]:
    """Atomically invalidate process-local caches after repository mutation."""
    _atomic_write(root / REPOSITORY_GENERATION_FILENAME, b"1")
    identity = materialized_repository_identity(root)
    if identity == EMPTY_REPOSITORY_IDENTITY:
        raise AirflowFailException("report JSON generation marker was not published")
    return identity


def _reject_duplicate_object_keys(
    pairs: list[tuple[str, Any]],
) -> dict[str, Any]:
    """Build one JSON object while rejecting ambiguous duplicate names."""
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise AirflowFailException(
                f"report JSON partition contains duplicate key {key!r}"
            )
        result[key] = value
    return result


def _read_partition_payload(path: Path) -> dict[str, Any]:
    if not PARTITION_RE.fullmatch(path.name):
        raise AirflowFailException("report JSON partition filename is invalid")
    raw, _device, _inode = read_bounded_regular_file(
        path,
        MAX_PARTITION_BYTES,
        "report JSON partition",
        verify_stable_content=True,
    )
    try:
        payload = json.loads(raw, object_pairs_hook=_reject_duplicate_object_keys)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise AirflowFailException("report JSON partition is malformed") from exc
    if (
        not isinstance(payload, dict)
        or payload.get("schemaVersion") != PARTITION_SCHEMA
    ):
        raise AirflowFailException("report JSON partition schema is unsupported")
    return payload


def _validate_partition_integrity(
    payload: Mapping[str, Any],
) -> tuple[dict[str, Any], str]:
    integrity = payload.get("integrity")
    if not isinstance(integrity, dict):
        raise AirflowFailException("report JSON partition integrity is missing")
    expected = str(integrity.get("contentSha256") or "")
    actual = hashlib.sha256(_canonical_bytes(_integrity_material(payload))).hexdigest()
    if not expected or expected != actual:
        raise AirflowFailException("report JSON partition checksum mismatch")
    return integrity, expected


def _validate_partition_window(
    path: Path,
    payload: Mapping[str, Any],
    expected_timezone: str,
) -> tuple[str, str]:
    timezone = str(payload.get("timezone") or "")
    if timezone != expected_timezone:
        raise AirflowFailException(
            "report JSON partition timezone does not match the report"
        )
    try:
        filename_day = pendulum.from_format(path.stem, "YYMMDD", tz=timezone)
    except (TypeError, ValueError, OverflowError) as exc:
        raise AirflowFailException(
            "report JSON partition filename date is invalid"
        ) from exc
    partition_date = str(payload.get("date") or "")
    if partition_date != filename_day.to_date_string():
        raise AirflowFailException(
            "report JSON partition date does not match its filename"
        )
    expected_start = filename_day.start_of("day").to_iso8601_string()
    expected_end = filename_day.start_of("day").add(days=1).to_iso8601_string()
    if (
        payload.get("windowStart") != expected_start
        or payload.get("windowEnd") != expected_end
    ):
        raise AirflowFailException(
            "report JSON partition window does not match its date"
        )
    return timezone, partition_date


def _validate_partition_records(
    payload: Mapping[str, Any],
    timezone: str,
    integrity: Mapping[str, Any],
) -> tuple[tuple[dict[str, Any], ...], dict[str, DagInfo]]:
    runs_value = payload.get("runs")
    dags_value = payload.get("dagMetadata")
    if not isinstance(runs_value, list) or not isinstance(dags_value, list):
        raise AirflowFailException("report JSON partition arrays are invalid")
    if not all(isinstance(row, dict) for row in (*runs_value, *dags_value)):
        raise AirflowFailException("report JSON partition contains a non-object record")
    runs = tuple(dict(row) for row in runs_value)
    dag_rows = tuple(_dag_from_json(row, timezone) for row in dags_value)
    if any(not info.dag_id for info in dag_rows):
        raise AirflowFailException(
            "report JSON partition contains an empty DAG identity"
        )
    if len({info.dag_id for info in dag_rows}) != len(dag_rows):
        raise AirflowFailException(
            "report JSON partition contains duplicate DAG identities"
        )
    dags = {info.dag_id: info for info in dag_rows}
    expected_record_count = len(runs) + len(dags)
    record_count = _required_nonnegative_integer(
        integrity,
        "recordCount",
        "report JSON partition record count",
    )
    if record_count != expected_record_count:
        raise AirflowFailException("report JSON partition record count is inconsistent")
    return runs, dags


def _load_partition(path: Path, expected_timezone: str) -> _Partition:
    payload = _read_partition_payload(path)
    integrity, expected = _validate_partition_integrity(payload)
    timezone, partition_date = _validate_partition_window(
        path,
        payload,
        expected_timezone,
    )
    runs, dags = _validate_partition_records(payload, timezone, integrity)
    collection_value = payload.get("collection")
    if not isinstance(collection_value, dict):
        raise AirflowFailException("report JSON partition collection is missing")
    collection = collection_value
    source_rows = _required_nonnegative_integer(
        collection,
        "sourceRows",
        "report JSON partition sourceRows",
    )
    accepted_rows = _required_nonnegative_integer(
        collection,
        "acceptedRows",
        "report JSON partition acceptedRows",
    )
    if accepted_rows != len(runs):
        raise AirflowFailException(
            "report JSON partition accepted row count is inconsistent"
        )
    if _required_string(
        payload, "apiVersion", "report JSON partition API version", allow_empty=False
    ) != API_VERSION:
        raise AirflowFailException("report JSON partition API version is unsupported")
    return _Partition(
        date=partition_date,
        timezone=timezone,
        generated_at=_parse_datetime(
            payload.get("generatedAt"), timezone, "generatedAt"
        ),
        collected_through=_parse_datetime(
            payload.get("collectedThrough"),
            timezone,
            "collectedThrough",
        ),
        complete=_required_boolean(
            payload,
            "complete",
            "report JSON partition complete",
        ),
        runs=runs,
        nonterminal_rows=tuple(
            row for row in runs if _raw_state(row) in NON_TERMINAL_STATES
        ),
        dags=dags,
        source_rows=source_rows,
        accepted_rows=accepted_rows,
        api_requests=_required_nonnegative_integer(
            collection,
            "apiRequests",
            "report JSON partition apiRequests",
        ),
        response_bytes=_required_nonnegative_integer(
            collection,
            "responseBytes",
            "report JSON partition responseBytes",
        ),
        discarded_nonterminal_rows=_required_nonnegative_integer(
            collection,
            "discardedNonterminalRows",
            "report JSON partition discardedNonterminalRows",
        ),
        content_sha256=expected,
    )


def _safe_load(
    path: Path,
    timezone: str,
    *,
    before_quarantine: Callable[[], None] | None = None,
) -> _Partition | None:
    try:
        return _load_partition(path, timezone)
    except FileNotFoundError:
        return None
    except (OSError, AirflowFailException) as exc:
        invalid = path.with_name(f".{path.name}.{time.time_ns()}.invalid")
        quarantined = False
        try:
            if before_quarantine is not None:
                before_quarantine()
            os.replace(path, invalid)
            quarantined = True
            _prune_invalid_quarantine(path.parent)
        except OSError:
            pass
        LOG.warning(
            "REPORT | MATERIALIZED | partition=%s | quarantined=%s | reason=%s",
            path.name,
            quarantined,
            redact_secret_text(exc, 240),
        )
        return None


def _prune_invalid_quarantine(root: Path) -> tuple[str, ...]:
    """Retain only the newest bounded invalid-partition diagnostics."""
    candidates: list[tuple[int, str, Path]] = []
    for path in root.iterdir():
        if not INVALID_PARTITION_RE.fullmatch(path.name):
            continue
        metadata = os.stat(path, follow_symlinks=False)
        if stat.S_ISREG(metadata.st_mode):
            candidates.append((metadata.st_mtime_ns, path.name, path))
    removed: list[str] = []
    for _mtime, name, path in sorted(candidates)[:-MAX_INVALID_PARTITION_QUARANTINE]:
        path.unlink(missing_ok=True)
        removed.append(name)
    directory = os.open(root, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(directory)
    finally:
        os.close(directory)
    return tuple(removed)


def _raw_state(row: Mapping[str, Any]) -> str:
    return str(row.get("state") or row.get("dag_run_state") or "").strip().lower()
