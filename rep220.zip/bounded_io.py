# SPDX-License-Identifier: Apache-2.0
"""Bounded, streaming regular-file digests for release verification."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat

MAX_FILE_BYTES = 128 * 1024 * 1024
MAX_TOTAL_BYTES = 512 * 1024 * 1024
MAX_FILES = 1000


def stream_digest(stream, maximum: int) -> tuple[str, int]:
    digest = hashlib.sha256()
    total = 0
    while True:
        block = stream.read(min(65536, maximum - total + 1))
        if not block:
            return digest.hexdigest(), total
        total += len(block)
        if total > maximum:
            raise ValueError("Verification byte budget exceeded")
        digest.update(block)


def file_digest(path: Path, maximum: int = MAX_FILE_BYTES) -> str:
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))
    with os.fdopen(descriptor, "rb") as stream:
        before = os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode) or before.st_size > maximum:
            raise ValueError("Expected a bounded regular file")
        digest, total = stream_digest(stream, maximum)
        after = os.fstat(stream.fileno())
        if total != before.st_size or (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            raise ValueError("File changed during verification")
        return digest


def inventory_budget(records: dict) -> None:
    if not isinstance(records, dict) or not 1 <= len(records) <= MAX_FILES:
        raise ValueError("Verification inventory exceeds count bound")
    sizes = [record.get("bytes") for record in records.values()]
    if any(type(size) is not int or not 0 <= size <= MAX_FILE_BYTES for size in sizes) or sum(sizes) > MAX_TOTAL_BYTES:
        raise ValueError("Verification inventory exceeds byte budget")


def unique_json(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result


def load_json(path: Path) -> dict:
    file_digest(path, 4 * 1024 * 1024)
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=unique_json)


def confined_path(root: Path, name: str) -> Path:
    parts = PurePosixPath(name)
    if root.is_symlink() or not root.is_dir() or not name or len(name) > 512 or parts.is_absolute() or ".." in parts.parts or "\\" in name:
        raise ValueError("Unsafe evidence path")
    result = root
    for part in parts.parts:
        result = result / part
        if result.is_symlink():
            raise ValueError("Evidence symlink rejected")
    return result
