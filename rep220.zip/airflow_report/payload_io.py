# SPDX-License-Identifier: Apache-2.0
"""Report output-path derivation and filesystem location helpers."""

from __future__ import annotations

from .preamble import SAFE_FILENAME_RE, Path, conf, os, pendulum


def base_log_folder() -> Path:
    """Return the configured Airflow base log directory."""
    fallback = Path(os.getenv("AIRFLOW_HOME", "~/airflow")).expanduser() / "logs"
    configured = conf.get("logging", "base_log_folder", fallback=str(fallback))
    return Path(os.path.abspath(os.path.expanduser(str(configured))))


def output_path(generated: pendulum.DateTime, hostname: str) -> Path:
    """Build a clean collision-resistant report output pathname."""
    host = (
        SAFE_FILENAME_RE.sub("_", hostname.split(".", 1)[0].lower()).strip("._")
        or "airflow"
    )
    timestamp = generated.strftime("%Y_%m%d_%H%M%S_%f")
    return base_log_folder() / "report" / f"{host}_{timestamp}.html"
