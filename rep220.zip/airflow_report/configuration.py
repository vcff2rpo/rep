# SPDX-License-Identifier: Apache-2.0
"""Assemble one immutable report configuration from focused validators."""

from __future__ import annotations

from .configuration_errors import fail
from .configuration_security import (
    absolute_path_without_resolving,
    validate_relative_endpoint,
)
from .configuration_values import (
    api_connection_id,
    choice,
    env,
    normalized_parameter_sources,
    parse_bool,
    parse_email_list,
    parse_float,
    parse_int,
    parse_optional_mode,
)
from .configuration_windows import (
    history_window,
    nice_bucket,
    projection_window,
    timezone_context,
)
from .models import Config
from .preamble import (
    FUTURE_OCCURRENCES_TARGET_PER_DAG,
    MAX_API_CACHE_BYTES_HARD,
    MAX_API_CACHE_ENTRIES_HARD,
    MAX_API_PAGES_HARD,
    MAX_API_RESPONSE_BYTES_HARD,
    MAX_API_ROWS_HARD,
    MAX_BUCKET_SECONDS,
    MAX_BUCKETS,
    MAX_DAG_DETAIL_CALLS_HARD,
    MAX_FUTURE_OCCURRENCES_HARD,
    MAX_FUTURE_PER_DAG_HARD,
    MAX_HISTORY_DAYS,
    MAX_HTML_BYTES_HARD,
    MAX_RENDERED_RUNS_HARD,
    MAX_REQUEST_FINGERPRINTS_HARD,
    MAX_TASK_INSTANCE_CALLS_HARD,
    MAX_TOTAL_TIMELINE_ITEMS_HARD,
    MIN_BUCKET_SECONDS,
    RENDERER_FILENAME,
    Any,
    Mapping,
    Path,
    math,
)


def _window_options(values: Mapping[str, Any]) -> tuple[dict[str, Any], Any, Any]:
    """Resolve selected history/future windows and return constructor options."""
    timezone, now = timezone_context(values)
    (
        requested_history_start,
        requested_history_end,
        start,
        end,
        requested_selected_days,
        selected_days,
        history_clamped,
    ) = history_window(values, timezone, now)
    future_enabled, requested_end, effective_end, clamped = projection_window(
        values.get("future_end"), timezone, now
    )
    return (
        {
            "timezone": timezone,
            "requested_history_start": requested_history_start,
            "requested_history_end": requested_history_end,
            "history_start": start,
            "history_end": end,
            "history_clamped": history_clamped,
            "trigger_time": now,
            "requested_selected_days": requested_selected_days,
            "selected_days": selected_days,
            "future_enabled": future_enabled,
            "future_requested_end": requested_end,
            "future_effective_end": effective_end,
            "future_clamped": clamped,
        },
        start,
        end,
    )


def _bucket_options(values: Mapping[str, Any], start: Any, end: Any) -> dict[str, Any]:
    """Resolve the bounded historical aggregation bucket configuration."""
    requested = parse_float(
        values.get("bucket_seconds", 300),
        "bucket_seconds",
        MIN_BUCKET_SECONDS,
        MAX_BUCKET_SECONDS,
    )
    maximum = parse_int(
        env("MAX_HTML_BUCKETS", 3000), "MAX_HTML_BUCKETS", 100, MAX_BUCKETS
    )
    duration_seconds = (end - start).total_seconds()
    effective = (
        requested
        if math.ceil(duration_seconds / requested) <= maximum
        else nice_bucket(duration_seconds / maximum)
    )
    if math.ceil(duration_seconds / effective) > MAX_BUCKETS:
        fail("historical window exceeds maximum bucket count")
    return {
        "requested_bucket_seconds": requested,
        "bucket_seconds": effective,
        "bucket_auto_scaled": effective != requested,
        "max_html_buckets": maximum,
    }


def _timeline_limits() -> tuple[int, int]:
    """Resolve and cross-check historical and future timeline ceilings."""
    historical = parse_int(
        env("MAX_RENDERED_RUNS", 10_000),
        "MAX_RENDERED_RUNS",
        1,
        MAX_RENDERED_RUNS_HARD,
    )
    future = parse_int(
        env("MAX_FUTURE_OCCURRENCES", 10_000),
        "MAX_FUTURE_OCCURRENCES",
        1,
        MAX_FUTURE_OCCURRENCES_HARD,
    )
    if historical + future > MAX_TOTAL_TIMELINE_ITEMS_HARD:
        fail(
            "configured historical and future timeline ceilings exceed the "
            f"combined hard limit {MAX_TOTAL_TIMELINE_ITEMS_HARD}"
        )
    return historical, future


def _api_options(values: Mapping[str, Any]) -> dict[str, Any]:
    """Resolve API, pagination, response, and open-run collection options."""
    if "api_version" in values or env("API_VERSION", None) is not None:
        fail(
            "api_version and AIRFLOW_REPORT__API_VERSION were removed; "
            "REST API v2 is required"
        )
    return {
        "auth_mode": choice(
            values.get("auth_mode") or env("AUTH_MODE", "auto"),
            "auth_mode",
            {"auto", "basic", "bearer", "password_token", "none"},
        ),
        "api_conn_id": api_connection_id(),
        "token_endpoint": validate_relative_endpoint(
            env("TOKEN_ENDPOINT", "/auth/token"), "TOKEN_ENDPOINT"
        ),
        "api_timeout": parse_int(
            env("API_TIMEOUT_SECONDS", 30), "API_TIMEOUT_SECONDS", 1, 3600
        ),
        "token_timeout": parse_int(
            env("API_TOKEN_TIMEOUT_SECONDS", 15),
            "API_TOKEN_TIMEOUT_SECONDS",
            1,
            3600,
        ),
        "api_retries": parse_int(env("API_RETRIES", 3), "API_RETRIES", 0, 10),
        "token_retries": parse_int(
            env("API_TOKEN_RETRIES", 0), "API_TOKEN_RETRIES", 0, 3
        ),
        "api_backoff": parse_float(
            env("API_BACKOFF_SECONDS", 0.5), "API_BACKOFF_SECONDS", 0, 60
        ),
        "page_limit": parse_int(env("API_PAGE_LIMIT", 100), "API_PAGE_LIMIT", 1, 10000),
        "max_pages": parse_int(
            env("API_MAX_PAGES", 3_000), "API_MAX_PAGES", 1, MAX_API_PAGES_HARD
        ),
        "max_rows": parse_int(
            env("API_MAX_ROWS", 200_000), "API_MAX_ROWS", 1, MAX_API_ROWS_HARD
        ),
        "live_report_days": parse_int(
            values.get("_live_report_days", 0),
            "_live_report_days",
            0,
            MAX_HISTORY_DAYS,
        ),
        "max_response_bytes": parse_int(
            env("API_MAX_RESPONSE_BYTES", 25_000_000),
            "API_MAX_RESPONSE_BYTES",
            1024,
            MAX_API_RESPONSE_BYTES_HARD,
        ),
        "max_detail_calls": parse_int(
            env("API_MAX_DAG_DETAILS", 1_000),
            "API_MAX_DAG_DETAILS",
            0,
            MAX_DAG_DETAIL_CALLS_HARD,
        ),
        "count_task_instances": parse_bool(
            env("COUNT_TASK_INSTANCES", False), "COUNT_TASK_INSTANCES"
        ),
        "verify_open_runs": parse_bool(
            env("VERIFY_OPEN_ACTIVE_RUNS", True), "VERIFY_OPEN_ACTIVE_RUNS"
        ),
        "open_run_mode": choice(
            env("OPEN_RUN_UNVERIFIED_MODE", "marker"),
            "OPEN_RUN_UNVERIFIED_MODE",
            {"marker", "skip", "active"},
        ),
        "open_run_max_hours": parse_float(
            env("OPEN_RUN_MAX_HOURS", 0), "OPEN_RUN_MAX_HOURS", 0, 24 * 366
        ),
        "max_task_instance_calls": parse_int(
            env("MAX_TASK_COUNT_RUNS", 2_000),
            "MAX_TASK_COUNT_RUNS",
            0,
            MAX_TASK_INSTANCE_CALLS_HARD,
        ),
    }


def _resource_output_options(
    values: Mapping[str, Any], max_rendered_runs: int, max_future_occurrences: int
) -> dict[str, Any]:
    """Resolve renderer, cache, output, security, and task identity options."""
    renderer_default = Path(__file__).with_name(RENDERER_FILENAME)
    return {
        "max_rendered_runs": max_rendered_runs,
        "max_future_occurrences": max_future_occurrences,
        "max_future_per_dag": parse_int(
            env("MAX_FUTURE_OCCURRENCES_PER_DAG", 10_000),
            "MAX_FUTURE_OCCURRENCES_PER_DAG",
            1,
            MAX_FUTURE_PER_DAG_HARD,
        ),
        "future_target_per_dag": FUTURE_OCCURRENCES_TARGET_PER_DAG,
        "max_cache_entries": parse_int(
            env("API_CACHE_ENTRIES", 64),
            "API_CACHE_ENTRIES",
            0,
            MAX_API_CACHE_ENTRIES_HARD,
        ),
        "max_cache_bytes": parse_int(
            env("API_CACHE_BYTES", 2_000_000),
            "API_CACHE_BYTES",
            0,
            MAX_API_CACHE_BYTES_HARD,
        ),
        "max_request_fingerprints": parse_int(
            env("API_MAX_REQUEST_FINGERPRINTS", 4_096),
            "API_MAX_REQUEST_FINGERPRINTS",
            32,
            MAX_REQUEST_FINGERPRINTS_HARD,
        ),
        "max_html_bytes": parse_int(
            env("MAX_HTML_BYTES", 100_000_000),
            "MAX_HTML_BYTES",
            1_000_000,
            MAX_HTML_BYTES_HARD,
        ),
        "max_email_attachment_bytes": parse_int(
            env("MAX_EMAIL_ATTACHMENT_BYTES", 25_000_000),
            "MAX_EMAIL_ATTACHMENT_BYTES",
            0,
            2_000_000_000,
        ),
        "allow_insecure_tls": parse_bool(
            env("ALLOW_INSECURE_TLS", False), "ALLOW_INSECURE_TLS"
        ),
        "allow_insecure_http_auth": parse_bool(
            env("ALLOW_INSECURE_HTTP_AUTH", False), "ALLOW_INSECURE_HTTP_AUTH"
        ),
        "api_trust_env": parse_bool(env("API_TRUST_ENV", False), "API_TRUST_ENV"),
        "new_directory_mode": parse_optional_mode(
            env("NEW_OUTPUT_DIRECTORY_MODE", ""), "NEW_OUTPUT_DIRECTORY_MODE"
        ),
        "run_id": str(values.get("_run_id") or "manual"),
        "task_instance_key": str(
            values.get("_task_instance_key") or "generate_runtime_report"
        ),
        "renderer_path": absolute_path_without_resolving(
            env("HTML_TEMPLATE", renderer_default), "HTML_TEMPLATE"
        ),
        "email_to": parse_email_list(values.get("email_to")),
        "parameter_sources": normalized_parameter_sources(values),
    }


def parse_config(values: Mapping[str, Any]) -> Config:
    """Build one explicit typed configuration from validated runtime inputs."""
    options, start, end = _window_options(values)
    options.update(_bucket_options(values, start, end))
    max_rendered_runs, max_future_occurrences = _timeline_limits()
    options.update(_api_options(values))
    options.update(
        _resource_output_options(values, max_rendered_runs, max_future_occurrences)
    )
    return Config(**options)
