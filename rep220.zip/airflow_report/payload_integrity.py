# SPDX-License-Identifier: Apache-2.0
"""Cross-view payload identity, count, ledger, and completeness validation."""

from __future__ import annotations

from .aggregation import unique_source_runs
from .configuration_errors import fail
from .models import Run
from .payload_context import PayloadAssemblyContext
from .payload_rows import _historical_tag_filter_from_dag_tags
from .preamble import Any, Counter, Mapping, Sequence


def _validate_historical_tag_source(
    runs: Sequence[Run], source: Mapping[str, Any], errors: list[str]
) -> None:
    """Validate the compact capacity-retained source ledger exactly."""
    source_runs = unique_source_runs(runs)
    expected_counts = Counter(run.dag_id for run in source_runs)
    expected_rows = [
        [dag_id, expected_counts[dag_id]]
        for dag_id in sorted(
            expected_counts, key=lambda value: (value.casefold(), value)
        )
    ]
    if source.get("schema") != "historical-tag-source-v2":
        errors.append("historical TAG source schema mismatch")
    if int(source.get("sourceRunCount") or 0) != len(source_runs):
        errors.append("historical TAG source-run count mismatch")
    if int(source.get("dagCount") or 0) != len(expected_counts):
        errors.append("historical TAG source DAG count mismatch")
    if list(source.get("dagRunCounts") or []) != expected_rows:
        errors.append("historical TAG source per-DAG counts mismatch")


def _validate_historical_tag_filter(
    dags: Sequence[Mapping[str, Any]],
    runs: Sequence[Run],
    options: Sequence[Mapping[str, Any]],
    errors: list[str],
) -> None:
    """Validate exact post-capacity TAG membership against canonical DAG metadata."""
    dag_tags = {
        str(row.get("dag") or ""): tuple(row.get("tags") or ())
        for row in dags
        if str(row.get("dag") or "")
    }
    expected = _historical_tag_filter_from_dag_tags(dag_tags, runs)
    actual = [dict(row) for row in options]
    if actual != expected:
        errors.append(
            "historical TAG filter mismatch "
            f"expected={expected[:5]!r} actual={actual[:5]!r}"
        )


def _validate_unique_payload_ids(
    runs: Sequence[Mapping[str, Any]],
    future: Sequence[Mapping[str, Any]],
    dags: Sequence[Mapping[str, Any]],
    errors: list[str],
) -> tuple[list[str], set[str]]:
    """Validate row identifiers and return canonical DAG identifiers."""
    identity_specs = (
        ("historical run row", [str(row.get("id") or "") for row in runs]),
        ("future occurrence", [str(row.get("id") or "") for row in future]),
        ("DAG metadata", [str(row.get("dag") or "") for row in dags]),
    )
    for label, values in identity_specs:
        if any(not value for value in values) or len(set(values)) != len(values):
            errors.append(f"{label} identifiers must be non-empty and unique")
    dag_ids = identity_specs[2][1]
    known_dags = set(dag_ids)
    referenced_dags = {
        str(row.get("dag") or "") for row in [*runs, *future] if row.get("dag")
    }
    missing_dags = sorted(referenced_dags - known_dags)
    if missing_dags:
        errors.append(f"run rows reference missing DAG metadata: {missing_dags[:5]}")
    return dag_ids, known_dags


def _group_historical_segments(
    runs: Sequence[Mapping[str, Any]],
    errors: list[str],
) -> dict[str, list[Mapping[str, Any]]]:
    segments: dict[str, list[Mapping[str, Any]]] = {}
    for row in runs:
        source_id = str(row.get("sourceRunId") or "")
        if source_id:
            segments.setdefault(source_id, []).append(row)
        else:
            errors.append("historical run row missing sourceRunId")
    return segments


def _validate_segment_group(
    source_id: str,
    rows: Sequence[Mapping[str, Any]],
    errors: list[str],
) -> None:
    expected = {int(row.get("segmentCount") or 0) for row in rows}
    indexes = sorted(int(row.get("segmentIndex") or 0) for row in rows)
    if len(expected) != 1 or next(iter(expected), 0) != len(rows):
        errors.append(f"source run {source_id} has inconsistent segmentCount")
    if indexes != list(range(1, len(rows) + 1)):
        errors.append(f"source run {source_id} has non-contiguous segmentIndex values")
    stable_fields = {
        (
            str(row.get("dag") or ""),
            str(row.get("runId") or ""),
            str(row.get("state") or ""),
        )
        for row in rows
    }
    if len(stable_fields) != 1:
        errors.append(f"source run {source_id} has inconsistent DAG/run/state fields")


def _validate_historical_segments(
    runs: Sequence[Mapping[str, Any]],
    errors: list[str],
) -> dict[str, list[Mapping[str, Any]]]:
    """Validate source-run segment ledgers and return grouped rows."""
    segments = _group_historical_segments(runs, errors)
    for source_id, rows in segments.items():
        _validate_segment_group(source_id, rows, errors)
    return segments


def _validate_dag_and_summary_ledgers(
    dags: Sequence[Mapping[str, Any]],
    future: Sequence[Mapping[str, Any]],
    runs: Sequence[Mapping[str, Any]],
    segments: Mapping[str, Sequence[Mapping[str, Any]]],
    summary: Mapping[str, Any],
    errors: list[str],
) -> Counter[str]:
    """Validate per-DAG counts and canonical summary totals."""
    source_by_dag = Counter(
        str(rows[0].get("dag") or "") for rows in segments.values() if rows
    )
    future_by_dag = Counter(str(row.get("dag") or "") for row in future)
    for row in dags:
        dag_id = str(row.get("dag") or "")
        if int(row.get("runCount") or 0) != source_by_dag[dag_id]:
            errors.append(
                f"DAG {dag_id} historical runCount does not match source ledger"
            )
        if int(row.get("futureCount") or 0) != future_by_dag[dag_id]:
            errors.append(f"DAG {dag_id} futureCount does not match projection ledger")
    expected_summary = {
        "runs": len(segments),
        "runSegments": len(runs),
        "dags": len(dags),
        "futureOccurrences": len(future),
    }
    for key, expected_value in expected_summary.items():
        if int(summary.get(key) or 0) != expected_value:
            errors.append(f"summary.{key} does not match canonical payload ledger")
    return future_by_dag


def _validate_bucket_and_window_ledgers(
    sparse_buckets: Sequence[Sequence[Any]],
    free: Sequence[Mapping[str, Any]],
    critical_indexes: Sequence[int],
    total_buckets: int,
    errors: list[str],
) -> None:
    """Validate sparse bucket indexes and free-window ordering."""
    bucket_indexes: list[int] = []
    for row in sparse_buckets:
        if not row:
            errors.append("sparse bucket row is empty")
            continue
        index = int(row[0])
        bucket_indexes.append(index)
        if index < 0 or index >= total_buckets:
            errors.append(f"sparse bucket index {index} is outside bucketCount")
    if len(bucket_indexes) != len(set(bucket_indexes)):
        errors.append("sparse bucket indexes must be unique")
    known_bucket_indexes = set(range(total_buckets))
    for index in critical_indexes:
        if index not in known_bucket_indexes:
            errors.append(f"critical window references missing bucket index {index}")
    previous_end = -1.0
    for free_row in sorted(free, key=lambda item: float(item.get("t0") or 0.0)):
        start = float(free_row.get("t0") or 0.0)
        end = float(free_row.get("t1") or 0.0)
        if end <= start:
            errors.append("free window must have positive duration")
        if start < previous_end - 1e-12:
            errors.append("free windows must be ordered and non-overlapping")
        previous_end = max(previous_end, end)


def _validate_schedule_diagnostics(
    audits: Sequence[Mapping[str, Any]],
    known_dags: set[str],
    future_by_dag: Mapping[str, int],
    errors: list[str],
) -> None:
    """Validate exact schedule-diagnostic coverage and occurrence parity."""
    audit_ids = [str(row.get("dagId") or "") for row in audits]
    if any(not dag_id for dag_id in audit_ids):
        errors.append("schedule diagnostics must identify a DAG")
    duplicate_audits = sorted(
        dag_id for dag_id, count in Counter(audit_ids).items() if dag_id and count > 1
    )
    if duplicate_audits:
        errors.append(
            f"duplicate schedule diagnostics for DAGs: {duplicate_audits[:5]}"
        )
    audit_dag_set = set(audit_ids)
    if audit_dag_set != known_dags:
        missing = sorted(known_dags - audit_dag_set)
        unknown = sorted(audit_dag_set - known_dags)
        errors.append(
            "schedule diagnostic DAG coverage mismatch "
            f"missing={missing[:5]} unknown={unknown[:5]}"
        )
    audit_occurrences = {
        str(row.get("dagId") or ""): int(row.get("occurrences") or 0) for row in audits
    }
    for dag_id in known_dags:
        if audit_occurrences.get(dag_id, -1) != future_by_dag.get(dag_id, 0):
            errors.append(f"schedule diagnostic occurrences mismatch for DAG {dag_id}")


def _validate_tag_ledgers(
    context: PayloadAssemblyContext, errors: list[str]
) -> Mapping[str, Any]:
    """Validate tag universe, source counts, and filter options together."""
    declared = {str(tag).strip() for tag in context.tags if str(tag).strip()}
    actual = {
        str(tag).strip()
        for row in (*context.dags, *context.runs, *context.future)
        for tag in row.get("tags", [])
        if str(tag).strip()
    }
    if declared != actual:
        errors.append(
            "tag universe mismatch "
            f"missing={sorted(actual - declared)[:5]} "
            f"unknown={sorted(declared - actual)[:5]}"
        )
    source = context.historical_tag_source
    _validate_historical_tag_source(context.historical_tag_runs, source, errors)
    _validate_historical_tag_filter(
        context.dags,
        context.historical_tag_runs,
        context.tag_filter_options,
        errors,
    )
    return source


def _validate_payload_relationships(
    context: PayloadAssemblyContext, errors: list[str]
) -> dict[str, list[Mapping[str, Any]]]:
    """Validate identity, segments, counts, windows, and schedule parity."""
    _, known_dags = _validate_unique_payload_ids(
        context.runs, context.future, context.dags, errors
    )
    segments = _validate_historical_segments(context.runs, errors)
    future_by_dag = _validate_dag_and_summary_ledgers(
        context.dags,
        context.future,
        context.runs,
        segments,
        context.summary,
        errors,
    )
    _validate_bucket_and_window_ledgers(
        context.sparse_buckets,
        context.free,
        context.critical_indexes,
        context.total_buckets,
        errors,
    )
    _validate_schedule_diagnostics(context.audits, known_dags, future_by_dag, errors)
    return segments


def _integrity_result(
    context: PayloadAssemblyContext,
    segments: Mapping[str, Sequence[Mapping[str, Any]]],
    source: Mapping[str, Any],
) -> dict[str, Any]:
    """Return the stable integrity evidence schema after every check passes."""
    return {
        "status": "PASS",
        "checks": {
            "uniqueHistoricalRows": True,
            "uniqueFutureRows": True,
            "dagReferences": True,
            "sourceRunSegments": True,
            "dagCounts": True,
            "summaryParity": True,
            "bucketIndexes": True,
            "freeWindowOrdering": True,
            "scheduleOccurrenceParity": True,
            "tagUniverseParity": True,
            "historicalTagSourceParity": True,
            "historicalTagFilterParity": True,
        },
        "counts": {
            "historicalSourceRuns": len(segments),
            "historicalSegments": len(context.runs),
            "futureOccurrences": len(context.future),
            "dagMetadataRows": len(context.dags),
            "sparseBuckets": len(context.sparse_buckets),
            "totalBuckets": context.total_buckets,
            "freeWindows": len(context.free),
            "criticalWindows": len(context.critical_indexes),
            "scheduleDiagnostics": len(context.audits),
            "historicalTagSourceRuns": int(source.get("sourceRunCount") or 0),
            "historicalTagSourceDags": int(source.get("dagCount") or 0),
            "historicalTagFilterOptions": len(context.tag_filter_options),
        },
        "derivationContract": "canonical-ledger-v2",
    }


def payload_integrity(context: PayloadAssemblyContext) -> dict[str, Any]:
    """Validate cross-section payload identities, counts, and ledgers."""
    errors: list[str] = []
    source = _validate_tag_ledgers(context, errors)
    segments = _validate_payload_relationships(context, errors)
    if errors:
        fail("payload data-wiring integrity failed: " + "; ".join(errors[:12]))
    return _integrity_result(context, segments, source)
