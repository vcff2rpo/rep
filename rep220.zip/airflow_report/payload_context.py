# SPDX-License-Identifier: Apache-2.0
"""Typed, bounded assembly context for the canonical renderer payload."""

from __future__ import annotations

from .aggregation import report_display_end, unique_source_runs
from .analytics import historical_analytics_payload
from .models import Report, Run
from .payload_metadata import (
    critical_window_indexes,
    projection_payload,
    summary_payload,
)
from .payload_rows import (
    bucket_payload,
    calendar_payload,
    dag_payload,
    free_window_payload,
    future_payload,
    historical_ledger_sha256,
    historical_tag_filter_payload,
    historical_tag_source_payload,
    run_payload,
    schedule_audit_payload,
)
from .preamble import Any, Sequence, dataclass, pendulum


@dataclass(frozen=True, slots=True)
class PayloadAssemblyContext:
    """Hold each derived payload ledger exactly once during assembly."""

    report: Report
    source_runs: tuple[Run, ...]
    calendar_days: list[dict[str, Any]]
    runs: list[dict[str, Any]]
    future: list[dict[str, Any]]
    dags: list[dict[str, Any]]
    sparse_buckets: list[list[Any]]
    free: list[dict[str, Any]]
    audits: list[dict[str, Any]]
    display_end: pendulum.DateTime
    total_buckets: int
    critical_indexes: tuple[int, ...]
    summary: dict[str, Any]
    tags: list[str]
    historical_tag_runs: Sequence[Run]
    historical_tag_source: dict[str, Any]
    tag_filter_options: list[dict[str, Any]]
    non_empty_buckets: int
    empty_buckets: int
    historical_sha256: str
    future_projection: dict[str, Any]
    historical_analytics: dict[str, Any]


def build_payload_context(report: Report) -> PayloadAssemblyContext:
    """Derive every payload section once with bounded intermediates."""
    source_runs = unique_source_runs(report.runs)
    calendar_days = calendar_payload(report)
    runs = run_payload(report)
    future = future_payload(report)
    dags = dag_payload(report, source_runs)
    sparse_buckets = bucket_payload(report)
    free = free_window_payload(report)
    audits = schedule_audit_payload(report)
    display_end = report_display_end(report)
    total_buckets = len(report.buckets)
    critical_indexes = critical_window_indexes(report)
    summary = summary_payload(
        report, source_runs, calendar_days, runs, dags, future, audits, free
    )
    tags = sorted(
        {str(tag) for row in (*dags, *runs, *future) for tag in row.get("tags", [])},
        key=str.casefold,
    )
    historical_tag_runs = report.historical_tag_source_runs or report.runs
    historical_tag_source = historical_tag_source_payload(report, historical_tag_runs)
    tag_filter_options = historical_tag_filter_payload(report.dags, historical_tag_runs)
    non_empty_buckets = len(sparse_buckets)
    return PayloadAssemblyContext(
        report=report,
        source_runs=source_runs,
        calendar_days=calendar_days,
        runs=runs,
        future=future,
        dags=dags,
        sparse_buckets=sparse_buckets,
        free=free,
        audits=audits,
        display_end=display_end,
        total_buckets=total_buckets,
        critical_indexes=critical_indexes,
        summary=summary,
        tags=tags,
        historical_tag_runs=historical_tag_runs,
        historical_tag_source=historical_tag_source,
        tag_filter_options=tag_filter_options,
        non_empty_buckets=non_empty_buckets,
        empty_buckets=max(0, total_buckets - non_empty_buckets),
        historical_sha256=historical_ledger_sha256(runs),
        future_projection=projection_payload(report, future, audits),
        historical_analytics=historical_analytics_payload(report),
    )
