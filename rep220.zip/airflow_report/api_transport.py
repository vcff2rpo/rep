# SPDX-License-Identifier: Apache-2.0
"""TLS admission, immutable CA snapshots and transport failure classification."""
from __future__ import annotations

from .configuration_errors import fail
from .configuration_security import absolute_path_without_resolving, read_bounded_regular_file, redact_secret_text
from .preamble import LOG, MAX_CA_BUNDLE_BYTES, AirflowFailException, Any, Mapping, Path, conf, hashlib, os, requests, tempfile, urlsplit

class ApiTransportPolicy:
    __slots__ = ()

    def enforce_transport_policy(self, mode: str) -> None:
        """Enforce HTTPS unless an explicit local exception is configured."""
        scheme = urlsplit(self.base_url()).scheme
        if scheme == "https":
            return
        if not self.config.allow_insecure_http_auth:
            fail(
                "API traffic requires HTTPS; set ALLOW_INSECURE_HTTP_AUTH=true "
                "only for an explicitly approved local exception"
            )
        self.stats.insecure_http_auth = True
        LOG.warning(
            "SECURITY WARNING: API traffic is using plaintext HTTP by explicit "
            "override auth_mode=%s",
            mode,
        )
    def _snapshot_ca_path(self, value: object, source: str) -> str:
        """Copy one verified CA bundle into a private immutable snapshot."""
        text = str(value or "").strip()
        if not text:
            fail(f"{source} must contain a non-empty CA bundle path")
        source_path = absolute_path_without_resolving(text, source)
        payload, _device, _inode = read_bounded_regular_file(
            source_path,
            MAX_CA_BUNDLE_BYTES,
            f"TLS CA bundle from {source}",
            verify_stable_content=True,
        )
        if not payload.strip():
            fail(f"TLS CA bundle from {source} is empty")
        if self._tls_snapshot_dir is None:
            self._tls_snapshot_dir = tempfile.TemporaryDirectory(
                prefix="airflow-runtime-report-ca-"
            )
        snapshot = Path(self._tls_snapshot_dir.name) / (
            "ca-" + hashlib.sha256(payload).hexdigest()[:16] + ".pem"
        )
        if not snapshot.exists():
            descriptor = os.open(
                snapshot,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
                0o600,
            )
            try:
                view = memoryview(payload)
                while view:
                    written = os.write(descriptor, view)
                    if written <= 0:
                        raise OSError("CA snapshot write made no forward progress")
                    view = view[written:]
                os.fsync(descriptor)
            except OSError as exc:
                raise AirflowFailException(
                    f"TLS CA snapshot creation failed: {redact_secret_text(exc, 300)}"
                ) from exc
            finally:
                os.close(descriptor)
        return str(snapshot)
    @staticmethod
    def _verify_boolean(value: object) -> bool | None:
        """Interpret a connection-extra value as an optional Boolean."""
        if isinstance(value, bool):
            return value
        if isinstance(value, int) and value in {0, 1}:
            return bool(value)
        normalized = str(value or "").strip().lower()
        if normalized in {"", "1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
        return None
    def _connection_ca_candidates(
        self, extra: Mapping[str, Any]
    ) -> tuple[list[tuple[str, str]], bool | None]:
        """Collect CA snapshots in declared precedence without choosing a winner."""
        candidates: list[tuple[str, str]] = []
        for key in ("ca_cert", "ca_bundle", "ssl_ca_file", "tls_ca_bundle"):
            if key in extra and extra.get(key) not in (None, ""):
                candidates.append(
                    (
                        key,
                        self._snapshot_ca_path(extra[key], f"connection extra {key!r}"),
                    )
                )

        verify_value = extra.get("verify") if "verify" in extra else None
        verify_boolean = (
            self._verify_boolean(verify_value) if "verify" in extra else None
        )
        if "verify" in extra and verify_boolean is None:
            candidates.append(
                (
                    "verify",
                    self._snapshot_ca_path(verify_value, "connection extra 'verify'"),
                )
            )
        return candidates, verify_boolean
    def _connection_tls_setting(self) -> tuple[bool | str | None, str | None]:
        """Resolve TLS settings after checking all explicit sources for conflicts."""
        if self.request_credential is not None:
            return None, None
        candidates, verify_boolean = self._connection_ca_candidates(
            self.connection().extra_dejson or {}
        )

        distinct_paths = {path for _, path in candidates}
        if len(distinct_paths) > 1:
            sources = ", ".join(source for source, _ in candidates)
            fail(f"conflicting TLS CA bundle paths configured in {sources}")
        if verify_boolean is False and candidates:
            fail(
                "connection TLS configuration conflicts: verify=false with a CA bundle"
            )
        if candidates:
            sources = ",".join(source for source, _ in candidates)
            return candidates[0][1], f"connection-extra:{sources}"
        if verify_boolean is not None:
            return verify_boolean, "connection-extra:verify"
        return None, None
    def _airflow_api_ssl_cert(self) -> str | None:
        """Resolve the Airflow API CA bundle setting when configured."""
        value = str(conf.get("api", "ssl_cert", fallback="") or "").strip()
        if not value:
            return None
        return self._snapshot_ca_path(value, "Airflow [api] ssl_cert")
    def _resolved_tls_setting(self) -> tuple[bool | str, str]:
        """Resolve the final TLS verification value and provenance."""
        explicit, source = self._connection_tls_setting()
        if explicit is False:
            return False, source or "connection-extra:verify"
        if isinstance(explicit, str):
            return explicit, source or "connection-extra:ca-bundle"

        airflow_cert = self._airflow_api_ssl_cert()
        if airflow_cert:
            return airflow_cert, "airflow-config:[api] ssl_cert"
        return True, source or "system-trust-store"
    def verify_setting(self) -> bool | str:
        """Return the cached Requests TLS verification setting."""
        if self._tls_verify is not None:
            return self._tls_verify
        verified, source = self._resolved_tls_setting()
        if verified is False:
            if not self.config.allow_insecure_tls:
                fail(
                    "TLS verification is disabled; set ALLOW_INSECURE_TLS=true "
                    "only for an explicitly approved exception"
                )
            self.stats.insecure_tls = True
            LOG.warning(
                "SECURITY WARNING: API TLS certificate verification is disabled "
                "by explicit override"
            )
        self._tls_verify = verified
        self._tls_verify_source = source
        LOG.debug(
            "REPORT | API_TLS | mode=%s | source=%s",
            "disabled"
            if verified is False
            else ("ca-bundle" if isinstance(verified, str) else "system-store"),
            source,
        )
        return verified
    def _tls_failure_message(
        self, method: str, endpoint: str, exc: requests.exceptions.SSLError
    ) -> str:
        """Build an actionable, redacted TLS verification failure message."""
        source = self._tls_verify_source or "unresolved"
        if self._tls_verify is True:
            remediation = (
                "configure a readable PEM CA bundle in connection extra 'ca_cert' "
                "or configure Airflow [api] ssl_cert for the self-signed API certificate"
            )
        else:
            remediation = (
                "verify that the configured PEM bundle contains the issuing CA or "
                "self-signed server certificate and that the URL hostname matches "
                "the certificate SAN"
            )
        return (
            f"{method} {endpoint} TLS certificate verification failed "
            f"(trust_source={source}); {remediation}: "
            f"{redact_secret_text(exc, 240)}"
        )
