# SPDX-License-Identifier: Apache-2.0
"""Fail-closed validation primitives for the single API pagination state machine."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from typing import Any

from .configuration_errors import fail
from .models import ApiStats, Config


def remaining_capacity(
    config: Config, stats: ApiStats, resource: str, rows: Sequence[object]
) -> int:
    """Return remaining row capacity or fail with an incomplete ledger."""
    remaining = config.max_rows - len(rows)
    if remaining > 0:
        return remaining
    stats.max_rows_hit = True
    stats.mark_incomplete(f"{resource}:max_rows")
    fail(f"{resource} reached max_rows={config.max_rows} before completion")


def valid_page_members(
    stats: ApiStats,
    payload: Mapping[str, Any],
    collection_key: str,
    resource: str,
    remaining: int,
) -> tuple[list[dict[str, Any]], list[object], int]:
    """Validate one paginated collection and count malformed members."""
    chunk = payload.get(collection_key)
    if not isinstance(chunk, list):
        stats.mark_incomplete(f"{resource}:missing_collection")
        fail(f"{resource} response is missing list key {collection_key!r}")
    stats.input_members += len(chunk)
    valid = [item for item in chunk if isinstance(item, dict)]
    rejected = len(chunk) - len(valid)
    stats.accepted_members += len(valid)
    if rejected:
        stats.rejected_members += rejected
        stats.mark_incomplete(f"{resource}:malformed_members={rejected}")
    if len(valid) > remaining:
        stats.max_rows_hit = True
        stats.mark_incomplete(f"{resource}:remaining_row_capacity")
        fail(f"{resource} response exceeded remaining row capacity={remaining}")
    return valid, chunk, rejected


def remember_page(
    config: Config,
    stats: ApiStats,
    chunk: Sequence[object],
    seen_pages: set[str],
    resource: str,
) -> None:
    """Detect repeated pages using a bounded page-fingerprint set."""
    fingerprint = hashlib.sha256(
        json.dumps(chunk, sort_keys=True, separators=(",", ":"), default=str).encode(
            "utf-8"
        )
    ).hexdigest()
    if chunk and fingerprint in seen_pages:
        stats.repeated_pages_stopped += 1
        stats.mark_incomplete(f"{resource}:repeated_page")
        fail(
            f"pagination repeated page for {resource}; "
            "report completeness cannot be proven"
        )
    if len(seen_pages) >= config.max_request_fingerprints:
        stats.mark_incomplete(f"{resource}:page_fingerprint_budget")
        fail(
            f"{resource} exceeded page fingerprint budget="
            f"{config.max_request_fingerprints}"
        )
    seen_pages.add(fingerprint)


def record_page(stats: ApiStats, valid: Sequence[object]) -> None:
    """Update page, row, and peak-page telemetry."""
    stats.pages += 1
    stats.rows += len(valid)
    stats.peak_page_rows = max(stats.peak_page_rows, len(valid))


def validated_page_total(
    stats: ApiStats,
    payload: Mapping[str, Any],
    resource: str,
    offset: int,
    previous_total: int | None,
) -> int:
    """Validate stable pagination totals across all pages."""
    has_snake = "total_entries" in payload
    has_camel = "totalEntries" in payload
    if not has_snake and not has_camel:
        stats.mark_incomplete(f"{resource}:missing_total_entries")
        fail(f"{resource} response is missing pagination total_entries")
    if has_snake and has_camel and payload["total_entries"] != payload["totalEntries"]:
        stats.mark_incomplete(f"{resource}:conflicting_total_entries")
        fail(f"{resource} response contains conflicting pagination totals")
    total = payload["total_entries"] if has_snake else payload["totalEntries"]
    if isinstance(total, bool) or not isinstance(total, int):
        stats.mark_incomplete(f"{resource}:invalid_total_entries_type")
        fail(f"{resource} pagination total_entries must be a non-negative integer")
    if total < 0:
        stats.mark_incomplete(f"{resource}:negative_total_entries")
        fail(f"{resource} pagination total_entries must not be negative")
    if previous_total is not None and total != previous_total:
        stats.mark_incomplete(f"{resource}:changed_total_entries")
        fail(
            f"{resource} pagination total_entries changed from "
            f"{previous_total} to {total}"
        )
    if total < offset:
        stats.mark_incomplete(f"{resource}:total_below_offset")
        fail(
            f"{resource} pagination total_entries={total} is below "
            f"observed offset={offset}"
        )
    return total


def page_complete(
    stats: ApiStats,
    chunk: Sequence[object],
    request_limit: int,
    offset: int,
    total: int,
    resource: str,
) -> bool:
    """Determine whether pagination completed without a short or empty page."""
    if offset == total:
        return True
    if not chunk:
        stats.mark_incomplete(f"{resource}:premature_empty_page")
        fail(
            f"{resource} returned an empty page before total_entries={total} "
            f"was reached at offset={offset}"
        )
    if len(chunk) < request_limit:
        stats.mark_incomplete(f"{resource}:premature_short_page")
        fail(
            f"{resource} returned a short page before total_entries={total} "
            f"was reached at offset={offset}"
        )
    return False


def validated_row_limit(
    config: Config,
    resource: str,
    row_limit: int | None,
) -> int | None:
    """Validate an optional local page-window cap."""
    if row_limit is not None and not 0 <= row_limit <= config.max_rows:
        fail(f"{resource} row_limit must be between 0 and {config.max_rows}")
    return row_limit


def pagination_request_limit(
    config: Config,
    stats: ApiStats,
    resource: str,
    accepted_rows: Sequence[object],
    row_limit: int | None,
) -> tuple[int, int]:
    """Return global capacity and the next bounded request size."""
    global_remaining = remaining_capacity(config, stats, resource, accepted_rows)
    local_remaining = (
        row_limit - len(accepted_rows) if row_limit is not None else global_remaining
    )
    return global_remaining, min(
        config.page_limit,
        global_remaining,
        local_remaining,
    )


def page_window_complete(
    stats: ApiStats,
    chunk: Sequence[object],
    request_limit: int,
    offset: int,
    total: int,
    accepted_count: int,
    row_limit: int,
    resource: str,
) -> bool:
    """Evaluate bounded-window completion without weakening page integrity."""
    if offset == total or accepted_count >= row_limit:
        return True
    if not chunk or len(chunk) < request_limit:
        stats.mark_incomplete(f"{resource}:premature_page")
        fail(f"{resource} pagination ended before total_entries={total}")
    return False
