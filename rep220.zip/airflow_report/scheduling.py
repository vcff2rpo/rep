# SPDX-License-Identifier: Apache-2.0
"""Future-schedule expansion, demand counting, and fair allocation."""

from __future__ import annotations

from .configuration_values import stable_id
from .models import Config, DagInfo, FutureRun, ScheduleAudit
from .preamble import (
    MAX_TOTAL_TIMELINE_ITEMS_HARD,
    CroniterBadCronError,
    Mapping,
    Sequence,
    croniter,
    dataclass,
    datetime,
    heapq,
    math,
    pendulum,
)


def cron_seed(
    info: DagInfo, start: pendulum.DateTime, end: pendulum.DateTime, limit: int
) -> tuple[str, list[pendulum.DateTime], set[str], pendulum.DateTime, bool]:
    """Choose a stable cron-iteration seed around the projection anchor."""
    timezone = info.schedule_timezone
    if not timezone:
        raise ValueError("cron schedule timezone is unavailable")
    authoritative = (
        info.next_run.in_timezone(timezone) if info.next_run is not None else None
    )
    values: list[pendulum.DateTime] = []
    seen: set[str] = set()
    if authoritative is not None and authoritative >= end:
        return timezone, values, seen, start.in_timezone(timezone), True
    if authoritative is not None and authoritative > start:
        values.append(authoritative)
        seen.add(authoritative.in_timezone("UTC").to_iso8601_string())
        return timezone, values, seen, authoritative, len(values) >= limit
    return timezone, values, seen, start.in_timezone(timezone), False


def expand_cron(
    info: DagInfo, start: pendulum.DateTime, end: pendulum.DateTime, limit: int
) -> tuple[list[pendulum.DateTime], bool]:
    """Expand one cron schedule within a bounded interval."""
    expression = info.schedule_expression.strip()
    if len(expression.split()) not in {5, 6}:
        raise ValueError("unsupported cron field count")
    timezone, values, seen, base, complete = cron_seed(info, start, end, limit)
    if complete:
        return values, bool(values and len(values) >= limit)
    try:
        iterator = croniter(expression, base, ret_type=datetime)
    except (CroniterBadCronError, ValueError, KeyError) as exc:
        raise ValueError(f"croniter rejected expression: {exc}") from exc
    guard_limit = max(limit * 4 + 32, 128)
    for _ in range(guard_limit):
        try:
            value = iterator.get_next(datetime)
            candidate = (
                value.in_timezone(timezone)
                if isinstance(value, pendulum.DateTime)
                else pendulum.instance(value, tz=timezone)
                if value.tzinfo is None
                else pendulum.instance(value).in_timezone(timezone)
            )
        except (CroniterBadCronError, ValueError, OverflowError) as exc:
            raise ValueError(f"cron iteration failed: {exc}") from exc
        if candidate >= end:
            return values, False
        if candidate <= start:
            continue
        key = candidate.in_timezone("UTC").to_iso8601_string()
        if key in seen:
            continue
        if len(values) >= limit:
            return values, True
        seen.add(key)
        values.append(candidate)
    raise ValueError("cron iteration guard exceeded")


def expand_interval(
    info: DagInfo,
    start: pendulum.DateTime,
    end: pendulum.DateTime,
    limit: int,
) -> tuple[list[pendulum.DateTime], bool]:
    """Expand one interval schedule within a bounded interval."""
    seconds = float(info.schedule_expression)
    if info.next_run is None or not math.isfinite(seconds) or seconds <= 0:
        return [], False
    current = info.next_run
    if current <= start:
        delta = (start - current).total_seconds()
        steps = math.floor(delta / seconds) + 1
        advance = steps * seconds
        remaining = (end - current).total_seconds()
        if not math.isfinite(advance) or advance >= remaining:
            return [], False
        current = current.add(seconds=advance)
    values: list[pendulum.DateTime] = []
    while current < end:
        if len(values) >= limit:
            return values, True
        values.append(current)
        remaining = (end - current).total_seconds()
        if seconds >= remaining:
            break
        current = current.add(seconds=seconds)
    return values, False


def projection_moments(
    info: DagInfo,
    config: Config,
    *,
    limit: int | None = None,
    effective_end: pendulum.DateTime | None = None,
) -> tuple[list[pendulum.DateTime], bool, bool, str]:
    """Return future moments for one DAG with an explicit expansion ceiling."""
    eligible = info.eligible
    reason = info.exclusion_reason
    if not eligible:
        return [], False, False, reason
    end = effective_end or config.future_effective_end
    if end is None:
        return [], False, False, "projection horizon is unavailable"
    expansion_limit = max(1, limit or config.max_future_per_dag)
    try:
        if info.schedule_kind in {"cron", "preset"}:
            moments, truncated = expand_cron(
                info, config.trigger_time, end, expansion_limit
            )
        elif info.schedule_kind == "interval":
            moments, truncated = expand_interval(
                info, config.trigger_time, end, expansion_limit
            )
        elif info.next_run is not None and config.trigger_time < info.next_run < end:
            moments, truncated = [info.next_run], False
        else:
            moments, truncated = [], False
            if info.next_run is not None:
                reason = "authoritative next run is outside the effective horizon"
    except (TypeError, ValueError, OverflowError) as exc:
        return [], False, False, f"unsupported or malformed schedule: {exc}"
    return moments, truncated, True, reason


def future_demand(
    config: Config,
    dags: Mapping[str, DagInfo],
    effective_end: pendulum.DateTime | None,
    *,
    stop_after: int,
) -> tuple[int, int]:
    """Count exact future demand up to one overflow sentinel.

    The second return value is the number of eligible DAGs with at least one
    occurrence in the candidate horizon.
    """
    if not config.future_enabled or effective_end is None:
        return 0, 0
    total = 0
    active_dags = 0
    sentinel = max(1, stop_after + 1)
    for info in sorted(dags.values(), key=lambda item: item.dag_id.casefold()):
        moments, truncated, eligible, _ = projection_moments(
            info,
            config,
            limit=sentinel,
            effective_end=effective_end,
        )
        if not eligible or not moments:
            continue
        active_dags += 1
        total += len(moments)
        if truncated or total > stop_after:
            return sentinel, active_dags
    return total, active_dags


def _future_run(info: DagInfo, moment: pendulum.DateTime, config: Config) -> FutureRun:
    """Construct one canonical future occurrence."""
    key = (
        info.dag_id,
        moment.in_timezone("UTC").to_iso8601_string(),
        info.schedule_source,
    )
    return FutureRun(
        projection_id=stable_id("future", *key),
        dag_id=info.dag_id,
        projected_at=moment.in_timezone(config.timezone),
        schedule_kind=info.schedule_kind,
        schedule_summary=info.schedule_summary,
        schedule_timezone=info.schedule_timezone,
        source=info.schedule_source,
        paused=info.paused,
        owner=info.owner,
        tags=info.tags,
    )


def _effective_target(
    available: Mapping[str, Sequence[pendulum.DateTime]],
    budget: int,
    configured: int,
) -> int:
    """Return the largest common per-DAG reserve target that fits."""
    for target in range(max(0, configured), -1, -1):
        required = sum(min(target, len(values)) for values in available.values())
        if required <= budget:
            return target
    return 0


def _allocate_future(
    available: Mapping[str, Sequence[pendulum.DateTime]],
    budget: int,
    configured_target: int,
) -> tuple[dict[str, tuple[pendulum.DateTime, ...]], int]:
    """Reserve equal DAG coverage, then assign remaining points chronologically."""
    selected: dict[str, list[pendulum.DateTime]] = {dag_id: [] for dag_id in available}
    if budget <= 0 or not available:
        return {key: () for key in available}, 0
    target = _effective_target(available, budget, configured_target)
    used = 0
    offsets: dict[str, int] = {}
    for dag_id in sorted(available, key=str.casefold):
        reserve = min(target, len(available[dag_id]), budget - used)
        if reserve > 0:
            selected[dag_id].extend(available[dag_id][:reserve])
        offsets[dag_id] = reserve
        used += reserve
    heap: list[tuple[pendulum.DateTime, str, int]] = []
    for dag_id, values in available.items():
        offset = offsets[dag_id]
        if offset < len(values):
            heapq.heappush(
                heap,
                (values[offset].in_timezone("UTC"), dag_id, offset),
            )
    while heap and used < budget:
        _, dag_id, index = heapq.heappop(heap)
        values = available[dag_id]
        selected[dag_id].append(values[index])
        used += 1
        next_index = index + 1
        if next_index < len(values):
            heapq.heappush(
                heap,
                (values[next_index].in_timezone("UTC"), dag_id, next_index),
            )
    return {key: tuple(values) for key, values in selected.items()}, target


def disabled_projection_audits(
    dags: Mapping[str, DagInfo], configured_target: int = 20
) -> tuple[ScheduleAudit, ...]:
    """Build zero-occurrence audits when projection is disabled."""
    return tuple(
        ScheduleAudit(
            dag_id=info.dag_id,
            source=info.schedule_source,
            kind=info.schedule_kind,
            eligible=False,
            reason="projection disabled",
            detail_status=info.detail_status,
            occurrences=0,
            available_occurrences=0,
            omitted_occurrences=0,
            configured_target=configured_target,
            effective_target=0,
            coverage_status="excluded",
            truncated=False,
        )
        for info in sorted(dags.values(), key=lambda item: item.dag_id.casefold())
    )


@dataclass(frozen=True, slots=True)
class _ProjectionCandidate:
    """Contain one bounded schedule expansion before capacity allocation."""

    info: DagInfo
    moments: tuple[pendulum.DateTime, ...]
    source_truncated: bool
    reason: str


def _projection_candidates(
    config: Config, dags: Mapping[str, DagInfo]
) -> tuple[dict[str, _ProjectionCandidate], dict[str, tuple[pendulum.DateTime, ...]]]:
    """Expand each schedule once and expose only eligible non-empty candidates."""
    candidates: dict[str, _ProjectionCandidate] = {}
    available: dict[str, tuple[pendulum.DateTime, ...]] = {}
    for info in sorted(dags.values(), key=lambda item: item.dag_id.casefold()):
        moments, source_truncated, eligible, reason = projection_moments(info, config)
        candidate = _ProjectionCandidate(
            info=info,
            moments=tuple(moments),
            source_truncated=source_truncated,
            reason=reason,
        )
        candidates[info.dag_id] = candidate
        if eligible and candidate.moments:
            available[info.dag_id] = candidate.moments
    return candidates, available


def _projection_audit_status(
    candidate: _ProjectionCandidate,
    emitted_count: int,
    configured_target: int,
) -> tuple[bool, str, str]:
    """Classify one projected DAG without altering allocation semantics."""
    available_count = len(candidate.moments)
    omitted_count = max(0, available_count - emitted_count)
    eligible = candidate.info.eligible and not candidate.reason.startswith(
        "unsupported or malformed schedule"
    )
    if not eligible:
        return False, "excluded", candidate.reason or "excluded"
    if available_count == 0:
        return (
            True,
            "eligible-no-occurrence",
            candidate.reason or "eligible schedule has no occurrence in horizon",
        )
    if emitted_count == 0:
        return (
            True,
            "eligible-omitted-capacity",
            "eligible schedule omitted by future capacity",
        )
    if omitted_count == 0:
        return True, "eligible-complete", "projected"
    if emitted_count >= min(configured_target, available_count):
        return (
            True,
            "eligible-covered-20",
            "future capacity retained configured DAG coverage target",
        )
    return (
        True,
        "eligible-partially-truncated",
        "future reserve target reduced by capacity",
    )


def _project_candidate(
    config: Config,
    candidate: _ProjectionCandidate,
    emitted_moments: tuple[pendulum.DateTime, ...],
    effective_target: int,
) -> tuple[list[FutureRun], ScheduleAudit]:
    """Create projected rows and one complete schedule-audit record."""
    info = candidate.info
    available_count = len(candidate.moments)
    emitted_count = len(emitted_moments)
    omitted_count = max(0, available_count - emitted_count)
    eligible, status, reason = _projection_audit_status(
        candidate, emitted_count, config.future_target_per_dag
    )
    audit = ScheduleAudit(
        dag_id=info.dag_id,
        source=info.schedule_source,
        kind=info.schedule_kind,
        eligible=eligible,
        reason=reason,
        detail_status=info.detail_status,
        occurrences=emitted_count,
        available_occurrences=available_count,
        omitted_occurrences=omitted_count,
        configured_target=config.future_target_per_dag,
        effective_target=min(effective_target, available_count),
        coverage_status=status,
        truncated=candidate.source_truncated or omitted_count > 0,
    )
    return [_future_run(info, moment, config) for moment in emitted_moments], audit


def project(
    config: Config,
    dags: Mapping[str, DagInfo],
    *,
    historical_items: int = 0,
) -> tuple[tuple[FutureRun, ...], tuple[ScheduleAudit, ...], int]:
    """Project schedules with reserve-then-chronological fair allocation."""
    if not config.future_enabled or config.future_effective_end is None:
        return (), disabled_projection_audits(dags, config.future_target_per_dag), 0
    budget = min(
        config.max_future_occurrences,
        max(0, MAX_TOTAL_TIMELINE_ITEMS_HARD - historical_items),
    )
    candidates, available = _projection_candidates(config, dags)
    allocated, effective_target = _allocate_future(
        available, budget, config.future_target_per_dag
    )
    future: list[FutureRun] = []
    audits: list[ScheduleAudit] = []
    for dag_id in sorted(candidates, key=str.casefold):
        rows, audit = _project_candidate(
            config, candidates[dag_id], allocated.get(dag_id, ()), effective_target
        )
        future.extend(rows)
        audits.append(audit)
    future.sort(
        key=lambda item: (item.projected_at, item.dag_id.casefold(), item.projection_id)
    )
    return tuple(future), tuple(audits), effective_target
