# SPDX-License-Identifier: Apache-2.0
"""Strict scalar parsing, normalization, runtime parameter provenance, and IDs."""

from __future__ import annotations

from .configuration_errors import fail
from .configuration_security import redact_secret_text
from .preamble import (
    EMAIL_RE,
    ENV_PREFIX,
    ISO_DATE_RE,
    LOG,
    REPORT_PARAM_NAMES,
    STATE_ALIASES,
    AirflowFailException,
    Any,
    Mapping,
    datetime,
    get_current_context,
    hashlib,
    math,
    os,
    pendulum,
    re,
)


def env(name: str, default: object) -> object:
    """Read a namespaced environment value or return its default."""
    value = os.getenv(f"{ENV_PREFIX}{name}")
    return default if value in (None, "") else value


def parse_bool(value: object, label: str) -> bool:
    """Parse a strict Boolean configuration value."""
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and value in {0, 1}:
        return bool(value)
    normalized = str(value).strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    fail(f"invalid boolean {label}; expected true/false")


def parse_int(value: object, label: str, minimum: int, maximum: int) -> int:
    """Parse a strict bounded integer without implicit object coercion."""
    if isinstance(value, bool):
        fail(f"invalid integer {label}")
    if isinstance(value, int):
        result = value
    elif isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            fail(f"invalid integer {label}")
        result = int(value)
    elif isinstance(value, str):
        text = value.strip()
        if not re.fullmatch(r"[+-]?\d+", text):
            fail(f"invalid integer {label}")
        result = int(text, 10)
    else:
        fail(f"invalid integer {label}")
    if not minimum <= result <= maximum:
        fail(f"{label} must be between {minimum} and {maximum}")
    return result


def parse_float(value: object, label: str, minimum: float, maximum: float) -> float:
    """Parse a bounded finite floating-point configuration value."""
    if isinstance(value, bool):
        fail(f"invalid number {label}")
    try:
        result = float(str(value).replace(",", "."))
    except (TypeError, ValueError) as exc:
        raise AirflowFailException(f"invalid number {label}") from exc
    if not minimum <= result <= maximum:
        fail(f"{label} must be between {minimum} and {maximum}")
    return result


def choice(value: object, label: str, allowed: set[str]) -> str:
    """Normalize and validate one enumerated string choice."""
    result = str(value or "").strip().lower().replace("-", "_")
    if result not in allowed:
        fail(f"invalid {label}; expected one of {sorted(allowed)}")
    return result


def parsed_datetime(value: object, timezone: str, label: str) -> pendulum.DateTime:
    """Parse one timezone-aware datetime value."""
    parsed = pendulum.parse(str(value), tz=timezone)
    if not isinstance(parsed, pendulum.DateTime):
        fail(f"invalid {label}; expected a date or datetime")
    return parsed


def parse_datetime(
    value: object, timezone: str, label: str, *, date_end: bool = False
) -> pendulum.DateTime:
    """Parse and normalize one required date or datetime parameter."""
    if value in (None, ""):
        fail(f"missing {label}")
    try:
        if isinstance(value, datetime):
            parsed = pendulum.instance(value).in_timezone(timezone)
        else:
            text = str(value).strip()
            if ISO_DATE_RE.fullmatch(text):
                parsed = parsed_datetime(text, timezone, label).start_of("day")
                if date_end:
                    parsed = parsed.add(days=1)
            else:
                parsed = parsed_datetime(text, timezone, label).in_timezone(timezone)
        return parsed
    except AirflowFailException:
        raise
    except (TypeError, ValueError, OverflowError) as exc:
        raise AirflowFailException(f"invalid {label}") from exc


def dt_or_none(
    row: Mapping[str, Any], timezone: str, *keys: str
) -> pendulum.DateTime | None:
    """Return the first valid datetime among candidate API fields."""
    for key in keys:
        value = row.get(key)
        if value in (None, ""):
            continue
        try:
            return parsed_datetime(value, timezone, key).in_timezone(timezone)
        except (AirflowFailException, TypeError, ValueError, OverflowError) as exc:
            LOG.warning(
                "invalid datetime field=%s error=%s", key, redact_secret_text(exc, 160)
            )
    return None


def first_text(row: Mapping[str, Any], *keys: str) -> str:
    """Return the first non-empty textual field from a mapping."""
    for key in keys:
        value = row.get(key)
        if value not in (None, ""):
            return str(value).strip()
    return ""


def normalize_tags(value: object) -> tuple[str, ...]:
    """Normalize tags into a deterministic non-empty tuple."""
    items: list[str] = []
    if isinstance(value, str):
        items.extend(value.split(","))
    elif isinstance(value, list):
        for item in value:
            if isinstance(item, Mapping):
                items.append(str(item.get("name") or item.get("tag") or ""))
            else:
                items.append(str(item))
    normalized = tuple(
        sorted({item.strip() for item in items if item.strip()}, key=str.casefold)
    )
    return normalized or ("untagged",)


def normalize_owner(row: Mapping[str, Any]) -> str:
    """Normalize one or more owners into deterministic display text."""
    owners = row.get("owners")
    if isinstance(owners, list):
        values = sorted(
            {str(item).strip() for item in owners if str(item).strip()},
            key=str.casefold,
        )
        return ", ".join(values) or "unknown"
    return first_text(row, "owner", "owners") or "unknown"


def normalize_state(value: object) -> str:
    """Map a raw Airflow state into the renderer state contract."""
    return STATE_ALIASES.get(str(value or "other").strip().lower(), "other")


def stable_id(*parts: object) -> str:
    """Derive a stable bounded identifier from ordered input parts."""
    raw = "\x00".join((str(part) for part in parts))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]


def iso(value: pendulum.DateTime | None) -> str | None:
    """Return an ISO-8601 string for an optional Pendulum datetime."""
    return value.to_iso8601_string() if value is not None else None


def instant_microseconds(value: pendulum.DateTime) -> int:
    """Return an exact absolute ordering key, including repeated local hours."""
    offset = value.utcoffset()
    if offset is None:
        fail("timeline instant must include a timezone")
    local = (
        value.toordinal() * 86400
        + value.hour * 3600
        + value.minute * 60
        + value.second
    ) * 1_000_000 + value.microsecond
    offset_us = (offset.days * 86400 + offset.seconds) * 1_000_000 + offset.microseconds
    return local - offset_us


def ratio(
    value: pendulum.DateTime, start: pendulum.DateTime, end: pendulum.DateTime
) -> float:
    """Return a value position clamped to a normalized interval."""
    origin = instant_microseconds(start)
    span = max(1000, instant_microseconds(end) - origin)
    return max(0.0, min(1.0, (instant_microseconds(value) - origin) / span))


def parse_email_list(value: object) -> tuple[str, ...]:
    """Parse, validate, and stably deduplicate comma/semicolon recipients."""
    raw = str(value or "").strip()
    if not raw:
        return ()
    parsed = tuple(part.strip() for part in re.split("[;,]", raw) if part.strip())
    invalid = [item for item in parsed if not EMAIL_RE.fullmatch(item)]
    if invalid:
        fail(f"invalid email address list; invalid_count={len(invalid)}")
    unique: dict[str, str] = {}
    for address in parsed:
        unique.setdefault(address.casefold(), address)
    return tuple(unique.values())


def parse_optional_mode(value: object, label: str) -> int | None:
    """Parse an optional octal directory mode."""
    text = str(value or "").strip()
    if not text:
        return None
    try:
        mode = int(text, 8)
    except ValueError as exc:
        raise AirflowFailException(f"invalid octal mode {label}") from exc
    if not 0 <= mode <= 511:
        fail(f"{label} must be an octal mode between 000 and 777")
    return mode


def current_params() -> dict[str, Any]:
    """Merge validated DAG params and dag_run.conf with provenance."""
    context = get_current_context()
    values = dict(context.get("params") or {})
    sources = {name: "params" for name in REPORT_PARAM_NAMES if name in values}
    dag_run = context.get("dag_run")
    runtime_conf = getattr(dag_run, "conf", None)
    if isinstance(runtime_conf, Mapping):
        normalized_conf = {str(key): value for key, value in runtime_conf.items()}
        unknown = sorted(set(normalized_conf) - REPORT_PARAM_NAMES)
        if unknown:
            fail(
                "unsupported DAG run conf parameter(s): "
                + ", ".join(redact_secret_text(name, 80) for name in unknown)
            )
        for name, value in normalized_conf.items():
            values[name] = value
            sources[name] = "dag_run.conf"
    values["_parameter_sources"] = sources
    values["_run_id"] = str(
        getattr(dag_run, "run_id", "") or context.get("run_id") or "manual"
    )
    task_instance = context.get("task_instance") or context.get("ti")
    values["_task_instance_key"] = str(
        getattr(task_instance, "key", "")
        or getattr(task_instance, "task_id", "")
        or "generate_runtime_report"
    )
    return values


def normalized_parameter_sources(values: Mapping[str, Any]) -> dict[str, str]:
    """Filter parameter provenance to supported names and sources."""
    raw = values.get("_parameter_sources")
    if not isinstance(raw, Mapping):
        return {}
    allowed_sources = {"params", "dag_run.conf"}
    return {
        name: str(source)
        for name, source in raw.items()
        if name in REPORT_PARAM_NAMES and str(source) in allowed_sources
    }


def api_connection_id() -> str:
    """Validate and return the configured Airflow API connection ID."""
    raw = os.getenv(f"{ENV_PREFIX}API_CONN_ID")
    value = "airflow_api" if raw is None else raw.strip()
    if not value or len(value) > 250:
        fail("invalid API_CONN_ID")
    if any(char.isspace() or ord(char) < 32 or ord(char) == 127 for char in value):
        fail("invalid API_CONN_ID; whitespace and control characters are prohibited")
    return value
