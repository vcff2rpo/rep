# SPDX-License-Identifier: Apache-2.0
"""Schedule and DAG metadata normalization."""

from __future__ import annotations

from .configuration_values import (
    dt_or_none,
    first_text,
    normalize_owner,
    normalize_tags,
    parse_bool,
)
from .models import DagInfo
from .preamble import (
    CRON_PRESETS,
    Any,
    CroniterBadCronError,
    Mapping,
    croniter,
    json,
    math,
    pendulum,
    re,
)
from .timezone_model import resolve_schedule_timezone


def schedule_raw(row: Mapping[str, Any]) -> object:
    """Return the first supported raw schedule representation."""
    for key in (
        "schedule_interval",
        "scheduleInterval",
        "schedule",
        "timetable_summary",
        "timetableSummary",
        "timetable",
        "schedule_summary",
        "scheduleSummary",
    ):
        value = row.get(key)
        if value not in (None, "", {}, []):
            return value
    return None


def schedule_text(value: object) -> str:
    """Convert a schedule payload into deterministic text."""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, Mapping):
        for key in (
            "cron",
            "expression",
            "value",
            "schedule",
            "summary",
            "description",
        ):
            item = value.get(key)
            if item not in (None, ""):
                return str(item).strip()
        return json.dumps(
            dict(value), sort_keys=True, separators=(",", ":"), default=str
        )
    return ""


def extract_cron(text: str) -> str | None:
    """Extract a supported cron expression from schedule data."""
    candidate = str(text or "").strip()
    candidates = [candidate]
    tokens = candidate.split()
    for width in (6, 5):
        for index in range(max(0, len(tokens) - width + 1)):
            candidates.append(" ".join(tokens[index : index + width]))
    seen: set[str] = set()
    for expression in candidates:
        if expression in seen or len(expression.split()) not in {5, 6}:
            continue
        seen.add(expression)
        try:
            croniter(expression, pendulum.datetime(2024, 1, 1, tz="UTC"))
        except (CroniterBadCronError, ValueError, KeyError, TypeError):
            continue
        return expression
    return None


def _finite_number(value: object) -> float | None:
    """Convert one scalar to a finite float when possible."""
    candidate: Any = value
    try:
        number = float(candidate)
    except (OverflowError, TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _positive_finite_seconds(value: object) -> float | None:
    """Convert one scalar to positive finite seconds when possible."""
    seconds = _finite_number(value)
    return seconds if seconds is not None and seconds > 0 else None


def _mapping_interval_seconds(value: Mapping[str, Any]) -> tuple[bool, float | None]:
    """Parse supported timedelta-like mapping keys and report whether handled."""
    total = 0.0
    found = False
    for key, multiplier in (
        ("days", 86400),
        ("hours", 3600),
        ("minutes", 60),
        ("seconds", 1),
    ):
        if key not in value:
            continue
        found = True
        component = _finite_number(value[key])
        if component is None:
            return True, None
        total += component * multiplier
    if not found:
        return False, None
    return True, total if math.isfinite(total) and total > 0 else None


def _iso_interval_seconds(text: str) -> float | None:
    """Parse the supported ISO-8601 day/time duration subset."""
    match = re.fullmatch(
        r"p(?:(\d+(?:\.\d+)?)d)?"
        r"(?:t(?:(\d+(?:\.\d+)?)h)?"
        r"(?:(\d+(?:\.\d+)?)m)?"
        r"(?:(\d+(?:\.\d+)?)s)?)?",
        text,
    )
    if not match:
        return None
    days, hours, minutes, seconds = (float(part or 0) for part in match.groups())
    total = days * 86400 + hours * 3600 + minutes * 60 + seconds
    return total if math.isfinite(total) and total > 0 else None


def _simple_interval_seconds(text: str) -> float | None:
    """Parse one positive number followed by a supported time unit."""
    match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*(seconds?|minutes?|hours?|days?)", text)
    if not match:
        return None
    factor = {
        "second": 1,
        "seconds": 1,
        "minute": 60,
        "minutes": 60,
        "hour": 3600,
        "hours": 3600,
        "day": 86400,
        "days": 86400,
    }[match.group(2)]
    total = float(match.group(1)) * factor
    return total if math.isfinite(total) and total > 0 else None


def interval_seconds(value: object) -> float | None:
    """Extract a positive interval schedule in seconds when supported."""
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return _positive_finite_seconds(value)
    if isinstance(value, Mapping):
        handled, seconds = _mapping_interval_seconds(value)
        if handled:
            return seconds
    text = schedule_text(value).lower()
    iso_seconds = _iso_interval_seconds(text)
    return iso_seconds if iso_seconds is not None else _simple_interval_seconds(text)


def next_run(row: Mapping[str, Any], timezone: str) -> pendulum.DateTime | None:
    """Return the next authoritative scheduled-run timestamp."""
    return dt_or_none(
        row,
        timezone,
        "next_dagrun_run_after",
        "nextDagrunRunAfter",
        "next_dagrun_logical_date",
        "nextDagrunLogicalDate",
        "next_dagrun",
        "nextDagrun",
        "next_run",
        "nextRun",
        "next_dag_run",
        "nextDagRun",
        "next_run_after_data_interval",
        "nextRunAfterDataInterval",
    )


def schedule_context(
    row: Mapping[str, Any], timezone: str
) -> tuple[object, str, str, str, bool, pendulum.DateTime | None]:
    """Return normalized schedule type, expression, summary, and timezone."""
    raw = schedule_raw(row)
    raw_text = schedule_text(raw)
    description = first_text(
        row,
        "timetable_description",
        "timetableDescription",
        "description",
        "schedule_description",
        "scheduleDescription",
    )
    timetable_type = first_text(
        row, "timetable_type", "timetableType", "schedule_type", "scheduleType"
    ).lower()
    raw_asset_flag = row.get("has_asset_schedule", row.get("hasAssetSchedule", False))
    has_asset = parse_bool(raw_asset_flag, "dag.has_asset_schedule")
    has_asset = has_asset or bool(
        row.get("asset_expression") or row.get("assetExpression")
    )
    return (
        raw,
        raw_text,
        description,
        timetable_type,
        has_asset,
        next_run(row, timezone),
    )


def authoritative_schedule(
    kind: str,
    summary: str,
    authoritative_next: pendulum.DateTime | None,
    raw: object,
    timetable_type: str,
) -> tuple[str, str, str, bool, str, pendulum.DateTime | None, object, str]:
    """Determine whether schedule data is authoritative enough to project."""
    eligible = authoritative_next is not None
    reason = "" if eligible else f"{kind} schedule has no authoritative next run"
    return kind, "", summary, eligible, reason, authoritative_next, raw, timetable_type


def classify_standard_schedule(
    raw: object,
    raw_text: str,
    description: str,
    timetable_type: str,
    authoritative_next: pendulum.DateTime | None,
) -> tuple[str, str, str, bool, str, pendulum.DateTime | None, object, str]:
    """Classify one standard cron, interval, or manual schedule."""
    summary = raw_text or description
    lowered = raw_text.lower()
    if lowered in CRON_PRESETS:
        return (
            "preset",
            CRON_PRESETS[lowered],
            lowered,
            True,
            "",
            authoritative_next,
            raw,
            timetable_type,
        )
    cron = extract_cron(raw_text) or extract_cron(description)
    if cron:
        return (
            "cron",
            cron,
            raw_text or cron,
            True,
            "",
            authoritative_next,
            raw,
            timetable_type,
        )
    interval = interval_seconds(raw)
    if interval is not None:
        eligible = authoritative_next is not None
        reason = "" if eligible else "interval schedule has no authoritative anchor"
        return (
            "interval",
            str(interval),
            summary or f"every {interval:g}s",
            eligible,
            reason,
            authoritative_next,
            raw,
            timetable_type,
        )
    if authoritative_next is not None:
        return (
            "custom_next_only",
            "",
            summary,
            True,
            "",
            authoritative_next,
            raw,
            timetable_type,
        )
    if raw is not None or timetable_type:
        return (
            "unsupported",
            "",
            summary,
            False,
            "unsupported timetable representation",
            authoritative_next,
            raw,
            timetable_type,
        )
    return (
        "none",
        "",
        summary,
        False,
        "no schedule",
        authoritative_next,
        raw,
        timetable_type,
    )


def classify_schedule(
    row: Mapping[str, Any], timezone: str
) -> tuple[str, str, str, bool, str, pendulum.DateTime | None, object, str]:
    """Classify one DAG schedule and projection eligibility."""
    raw, raw_text, description, timetable_type, has_asset, authoritative_next = (
        schedule_context(row, timezone)
    )
    summary = raw_text or description
    if has_asset or "asset" in timetable_type or "dataset" in timetable_type:
        return authoritative_schedule(
            "asset", summary, authoritative_next, raw, timetable_type
        )
    if "event" in timetable_type:
        return authoritative_schedule(
            "event", summary, authoritative_next, raw, timetable_type
        )
    return classify_standard_schedule(
        raw, raw_text, description, timetable_type, authoritative_next
    )


def classify_dag(
    row: Mapping[str, Any],
    timezone: str,
    source: str,
    detail_status: str = "not-needed",
) -> DagInfo:
    """Normalize one API DAG record into canonical metadata."""
    (
        kind,
        expression,
        summary,
        eligible,
        reason,
        authoritative_next,
        raw,
        timetable_type,
    ) = classify_schedule(row, timezone)
    active_value = row.get("is_active", row.get("isActive", True))
    stale_value = row.get("is_stale", row.get("isStale", False))
    paused_value = row.get("is_paused", row.get("isPaused", row.get("paused", False)))
    active = parse_bool(active_value, "dag.is_active")
    stale = parse_bool(stale_value, "dag.is_stale") or not active
    paused = parse_bool(paused_value, "dag.is_paused")
    schedule_timezone, schedule_timezone_source = resolve_schedule_timezone(
        row, timezone, kind, expression, authoritative_next
    )
    if kind in {"cron", "preset"} and not schedule_timezone:
        eligible = False
        reason = "cron schedule timezone is unavailable"
    if stale:
        eligible = False
        reason = "stale DAG is not projected without authoritative current schedule"
    return DagInfo(
        dag_id=first_text(row, "dag_id", "dagId"),
        tags=normalize_tags(row.get("tags")),
        owner=normalize_owner(row),
        fileloc=first_text(
            row,
            "fileloc",
            "file_location",
            "fileLocation",
            "relative_fileloc",
            "relativeFileloc",
        ),
        paused=paused,
        stale=stale,
        schedule_kind=kind,
        schedule_expression=expression,
        schedule_summary=summary,
        schedule_timezone=schedule_timezone,
        schedule_timezone_source=schedule_timezone_source,
        schedule_source=source
        if raw is not None or authoritative_next is not None or timetable_type
        else "none",
        next_run=authoritative_next,
        eligible=eligible,
        exclusion_reason=reason,
        detail_status=detail_status,
    )
