# SPDX-License-Identifier: Apache-2.0
"""Canonical renderer row, bucket, calendar, and schedule serialization."""

from __future__ import annotations

from .aggregation import (
    exact_free_windows,
    report_display_end,
    run_risk,
    unique_source_runs,
)
from .calendar_windows import calendar_intervals
from .configuration_values import instant_microseconds, iso, ratio
from .configuration_windows import calendar_day_intervals
from .models import DagInfo, Report, Run
from .preamble import Any, Counter, Final, Mapping, Sequence, hashlib, json

HISTORICAL_RUN_TRANSPORT_FIELDS: Final[tuple[str, ...]] = (
    "id",
    "sourceRunId",
    "segmentIndex",
    "segmentCount",
    "selectedDay",
    "dag",
    "runId",
    "state",
    "rawState",
    "runType",
    "queuedAt",
    "effectiveStartSource",
    "logicalDate",
    "dataIntervalStart",
    "dataIntervalEnd",
    "tasks",
    "taskInstances",
    "taskEnrichmentStatus",
    "syntheticEnd",
    "t0",
    "t1",
    "abs0",
    "abs1",
    "durationSec",
    "durationText",
    "riskScore",
)


def historical_run_transport(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Encode historical rows without repeating field names per item."""
    return {
        "schema": "historical-columnar-v1",
        "fields": list(HISTORICAL_RUN_TRANSPORT_FIELDS),
        "rows": [
            [row.get(field) for field in HISTORICAL_RUN_TRANSPORT_FIELDS]
            for row in rows
        ],
    }


def _historical_tag_filter_from_dag_tags(
    dag_tags: Mapping[str, Sequence[str]], runs: Sequence[Run]
) -> list[dict[str, Any]]:
    """Aggregate every canonical DAG tag for the post-capacity run universe."""
    source_run_counts = Counter(run.dag_id for run in unique_source_runs(runs))
    aggregates: dict[str, dict[str, Any]] = {}
    for dag_id, source_run_count in source_run_counts.items():
        for raw_tag in dag_tags.get(dag_id, ()):
            tag = str(raw_tag).strip()
            if not tag:
                continue
            state = aggregates.setdefault(tag, {"runs": 0, "dags": set()})
            state["runs"] += source_run_count
            state["dags"].add(dag_id)
    return [
        {
            "value": tag,
            "historicalRunCount": int(aggregates[tag]["runs"]),
            "dagCount": len(aggregates[tag]["dags"]),
        }
        for tag in sorted(aggregates, key=lambda value: (value.casefold(), value))
    ]


def historical_tag_filter_payload(
    dags: Mapping[str, DagInfo], runs: Sequence[Run]
) -> list[dict[str, Any]]:
    """Derive TAG options from canonical DAG metadata and retained runs."""
    dag_tags = {dag_id: info.tags for dag_id, info in dags.items()}
    return _historical_tag_filter_from_dag_tags(dag_tags, runs)


def historical_tag_source_payload(
    report: Report, runs: Sequence[Run]
) -> dict[str, Any]:
    """Serialize a compact per-DAG ledger for the capacity-retained history universe."""
    source_runs = unique_source_runs(runs)
    counts = Counter(run.dag_id for run in source_runs)
    window_start = (
        report.historical_tag_window_start
        or report.capacity_plan.requested_history_start
    )
    window_end = (
        report.historical_tag_window_end or report.capacity_plan.requested_history_end
    )
    return {
        "schema": "historical-tag-source-v2",
        "windowStart": iso(window_start),
        "windowEnd": iso(window_end),
        "sourceRunCount": len(source_runs),
        "dagCount": len(counts),
        "dagRunCounts": [
            [dag_id, counts[dag_id]]
            for dag_id in sorted(counts, key=lambda value: (value.casefold(), value))
        ],
    }


def run_payload(report: Report) -> list[dict[str, Any]]:
    """Serialize normalized historical run segments for the renderer."""
    display_end = report_display_end(report)
    max_duration = max(
        ((run.end - run.start).total_seconds() for run in report.runs), default=1.0
    )
    values: list[dict[str, Any]] = []
    for index, run in enumerate(report.runs, start=1):
        duration = max(0.0, (run.end - run.start).total_seconds())
        values.append(
            {
                "id": f"run-{index:05d}-{run.source_run_id}-s{run.segment_index:02d}",
                "sourceRunId": run.source_run_id,
                "segmentIndex": run.segment_index,
                "segmentCount": run.segment_count,
                "selectedDay": run.selected_day,
                "dag": run.dag_id,
                "runId": run.run_id,
                "state": run.state,
                "rawState": run.raw_state,
                "runType": run.run_type,
                "queuedAt": iso(run.queued_at),
                "effectiveStartSource": run.effective_start_source,
                "logicalDate": iso(run.logical_date),
                "dataIntervalStart": iso(run.interval_start),
                "dataIntervalEnd": iso(run.interval_end),
                "tasks": run.task_count,
                "taskInstances": run.task_count,
                "taskEnrichmentStatus": run.task_enrichment_status,
                "syntheticEnd": run.synthetic_end,
                "t0": ratio(run.start, report.config.history_start, display_end),
                "t1": ratio(run.end, report.config.history_start, display_end),
                "abs0": iso(run.start),
                "abs1": iso(run.end),
                "durationSec": round(duration, 3),
                "durationText": human_duration(duration),
                "riskScore": run_risk(run, max_duration),
            }
        )
    return values


def historical_ledger_sha256(runs: Sequence[Mapping[str, Any]]) -> str:
    """Hash canonical historical-run ledger material."""
    digest = hashlib.sha256()
    digest.update(b"[")
    for index, run in enumerate(runs):
        if index:
            digest.update(b",")
        material = [
            str(run.get("sourceRunId") or ""),
            int(run.get("segmentIndex") or 0),
            int(run.get("segmentCount") or 0),
            str(run.get("selectedDay") or ""),
            str(run.get("dag") or ""),
            str(run.get("runId") or ""),
            str(run.get("state") or ""),
            str(run.get("abs0") or ""),
            str(run.get("abs1") or ""),
        ]
        digest.update(
            json.dumps(
                material,
                ensure_ascii=False,
                separators=(",", ":"),
            ).encode("utf-8")
        )
    digest.update(b"]")
    return digest.hexdigest()


def future_payload(report: Report) -> list[dict[str, Any]]:
    """Serialize projected occurrences using DAG-metadata rehydration.

    Future rows intentionally carry only their unique occurrence identity,
    DAG identity, timestamp and precomputed timeline ratio.  Schedule, owner,
    tag, badge and pause metadata are DAG-stable and are emitted once through
    ``dagMeta``.  The renderer restores the complete logical row before any
    filter, table, tooltip or Gantt derivation is evaluated.
    """
    display_end = report_display_end(report)
    return [
        {
            "projectionId": item.projection_id,
            "id": item.projection_id,
            "dag": item.dag_id,
            "projectedAt": iso(item.projected_at),
            "t0": ratio(item.projected_at, report.config.history_start, display_end),
        }
        for item in report.future_runs
    ]


def dag_payload(report: Report, source_runs: Sequence[Run]) -> list[dict[str, Any]]:
    """Serialize DAG metadata with historical, future, and maintenance counts."""
    actual = Counter(run.dag_id for run in source_runs)
    future = Counter((run.dag_id for run in report.future_runs))
    rows: list[dict[str, Any]] = []
    for info in sorted(report.dags.values(), key=lambda item: item.dag_id.casefold()):
        rows.append(
            {
                "dag": info.dag_id,
                "tags": list(info.tags),
                "owner": info.owner,
                "fileloc": info.fileloc,
                "isPaused": info.paused,
                "isStale": info.stale,
                "badge": "STALE"
                if info.stale
                else "PAUSED"
                if info.paused
                else "ACTIVE",
                "runCount": actual[info.dag_id],
                "futureCount": future[info.dag_id],
                "scheduleKind": info.schedule_kind,
                "scheduleExpression": info.schedule_expression,
                "scheduleSummary": info.schedule_summary,
                "scheduleTimezone": info.schedule_timezone,
                "scheduleTimezoneSource": info.schedule_timezone_source,
                "scheduleSource": info.schedule_source,
                "nextRun": iso(info.next_run),
                "projectionEligibility": "eligible" if info.eligible else "excluded",
                "projectionExclusionReason": info.exclusion_reason,
                "detailStatus": info.detail_status,
            }
        )
    return rows


def bucket_payload(report: Report) -> list[list[Any]]:
    """Serialize non-empty bucket rows in the compact renderer format."""
    values: list[list[Any]] = []
    for bucket in report.buckets:
        if not bucket.run_ids and bucket.risk <= 0:
            continue
        values.append(
            [
                bucket.index,
                len(bucket.run_ids),
                len(bucket.dag_ids),
                bucket.state_counts.get("success", 0),
                bucket.state_counts.get("failed", 0),
                bucket.state_counts.get("active", 0),
                bucket.state_counts.get("queued", 0),
                bucket.state_counts.get("skipped", 0),
                bucket.state_counts.get("other", 0),
                round(
                    bucket.seconds
                    / max(0.001, (bucket.end - bucket.start).total_seconds()),
                    8,
                ),
                round(bucket.risk, 6),
                round(bucket.risk_norm, 6),
                bucket.dominant,
            ]
        )
    return values


def free_window_payload(report: Report) -> list[dict[str, Any]]:
    """Serialize exact free windows only from a complete historical ledger."""
    if not report.historical_complete:
        return []
    values: list[dict[str, Any]] = []
    display_end = report_display_end(report)
    for start, end in exact_free_windows(report.config, report.runs):
        first = max(
            0,
            int(
                (start - report.config.history_start).total_seconds()
                // report.config.bucket_seconds
            ),
        )
        last = max(
            first,
            int(
                max(0.0, (end - report.config.history_start).total_seconds() - 1e-06)
                // report.config.bucket_seconds
            ),
        )
        seconds = (end - start).total_seconds()
        values.append(
            {
                "startIndex": first,
                "endIndex": last,
                "abs0": iso(start),
                "abs1": iso(end),
                "t0": ratio(start, report.config.history_start, display_end),
                "t1": ratio(end, report.config.history_start, display_end),
                "buckets": last - first + 1,
                "label": human_duration(seconds),
                "durationSec": round(seconds, 3),
            }
        )
    return values


def human_duration(seconds: float) -> str:
    """Format a duration in compact operator-readable units."""
    seconds = max(0, int(round(seconds)))
    days, remainder = divmod(seconds, 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes, secs = divmod(remainder, 60)
    parts = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    if secs or not parts:
        parts.append(f"{secs}s")
    return " ".join(parts)


def calendar_payload(report: Report) -> list[dict[str, Any]]:
    """Serialize the complete effective historical and future day range.

    Historical day selection semantics remain authoritative: continuous
    reports expose every effective historical day, while non-contiguous
    reports expose only the explicitly retained historical dates.  Effective
    future projection days are then appended and the transition date is
    merged when history and future share the same local calendar day.
    """
    display_end = report_display_end(report)
    origin = instant_microseconds(report.config.history_start)
    span = max(1000, instant_microseconds(display_end) - origin)
    by_key: dict[str, dict[str, Any]] = {}

    for day_start, day_end, day_key in calendar_day_intervals(report.config):
        by_key[day_key] = {
            "key": day_key,
            "label": day_start.format("D"),
            "start": day_start,
            "end": day_end,
            "history": True,
            "future": False,
        }

    if report.config.future_enabled:
        for day_start, day_end in calendar_intervals(
            report.config.trigger_time, display_end
        ):
            key = day_start.to_date_string()
            existing = by_key.get(key)
            if existing is None:
                by_key[key] = {
                    "key": key,
                    "label": day_start.format("D"),
                    "start": day_start,
                    "end": day_end,
                    "history": False,
                    "future": True,
                }
            else:
                existing["start"] = min(
                    existing["start"], day_start, key=instant_microseconds
                )
                existing["end"] = max(
                    existing["end"], day_end, key=instant_microseconds
                )
                existing["future"] = True

    values: list[dict[str, Any]] = []
    keyed_items = [(instant_microseconds(item["start"]), item) for item in by_key.values()]
    for start_key, item in sorted(keyed_items, key=lambda pair: pair[0]):
        day_start = item["start"]
        day_end = item["end"]
        has_history = bool(item["history"])
        has_future = bool(item["future"])
        kind = (
            "mixed"
            if has_history and has_future
            else "future"
            if has_future
            else "history"
        )
        values.append(
            {
                "key": item["key"],
                "label": item["label"],
                "kind": kind,
                "abs0": iso(day_start),
                "abs1": iso(day_end),
                "t0": max(0.0, min(1.0, (start_key - origin) / span)),
                "t1": max(
                    0.0, min(1.0, (instant_microseconds(day_end) - origin) / span)
                ),
            }
        )
    return values


def schedule_audit_payload(report: Report) -> list[dict[str, Any]]:
    """Serialize exact per-DAG projection diagnostics."""
    return [
        {
            "dagId": row.dag_id,
            "scheduleSource": row.source,
            "scheduleKind": row.kind,
            "eligible": row.eligible,
            "reason": row.reason,
            "detailStatus": row.detail_status,
            "occurrences": row.occurrences,
            "availableOccurrences": row.available_occurrences,
            "omittedOccurrences": row.omitted_occurrences,
            "configuredTarget": row.configured_target,
            "effectiveTarget": row.effective_target,
            "coverageStatus": row.coverage_status,
            "truncated": row.truncated,
        }
        for row in report.schedule_audit
    ]
