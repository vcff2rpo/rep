# SPDX-License-Identifier: Apache-2.0
"""Generated constants from contracts/report_feature_contract_v3.json.

Do not edit manually. Run ``python tools/generate_contract_bindings.py``.
"""

from __future__ import annotations

from typing import Final, TypedDict

FEATURE_CONTRACT_SCHEMA: Final[str] = "airflow-runtime-report-feature-contract-v1"
PAYLOAD_SCHEMA_GENERATED: Final[str] = "payload_v3"
TRANSPORT_SCHEMA_GENERATED: Final[str] = "report-transport-v1"
HISTORICAL_TRANSPORT_SCHEMA_GENERATED: Final[str] = "historical-columnar-v1"
HISTORICAL_ANALYTICS_SCHEMA: Final[str] = "historical-analytics-v1"
ANALYTICS_PERCENTILES: Final[tuple[int, ...]] = (
    50,
    90,
    95,
)
ANALYTICS_MINIMUM_SAMPLES: Final[int] = 5
ANALYTICS_MEDIUM_MINIMUM_SAMPLES: Final[int] = 12
ANALYTICS_HIGH_MINIMUM_SAMPLES: Final[int] = 30
ANOMALY_WATCH_SCORE: Final[int] = 40
ANOMALY_HIGH_SCORE: Final[int] = 65
ANOMALY_CRITICAL_SCORE: Final[int] = 85
TASK_INSPECTOR_PAGE_SIZE: Final[int] = 64
TASK_INSPECTOR_MAX_MOUNTED: Final[int] = 65

class TaskTimelinePolicy(TypedDict):
    status: int
    note: str
    action: str
    retryable: bool
    limitKey: str
    canPage: bool


TASK_TIMELINE_ERROR_SCHEMA = "task-timeline-error-v1"
TASK_TIMELINE_LIMITS: Final[dict[str, int]] = {
    "apiReadSeconds": 5,
    "apiRetries": 0,
    "attempts": 20000,
    "browserAbortMilliseconds": 35000,
    "dagIdCharacters": 250,
    "errorBytes": 4096,
    "historyCalls": 256,
    "knownEmptyEntries": 64,
    "maxPages": 50,
    "maximumRetryAfterSeconds": 300,
    "operationSeconds": 30,
    "pageLimit": 100,
    "preferredPageRuns": 32,
    "responseBytes": 8388608,
    "runIdCharacters": 1024,
    "runs": 64,
    "taskIdCharacters": 250,
    "tasks": 5000,
    "upstreamBytes": 16777216,
    "upstreamCalls": 512,
    "upstreamResponseBytes": 4194304,
    "urlCharacters": 16384,
    "workerConcurrency": 4,
}
TASK_TIMELINE_ERRORS: Final[dict[str, TaskTimelinePolicy]] = {
    "attempt_limit": {
        "action": "dates",
        "canPage": True,
        "limitKey": "attempts",
        "note": "Task request exceeds {limit} task attempts. Narrow the report dates.",
        "retryable": False,
        "status": 422,
    },
    "authentication": {
        "action": "",
        "canPage": False,
        "limitKey": "",
        "note": "",
        "retryable": False,
        "status": 401,
    },
    "busy": {
        "action": "retry",
        "canPage": True,
        "limitKey": "",
        "note": "Task service is busy. Retry loading these task details.",
        "retryable": True,
        "status": 429,
    },
    "forbidden": {
        "action": "",
        "canPage": False,
        "limitKey": "",
        "note": "Task details unavailable: access denied. Ask your Airflow administrator about DAG permissions.",
        "retryable": False,
        "status": 403,
    },
    "history_limit": {
        "action": "dates",
        "canPage": True,
        "limitKey": "historyCalls",
        "note": "Task timeline history request limit exceeded ({limit}). Narrow the report dates.",
        "retryable": False,
        "status": 422,
    },
    "incomplete": {
        "action": "",
        "canPage": True,
        "limitKey": "",
        "note": "Task data is incomplete. Complete task membership could not be verified.",
        "retryable": False,
        "status": 502,
    },
    "invalid_run_id": {
        "action": "",
        "canPage": True,
        "limitKey": "",
        "note": "Task scope contains an invalid or duplicate run identity. Apply the report dates again.",
        "retryable": False,
        "status": 422,
    },
    "live_required": {
        "action": "",
        "canPage": False,
        "limitKey": "",
        "note": "Task details require the live Airflow report.",
        "retryable": False,
        "status": 409,
    },
    "malformed": {
        "action": "",
        "canPage": True,
        "limitKey": "",
        "note": "Task service returned invalid data. Contact your Airflow administrator.",
        "retryable": False,
        "status": 502,
    },
    "membership_mismatch": {
        "action": "",
        "canPage": True,
        "limitKey": "",
        "note": "Task data does not match the requested run scope. No task details were published.",
        "retryable": False,
        "status": 502,
    },
    "missing": {
        "action": "",
        "canPage": True,
        "limitKey": "",
        "note": "A requested DAG or run is no longer available. Apply the report dates again.",
        "retryable": False,
        "status": 404,
    },
    "network": {
        "action": "retry",
        "canPage": True,
        "limitKey": "",
        "note": "Task details could not be reached. Retry loading these details.",
        "retryable": True,
        "status": 503,
    },
    "response_limit": {
        "action": "dates",
        "canPage": True,
        "limitKey": "responseBytes",
        "note": "Task response exceeds its {limit}-byte allowance. Narrow the report dates.",
        "retryable": False,
        "status": 422,
    },
    "retained_budget": {
        "action": "capacity",
        "canPage": True,
        "limitKey": "",
        "note": "Report task-data limit reached. Close another task expansion, then retry.",
        "retryable": False,
        "status": 409,
    },
    "run_limit": {
        "action": "dates",
        "canPage": True,
        "limitKey": "runs",
        "note": "Task request exceeds {limit} historical run IDs. Narrow the report dates.",
        "retryable": False,
        "status": 422,
    },
    "task_limit": {
        "action": "dates",
        "canPage": True,
        "limitKey": "tasks",
        "note": "Task request exceeds {limit} task instances. Narrow the report dates.",
        "retryable": False,
        "status": 422,
    },
    "temporarily_unavailable": {
        "action": "retry",
        "canPage": True,
        "limitKey": "",
        "note": "Task service is temporarily unavailable. Retry loading these details.",
        "retryable": True,
        "status": 503,
    },
    "timeout": {
        "action": "retry",
        "canPage": True,
        "limitKey": "",
        "note": "Task detail loading timed out. Retry or narrow the report dates.",
        "retryable": True,
        "status": 504,
    },
    "unavailable": {
        "action": "",
        "canPage": True,
        "limitKey": "",
        "note": "Task details unavailable. Contact your Airflow administrator if this persists.",
        "retryable": False,
        "status": 503,
    },
    "upstream_bytes_limit": {
        "action": "dates",
        "canPage": True,
        "limitKey": "upstreamBytes",
        "note": "Task collection exceeds its {limit}-byte upstream allowance. Narrow the report dates.",
        "retryable": False,
        "status": 422,
    },
    "upstream_calls_limit": {
        "action": "dates",
        "canPage": True,
        "limitKey": "upstreamCalls",
        "note": "Task collection exceeds its {limit}-call upstream allowance. Narrow the report dates.",
        "retryable": False,
        "status": 422,
    },
    "upstream_response_limit": {
        "action": "dates",
        "canPage": True,
        "limitKey": "upstreamResponseBytes",
        "note": "An upstream task response exceeds its {limit}-byte allowance. Narrow the report dates.",
        "retryable": False,
        "status": 422,
    },
    "url_limit": {
        "action": "",
        "canPage": True,
        "limitKey": "urlCharacters",
        "note": "A single run identity cannot fit the task request URL allowance. Contact your Airflow administrator.",
        "retryable": False,
        "status": 414,
    },
}

