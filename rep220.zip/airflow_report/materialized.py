# SPDX-License-Identifier: Apache-2.0
"""Request-driven local daily materialization for the Airflow report."""

from __future__ import annotations

import fcntl
import hashlib
import os
import stat
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any
from urllib.parse import quote

import pendulum

from .api import ApiClient, RequestApiCredential
from .configuration_security import redact_secret_text
from .configuration_values import dt_or_none
from .materialized_storage import (
    CURRENT_DAY_OVERLAP_SECONDS,
    DEFAULT_CURRENT_DAY_MAX_AGE_SECONDS,
    MAX_RETAINED_DAYS,
    NON_TERMINAL_STATES,
    PARTITION_RE,
    MaterializedDataset,
    _advance_repository_generation,
    _bounded_env_int,
    _date_key,
    _ensure_authorization_store,
    _ensure_root,
    _ensure_timezone_store,
    _load_partition,
    _Partition,
    _partition_payload,
    _raw_state,
    _safe_load,
    _synchronize_authorization_identity,
    _timezone_store,
    _write_partition,
    materialized_repository_identity,
)
from .models import ApiStats, Config, DagInfo
from .normalization import deduplicate_runs, fetch_dags, fetch_run_rows, run_key
from .preamble import LOG, AirflowFailException


def _day_config(
    config: Config,
    start: pendulum.DateTime,
    end: pendulum.DateTime,
) -> Config:
    return replace(
        config,
        requested_history_start=start,
        requested_history_end=end,
        history_start=start,
        history_end=end,
        history_clamped=False,
        requested_selected_days=(),
        selected_days=(),
        run_id=f"materialized-{start.to_date_string()}",
        task_instance_key="airflow-runtime-report-materialized",
    )


def _partition_complete(
    day: pendulum.DateTime,
    now: pendulum.DateTime,
) -> bool:
    """Return whether the partition's local calendar day is closed."""
    return day.to_date_string() != now.to_date_string()


def _nonterminal_rows(
    partition: _Partition | None,
    dags: Mapping[str, DagInfo],
) -> tuple[dict[str, Any], ...]:
    """Return refreshable open runs owned by current non-stale DAG definitions."""
    if partition is None:
        return ()
    rows = getattr(partition, "nonterminal_rows", None)
    candidates = (
        rows
        if isinstance(rows, tuple)
        else tuple(
            row for row in partition.runs if _raw_state(row) in NON_TERMINAL_STATES
        )
    )
    return tuple(
        row
        for row in candidates
        if (
            all(key := run_key(row))
            and (info := dags.get(key[0])) is not None
            and not info.stale
        )
    )


def _inventory_gated_rows(
    rows: Sequence[Mapping[str, Any]],
    dags: Mapping[str, DagInfo],
) -> tuple[list[dict[str, Any]], int]:
    """Discard only nonterminal rows without a current non-stale DAG owner."""
    retained: list[dict[str, Any]] = []
    discarded = 0
    for row in rows:
        if _raw_state(row) not in NON_TERMINAL_STATES:
            retained.append(dict(row))
            continue
        dag_id, run_id = run_key(row)
        info = dags.get(dag_id) if dag_id and run_id else None
        if info is not None and not info.stale:
            retained.append(dict(row))
        else:
            discarded += 1
    return retained, discarded


def _detail_row(payload: Mapping[str, Any]) -> dict[str, Any]:
    for key in ("dag_run", "dagRun", "data"):
        nested = payload.get(key)
        if isinstance(nested, Mapping):
            merged = dict(payload)
            merged.update(nested)
            return merged
    return dict(payload)


def _refresh_nonterminal_rows(
    client: ApiClient,
    rows: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    refreshed: list[dict[str, Any]] = []
    for row in rows:
        dag_id, run_id = run_key(row)
        resource = f"dags/{quote(dag_id, safe='')}/dagRuns/{quote(run_id, safe='')}"
        try:
            refreshed.append(_detail_row(client.get(resource, cache=False)))
        except AirflowFailException as exc:
            client.stats.mark_incomplete("materialized:nonterminal-detail")
            LOG.warning(
                "REPORT | MATERIALIZED | nonterminal_refresh_failed dag_id=%s "
                "run_id=%s reason=%s",
                dag_id,
                run_id,
                redact_secret_text(exc, 200),
            )
    return refreshed


def _row_intersects_day(
    row: Mapping[str, Any],
    day_start: pendulum.DateTime,
    day_end: pendulum.DateTime,
    timezone: str,
) -> bool:
    start = dt_or_none(
        row, timezone, "start_date", "startDate", "queued_at", "queuedAt"
    )
    if start is None or start >= day_end:
        return False
    end = dt_or_none(row, timezone, "end_date", "endDate")
    return end is None or end > day_start


def _changed_run_count(
    existing: Sequence[Mapping[str, Any]],
    current: Sequence[Mapping[str, Any]],
) -> int:
    previous = {run_key(row): dict(row) for row in existing if all(run_key(row))}
    latest = {run_key(row): dict(row) for row in current if all(run_key(row))}
    return sum(
        previous.get(key) != latest.get(key) for key in previous.keys() | latest.keys()
    )


def _collect_day(
    config: Config,
    day: pendulum.DateTime,
    now: pendulum.DateTime,
    existing: _Partition | None,
    dags: Mapping[str, DagInfo],
    request_api_credential: RequestApiCredential | None,
) -> tuple[dict[str, Any], int]:
    day_start = day.start_of("day")
    day_end = min(day_start.add(days=1), now)
    current = day.to_date_string() == now.to_date_string()
    nonterminal_rows = _nonterminal_rows(existing, dags)
    incremental = current and existing is not None
    if incremental and len(nonterminal_rows) > config.max_detail_calls:
        incremental = False
        query_start = day_start
    elif incremental and existing is not None:
        overlap = existing.collected_through.subtract(
            seconds=CURRENT_DAY_OVERLAP_SECONDS
        )
        query_start = max(day_start, overlap)
    else:
        query_start = day_start
    query_config = _day_config(config, query_start, day_end)
    client = ApiClient.create(query_config, request_api_credential)
    try:
        client.validate_api_v2()
        update_rows = [
            row
            for row in fetch_run_rows(client)
            if _row_intersects_day(
                row,
                day_start,
                day_start.add(days=1),
                config.timezone,
            )
        ]
        detail_rows = (
            _refresh_nonterminal_rows(client, nonterminal_rows) if incremental else []
        )
        candidates = deduplicate_runs(
            [
                *(existing.runs if incremental and existing is not None else ()),
                *update_rows,
                *detail_rows,
            ],
            client.stats,
        )
        rows, discarded_nonterminal_rows = _inventory_gated_rows(candidates, dags)
        changed_runs = _changed_run_count(existing.runs if existing else (), rows)
        complete = _partition_complete(day, now)
        payload = _partition_payload(
            day,
            now,
            complete,
            rows,
            dags,
            client.stats,
            discarded_nonterminal_rows=(
                (
                    existing.discarded_nonterminal_rows
                    if incremental and existing is not None
                    else 0
                )
                + discarded_nonterminal_rows
            ),
        )
        return payload, changed_runs
    finally:
        client.close()


def _collect_materialized_inventory(
    config: Config,
    request_api_credential: RequestApiCredential | None,
) -> tuple[dict[str, DagInfo], ApiStats]:
    client = ApiClient.create(config, request_api_credential)
    try:
        client.validate_api_v2()
        dags = fetch_dags(client)
        return dags, client.stats
    finally:
        client.close()


def _selected_days(config: Config) -> tuple[pendulum.DateTime, ...]:
    values: list[pendulum.DateTime] = []
    cursor = config.history_start.start_of("day")
    while cursor < config.history_end:
        values.append(cursor)
        cursor = cursor.add(days=1)
    if len(values) > MAX_RETAINED_DAYS:
        raise AirflowFailException("materialized history exceeds the 10-day limit")
    return tuple(values)


def _refresh_required(
    partition: _Partition | None,
    day: pendulum.DateTime,
    now: pendulum.DateTime,
    max_age_seconds: int,
) -> bool:
    if partition is None:
        return True
    if day.to_date_string() == now.to_date_string():
        return (now - partition.collected_through).total_seconds() > max_age_seconds
    return False


def _retain_last_ten(
    root: Path,
    now: pendulum.DateTime,
    *,
    before_first_mutation: Callable[[], None] | None = None,
) -> tuple[str, ...]:
    minimum = now.start_of("day").subtract(days=MAX_RETAINED_DAYS - 1).to_date_string()
    expired: list[Path] = []
    for path in sorted(root.iterdir(), key=lambda item: item.name):
        if (
            not path.is_file()
            or path.is_symlink()
            or not PARTITION_RE.fullmatch(path.name)
        ):
            continue
        try:
            day = pendulum.from_format(
                path.stem,
                "YYMMDD",
                tz=now.timezone_name or "UTC",
            )
        except ValueError:
            continue
        if day.to_date_string() < minimum:
            expired.append(path)
    if expired and before_first_mutation is not None:
        before_first_mutation()
    removed: list[str] = []
    for path in expired:
        path.unlink(missing_ok=True)
        removed.append(path.name)
    if removed:
        directory = os.open(root, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    return tuple(removed)


def _aggregate_stats(
    partitions: Sequence[_Partition],
    inventory_stats: ApiStats,
) -> ApiStats:
    stats = ApiStats()
    stats.requests = inventory_stats.requests + sum(
        item.api_requests for item in partitions
    )
    stats.rows = sum(item.source_rows for item in partitions)
    stats.raw_run_rows = sum(len(item.runs) for item in partitions)
    stats.deduplicated_run_rows = len(
        deduplicate_runs(row for item in partitions for row in item.runs)
    )
    stats.cache_hits = len(partitions)
    stats.cache_entries = len(partitions)
    stats.cache_bytes = 0
    stats.api_probe_status = "materialized-local-fs"
    stats.active_query_strategy = "daily-partition-reuse"
    return stats


def _open_partition_lock(store: Path, filename: str = ".report.lock") -> int:
    if filename not in {".report.lock", ".scope.lock"}:
        raise AirflowFailException("report JSON lock filename is invalid")
    descriptor = os.open(
        store / filename,
        os.O_CREAT
        | os.O_RDWR
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0),
        0o640,
    )
    if stat.S_ISREG(os.fstat(descriptor).st_mode):
        return descriptor
    os.close(descriptor)
    raise AirflowFailException("report JSON lock is not a regular file")


def _load_selected_partitions(
    store: Path,
    days: Sequence[pendulum.DateTime],
    timezone: str,
    now: pendulum.DateTime,
    *,
    generation_root: Path | None = None,
) -> dict[str, _Partition | None]:
    loaded: dict[str, _Partition | None] = {}
    today = now.to_date_string()
    generation_published = False

    def publish_quarantine_generation() -> None:
        nonlocal generation_published
        if generation_root is not None and not generation_published:
            _advance_repository_generation(generation_root)
            generation_published = True

    for day in days:
        key = day.to_date_string()
        partition = _safe_load(
            store / _date_key(day),
            timezone,
            before_quarantine=publish_quarantine_generation,
        )
        if partition is not None and key != today and not partition.complete:
            partition = replace(partition, complete=True)
        loaded[key] = partition
    return loaded


def _days_requiring_refresh(
    loaded: Mapping[str, _Partition | None],
    days: Sequence[pendulum.DateTime],
    now: pendulum.DateTime,
    max_age: int,
    force_reinitialize: bool,
) -> list[pendulum.DateTime]:
    if force_reinitialize:
        return list(days)
    return [
        day
        for day in days
        if _refresh_required(loaded[day.to_date_string()], day, now, max_age)
    ]


def _materialized_inventory_snapshot(
    config: Config,
    request_api_credential: RequestApiCredential | None,
) -> tuple[dict[str, DagInfo], ApiStats, bool]:
    """Refresh the authorization-visible DAG inventory on every report request.

    A stable bearer token does not prove that server-side DAG permissions stayed
    unchanged. Reusing partition-embedded DAG metadata would therefore allow a
    same-token permission contraction to keep historical rows visible until a
    partition refresh. The live inventory is the current authorization boundary.
    """
    dags, stats = _collect_materialized_inventory(config, request_api_credential)
    return dags, stats, True


def _sanitize_loaded_partitions(
    store: Path,
    loaded: dict[str, _Partition | None],
    days: Sequence[pendulum.DateTime],
    dags: Mapping[str, DagInfo],
    generation_root: Path,
    repository_identity: tuple[int, int, int, int],
) -> tuple[list[str], int, tuple[int, int, int, int]]:
    """Prune stale nonterminal rows from existing selected partitions once."""
    sanitized: list[str] = []
    discarded_total = 0
    for day in days:
        key = day.to_date_string()
        partition = loaded[key]
        if partition is None:
            continue
        invalid_nonterminal = any(
            not all(nonterminal_key := run_key(row))
            or (info := dags.get(nonterminal_key[0])) is None
            or info.stale
            for row in partition.nonterminal_rows
        )
        if not invalid_nonterminal:
            continue
        runs, discarded = _inventory_gated_rows(partition.runs, dags)
        if not discarded:
            continue
        stats = ApiStats()
        stats.requests = partition.api_requests
        stats.raw_run_rows = partition.source_rows
        stats.deduplicated_run_rows = len(runs)
        stats.response_bytes = partition.response_bytes
        payload = _partition_payload(
            day,
            partition.collected_through,
            partition.complete,
            runs,
            partition.dags,
            stats,
            generated_at=partition.generated_at,
            discarded_nonterminal_rows=(
                partition.discarded_nonterminal_rows + discarded
            ),
        )
        _write_partition(store / _date_key(day), payload)
        if not sanitized:
            repository_identity = _advance_repository_generation(generation_root)
        loaded[key] = _load_partition(store / _date_key(day), partition.timezone)
        sanitized.append(key)
        discarded_total += discarded
        LOG.warning(
            "REPORT | MATERIALIZED | stale_nonterminal_pruned date=%s rows=%s",
            key,
            discarded,
        )
    return sanitized, discarded_total, repository_identity


def _refresh_selected_partitions(
    config: Config,
    store: Path,
    loaded: dict[str, _Partition | None],
    refresh_days: Sequence[pendulum.DateTime],
    now: pendulum.DateTime,
    dags: Mapping[str, DagInfo],
    request_api_credential: RequestApiCredential | None,
    force_reinitialize: bool,
    generation_root: Path,
    repository_identity: tuple[int, int, int, int],
) -> tuple[list[str], int, tuple[int, int, int, int]]:
    refreshed: list[str] = []
    updated_rows = 0
    for day in refresh_days:
        key = day.to_date_string()
        payload, changed = _collect_day(
            config,
            day,
            now,
            None if force_reinitialize else loaded[key],
            dags,
            request_api_credential,
        )
        if not refreshed:
            _ensure_timezone_store(store)
        path = store / _date_key(day)
        _write_partition(path, payload)
        if not refreshed:
            repository_identity = _advance_repository_generation(generation_root)
        loaded[key] = _load_partition(path, config.timezone)
        refreshed.append(key)
        updated_rows += changed
    return refreshed, updated_rows, repository_identity


def _available_partition_set(
    loaded: Mapping[str, _Partition | None],
    days: Sequence[pendulum.DateTime],
) -> tuple[list[_Partition], list[str]]:
    partitions = [
        partition
        for day in days
        if (partition := loaded[day.to_date_string()]) is not None
    ]
    missing = [
        day.to_date_string() for day in days if loaded[day.to_date_string()] is None
    ]
    if not partitions:
        raise AirflowFailException(
            "no valid local daily report partitions are available"
        )
    return partitions, missing


def _authorization_visible_runs(
    rows: Sequence[Mapping[str, Any]],
    dags: Mapping[str, DagInfo],
) -> tuple[tuple[dict[str, Any], ...], int]:
    """Withhold history whose current DAG read authorization is unverifiable.

    Airflow's public API intentionally does not provide a reliable distinction
    between a deleted DAG and a DAG hidden by authorization. A row whose DAG is
    absent from the freshly authorization-filtered inventory is therefore not
    safe to disclose. The persisted partition is left intact so authorization
    restoration can recover history without fabricating occupancy.
    """
    visible: list[dict[str, Any]] = []
    withheld = 0
    for row in rows:
        dag_id, run_id = run_key(row)
        if dag_id and run_id and dag_id in dags:
            visible.append(dict(row))
        else:
            withheld += 1
    return tuple(visible), withheld


@dataclass(frozen=True, slots=True)
class _DatasetAssembly:
    config: Config
    days: Sequence[pendulum.DateTime]
    now: pendulum.DateTime
    partitions: list[_Partition]
    missing: list[str]
    dags: Mapping[str, DagInfo]
    inventory_refreshed: bool
    inventory_stats: ApiStats
    refreshed: list[str]
    updated_rows: int
    sanitized: list[str]
    discarded_nonterminal_rows: int
    removed: Sequence[str]
    max_age: int
    repository_identity: tuple[int, int, int, int]


def _coverage_text(
    assembly: _DatasetAssembly,
    current_through: pendulum.DateTime,
    age_seconds: int,
    withheld_unverifiable_rows: int,
) -> str:
    text = (
        f"Coverage {assembly.days[0].format('DD MMM')}–"
        f"{assembly.days[-1].format('DD MMM')} · "
        f"{len(assembly.partitions)}/{len(assembly.days)} days · "
        f"current through {current_through.format('HH:mm:ss')} · "
        + ("fresh" if age_seconds <= assembly.max_age else f"stale {age_seconds}s")
    )
    if assembly.refreshed:
        text += (
            f" · updated {len(assembly.refreshed)} day(s), {assembly.updated_rows} rows"
        )
    if assembly.sanitized:
        text += (
            f" · pruned {assembly.discarded_nonterminal_rows} stale "
            f"nonterminal row(s) from {len(assembly.sanitized)} day(s)"
        )
    if assembly.missing:
        text += " · missing " + ", ".join(assembly.missing)
    if withheld_unverifiable_rows:
        text += (
            " · authorization incomplete; withheld "
            f"{withheld_unverifiable_rows} unverifiable historical row(s)"
        )
    return text


def _coverage_payload(
    assembly: _DatasetAssembly,
    current_through: pendulum.DateTime,
    age_seconds: int,
    withheld_unverifiable_rows: int,
    authorization_complete: bool,
) -> dict[str, Any]:
    return {
        "text": _coverage_text(
            assembly,
            current_through,
            age_seconds,
            withheld_unverifiable_rows,
        ),
        "selectedDays": [day.to_date_string() for day in assembly.days],
        "availableDays": [item.date for item in assembly.partitions],
        "missingDays": assembly.missing,
        "refreshedDays": assembly.refreshed,
        "removedFiles": list(assembly.removed),
        "currentThrough": current_through.to_iso8601_string(),
        "ageSeconds": age_seconds,
        "fresh": age_seconds <= assembly.max_age,
        "updatedRows": assembly.updated_rows,
        "sanitizedDays": assembly.sanitized,
        "discardedStaleNonterminalRows": assembly.discarded_nonterminal_rows,
        "withheldUnverifiableHistoricalRows": withheld_unverifiable_rows,
        "authorizationCompleteness": (
            "complete" if authorization_complete else "unknown"
        ),
        "reportDays": assembly.config.live_report_days,
        "generation": hashlib.sha256(
            "\n".join(item.content_sha256 for item in assembly.partitions).encode(
                "utf-8"
            )
        ).hexdigest()[:24],
    }


def _assemble_materialized_dataset(
    assembly: _DatasetAssembly,
) -> MaterializedDataset:
    newest = assembly.partitions[-1]
    current_partition = next(
        (
            item
            for item in assembly.partitions
            if item.date == assembly.now.to_date_string()
        ),
        None,
    )
    current_through = (
        current_partition.collected_through
        if current_partition
        else newest.collected_through
    )
    age_seconds = max(0, int((assembly.now - current_through).total_seconds()))
    partition_complete = not assembly.missing and all(
        item.complete or item.date == assembly.now.to_date_string()
        for item in assembly.partitions
    )
    combined_candidates = tuple(
        deduplicate_runs(row for item in assembly.partitions for row in item.runs)
    )
    if assembly.inventory_refreshed:
        combined_runs, withheld_unverifiable_rows = _authorization_visible_runs(
            combined_candidates,
            assembly.dags,
        )
        latest_dags = dict(assembly.dags)
    else:
        combined_runs = tuple(dict(row) for row in combined_candidates)
        withheld_unverifiable_rows = 0
        latest_dags = next(
            (dict(item.dags) for item in reversed(assembly.partitions) if item.dags),
            dict(assembly.dags),
        )
    stats = _aggregate_stats(assembly.partitions, assembly.inventory_stats)
    for reason in assembly.inventory_stats.incomplete_reasons:
        stats.mark_incomplete(reason)
    authorization_complete = (
        assembly.inventory_refreshed
        and not assembly.inventory_stats.incomplete_reasons
        and withheld_unverifiable_rows == 0
    )
    if assembly.missing:
        stats.mark_incomplete("materialized:missing-days")
    if not authorization_complete:
        stats.mark_incomplete("materialized:authorization-completeness-unknown")
    complete = partition_complete and authorization_complete
    return MaterializedDataset(
        dags=latest_dags,
        raw_runs=combined_runs,
        complete=complete,
        coverage=_coverage_payload(
            assembly,
            current_through,
            age_seconds,
            withheld_unverifiable_rows,
            authorization_complete,
        ),
        stats=stats,
        repository_identity=assembly.repository_identity,
    )


def ensure_materialized_dataset(
    config: Config,
    root: Path,
    request_api_credential: RequestApiCredential | None,
    *,
    repository_scope: str,
    authorization_identity: str,
    force_reinitialize: bool = False,
) -> MaterializedDataset:
    """Refresh one authorization-scoped dataset and return validated partitions."""
    root_store = _ensure_root(root)
    root_lock = _open_partition_lock(root_store, ".scope.lock")
    try:
        fcntl.flock(root_lock, fcntl.LOCK_EX)
        authorization_store = _ensure_authorization_store(
            root_store,
            repository_scope,
        )
    finally:
        try:
            fcntl.flock(root_lock, fcntl.LOCK_UN)
        finally:
            os.close(root_lock)

    now = pendulum.now(config.timezone)
    days = _selected_days(config)
    max_age = _bounded_env_int(
        "CURRENT_DAY_MAX_AGE_SECONDS",
        DEFAULT_CURRENT_DAY_MAX_AGE_SECONDS,
        1,
        3600,
    )
    lock_descriptor = _open_partition_lock(authorization_store)
    try:
        fcntl.flock(lock_descriptor, fcntl.LOCK_EX)
        authorization_changed = _synchronize_authorization_identity(
            authorization_store,
            authorization_identity,
        )
        effective_reinitialize = force_reinitialize or authorization_changed
        store = _timezone_store(authorization_store, config.timezone)
        loaded = _load_selected_partitions(
            store,
            days,
            config.timezone,
            now,
            generation_root=authorization_store,
        )
        refresh_days = _days_requiring_refresh(
            loaded,
            days,
            now,
            max_age,
            effective_reinitialize,
        )
        repository_identity = materialized_repository_identity(authorization_store)
        dags, inventory_stats, inventory_refreshed = (
            _materialized_inventory_snapshot(
                config,
                request_api_credential,
            )
        )
        sanitized, discarded_nonterminal_rows, repository_identity = (
            _sanitize_loaded_partitions(
                store,
                loaded,
                days,
                dags,
                authorization_store,
                repository_identity,
            )
        )
        refreshed, updated_rows, repository_identity = _refresh_selected_partitions(
            config,
            store,
            loaded,
            refresh_days,
            now,
            dags,
            request_api_credential,
            effective_reinitialize,
            authorization_store,
            repository_identity,
        )

        def publish_retention_generation() -> None:
            nonlocal repository_identity
            repository_identity = _advance_repository_generation(authorization_store)

        removed = _retain_last_ten(
            store,
            now,
            before_first_mutation=publish_retention_generation,
        )
        partitions, missing = _available_partition_set(loaded, days)
        return _assemble_materialized_dataset(
            _DatasetAssembly(
                config=config,
                days=days,
                now=now,
                partitions=partitions,
                missing=missing,
                dags=dags,
                inventory_refreshed=inventory_refreshed,
                inventory_stats=inventory_stats,
                refreshed=refreshed,
                updated_rows=updated_rows,
                sanitized=sanitized,
                discarded_nonterminal_rows=discarded_nonterminal_rows,
                removed=removed,
                max_age=max_age,
                repository_identity=repository_identity,
            )
        )
    finally:
        try:
            fcntl.flock(lock_descriptor, fcntl.LOCK_UN)
        finally:
            os.close(lock_descriptor)
