# SPDX-License-Identifier: Apache-2.0
"""Typed configuration failures and operator-facing size formatting."""

from __future__ import annotations

from .preamble import AirflowFailException, NoReturn


class ApiError(AirflowFailException):
    """Represent a bounded HTTP failure with its exact request endpoint."""

    def __init__(
        self,
        method: str,
        endpoint: str,
        status: int,
        detail: str,
        code: str = "http_error",
    ) -> None:
        """Initialize parser state."""
        super().__init__(f"{method} {endpoint} HTTP {status}: {detail}")
        self.method = method
        self.endpoint = endpoint
        self.status = status
        self.code = code


class ApiOperationLimitError(ValueError):
    """Carry an operation budget cause without changing ordinary API policy."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__("Airflow API operation budget exceeded")


def fail(message: str) -> NoReturn:
    """Raise an Airflow task failure with the supplied operator-facing message."""
    raise AirflowFailException(message)


def size_text(size: int) -> str:
    """Format an exact byte count with decimal KB and MB values."""
    return f"bytes={size} KB={size / 1_000:.2f} MB={size / 1_000_000:.2f}"
