# SPDX-License-Identifier: Apache-2.0
"""Canonical build fragments for the Airflow runtime report."""
