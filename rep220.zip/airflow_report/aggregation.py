# SPDX-License-Identifier: Apache-2.0
"""Historical bucket, free-window, state, and risk aggregation."""

from __future__ import annotations

from .configuration_errors import fail
from .configuration_values import instant_microseconds, stable_id
from .configuration_windows import selected_day_intervals
from .models import Bucket, Config, Report, Run
from .preamble import STATE_ORDER, Counter, Sequence, math, pendulum


def build_buckets(config: Config, runs: Sequence[Run]) -> tuple[Bucket, ...]:
    """Aggregate normalized runs into bounded historical time buckets."""
    count = max(
        1,
        math.ceil(
            (config.history_end - config.history_start).total_seconds()
            / config.bucket_seconds
        ),
    )
    buckets = tuple(
        (
            Bucket(
                index=index,
                start=config.history_start.add(seconds=index * config.bucket_seconds),
                end=min(
                    config.history_start.add(
                        seconds=(index + 1) * config.bucket_seconds
                    ),
                    config.history_end,
                ),
            )
            for index in range(count)
        )
    )
    origin = instant_microseconds(config.history_start)
    bounds = tuple(
        (instant_microseconds(bucket.start), instant_microseconds(bucket.end))
        for bucket in buckets
    )
    for run in runs:
        run_start = instant_microseconds(run.start)
        run_end = instant_microseconds(run.end)
        first_index = max(
            0,
            int(
                ((run_start - origin) / 1_000_000)
                // config.bucket_seconds
            ),
        )
        last_index = min(
            count - 1,
            int(
                max(0.0, (run_end - origin) / 1_000_000 - 1e-06)
                // config.bucket_seconds
            ),
        )
        run_uid = stable_id(run.dag_id, run.run_id)
        for index in range(first_index, last_index + 1):
            bucket = buckets[index]
            overlap = max(
                0.0,
                (min(run_end, bounds[index][1]) - max(run_start, bounds[index][0]))
                / 1_000_000,
            )
            if overlap <= 0:
                continue
            bucket.seconds += overlap
            bucket.run_ids.add(run_uid)
            bucket.dag_ids.add(run.dag_id)
            bucket.state_counts[run.state] += 1
            bucket.state_seconds[run.state] = (
                bucket.state_seconds.get(run.state, 0.0) + overlap
            )
    maximum_risk = 0.0
    for bucket, (start_key, end_key) in zip(buckets, bounds, strict=True):
        capacity = max(0.001, (end_key - start_key) / 1_000_000)
        used = min(1.0, bucket.seconds / capacity)
        failed = bucket.state_seconds.get("failed", 0.0) / capacity
        active = bucket.state_seconds.get("active", 0.0) / capacity
        queued = bucket.state_seconds.get("queued", 0.0) / capacity
        bucket.risk = failed * 3.0 + queued * 1.5 + active * 0.25 + used * 0.1
        maximum_risk = max(maximum_risk, bucket.risk)
        bucket.dominant = (
            max(STATE_ORDER, key=lambda state: bucket.state_seconds.get(state, 0.0))
            if bucket.seconds
            else "free"
        )
    for bucket in buckets:
        bucket.risk_norm = bucket.risk / maximum_risk if maximum_risk else 0.0
    return buckets


def exact_free_windows(
    config: Config, runs: Sequence[Run]
) -> list[tuple[pendulum.DateTime, pendulum.DateTime]]:
    """Derive exact unoccupied windows from canonical run intervals."""
    windows: list[tuple[pendulum.DateTime, pendulum.DateTime]] = []
    source_bounds = tuple(
        (
            (instant_microseconds(run.start), run.start),
            (instant_microseconds(run.end), run.end),
        )
        for run in runs
    )
    for interval_start, interval_end, _ in selected_day_intervals(config):
        lower = (instant_microseconds(interval_start), interval_start)
        upper = (instant_microseconds(interval_end), interval_end)
        if upper[0] <= lower[0]:
            fail("historical interval must have positive absolute duration")
        occupied = sorted(
            (max(start, lower), min(end, upper))
            for start, end in source_bounds
            if end > lower and start < upper
        )
        merged: list[list[tuple[int, pendulum.DateTime]]] = []
        for start, end in occupied:
            if end <= start:
                continue
            if not merged or start > merged[-1][1]:
                merged.append([start, end])
            else:
                merged[-1][1] = max(merged[-1][1], end)
        cursor = lower
        for start, end in merged:
            if start > cursor:
                windows.append((cursor[1], start[1]))
            cursor = max(cursor, end)
        if cursor < upper:
            windows.append((cursor[1], interval_end))
    return windows


def unique_source_runs(runs: Sequence[Run]) -> tuple[Run, ...]:
    """Return one deterministic representative per source run."""
    values: dict[str, Run] = {}
    for run in runs:
        values.setdefault(run.source_run_id, run)
    return tuple(values.values())


def state_counts(runs: Sequence[Run]) -> dict[str, int]:
    """Count normalized run segments by renderer state."""
    counts = Counter((run.state for run in runs))
    return {state: counts.get(state, 0) for state in STATE_ORDER}


def report_display_end(report: Report) -> pendulum.DateTime:
    """Return the historical or projected display boundary."""
    future_end = report.config.future_effective_end
    if future_end is None:
        return report.config.history_end
    return max(report.config.history_end, future_end, key=instant_microseconds)


def report_mode_for_seconds(seconds: float) -> str:
    """Classify a selected duration into a renderer density mode."""
    if seconds <= 6 * 3600:
        return "detail"
    if seconds <= 2 * 86400:
        return "balanced"
    return "overview"


def run_risk(run: Run, max_duration: float) -> float:
    """Compute the bounded risk score for one normalized run."""
    state_boost = {
        "failed": 0.72,
        "active": 0.42,
        "queued": 0.34,
        "skipped": 0.14,
        "other": 0.1,
        "success": 0.04,
    }
    duration = max(0.0, (run.end - run.start).total_seconds())
    duration_weight = min(0.25, duration / max(max_duration, 1.0) * 0.25)
    return round(min(1.0, state_boost.get(run.state, 0.08) + duration_weight), 6)
