# SPDX-License-Identifier: Apache-2.0
"""Immutable Airflow REST API v2 transport contract."""

from __future__ import annotations

from typing import Final

API_VERSION: Final[str] = "v2"
API_PREFIX: Final[str] = "/api/v2"
DAG_INVENTORY_QUERY: Final[tuple[tuple[str, object], ...]] = (
    ("exclude_stale", False),
    ("order_by", "dag_id"),
)
API_VALIDATION_STATUSES: Final[frozenset[int]] = frozenset({400, 422})
API_MULTI_VALUE_PARAMETERS: Final[frozenset[str]] = frozenset({"state", "order_by"})
API_SOURCE_LABEL: Final[str] = "api_v2"
