# SPDX-License-Identifier: Apache-2.0
"""Bounded historical baselines and explainable anomaly scoring."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from math import floor
from typing import Any

from .generated_contracts import (
    ANALYTICS_HIGH_MINIMUM_SAMPLES,
    ANALYTICS_MEDIUM_MINIMUM_SAMPLES,
    ANALYTICS_MINIMUM_SAMPLES,
    ANALYTICS_PERCENTILES,
    ANOMALY_CRITICAL_SCORE,
    ANOMALY_HIGH_SCORE,
    ANOMALY_WATCH_SCORE,
    HISTORICAL_ANALYTICS_SCHEMA,
)
from .models import Report, Run


@dataclass(frozen=True, slots=True)
class SourceRunMetrics:
    """Contain one reconstructed source-run metric record."""

    source_run_id: str
    dag_id: str
    state: str
    duration_ms: int
    queue_delay_ms: int | None
    schedule_delay_ms: int | None


def _non_negative_ms(seconds: float) -> int:
    return max(0, round(seconds * 1000))


def _source_run_metrics(runs: Sequence[Run]) -> tuple[SourceRunMetrics, ...]:
    grouped: dict[str, list[Run]] = defaultdict(list)
    for run in runs:
        grouped[run.source_run_id].append(run)
    values: list[SourceRunMetrics] = []
    for source_id in sorted(grouped):
        segments = sorted(
            grouped[source_id],
            key=lambda row: (row.start, row.end, row.segment_index),
        )
        first = segments[0]
        start = min(row.start for row in segments)
        duration_ms = sum(
            _non_negative_ms((row.end - row.start).total_seconds()) for row in segments
        )
        queued_at = next((row.queued_at for row in segments if row.queued_at), None)
        logical_date = next(
            (row.logical_date for row in segments if row.logical_date), None
        )
        values.append(
            SourceRunMetrics(
                source_run_id=source_id,
                dag_id=first.dag_id,
                state=first.state,
                duration_ms=duration_ms,
                queue_delay_ms=(
                    _non_negative_ms((start - queued_at).total_seconds())
                    if queued_at is not None and start >= queued_at
                    else None
                ),
                schedule_delay_ms=(
                    _non_negative_ms((start - logical_date).total_seconds())
                    if logical_date is not None and start >= logical_date
                    else None
                ),
            )
        )
    return tuple(values)


def _percentile(values: Sequence[int], percentile: int) -> int | None:
    """Return deterministic R7 linear-interpolated percentile in integer units."""
    if not values:
        return None
    ordered = sorted(int(value) for value in values)
    if len(ordered) == 1:
        return ordered[0]
    rank = (len(ordered) - 1) * (percentile / 100.0)
    lower = floor(rank)
    upper = min(len(ordered) - 1, lower + 1)
    fraction = rank - lower
    return round(ordered[lower] + (ordered[upper] - ordered[lower]) * fraction)


def _percentile_set(values: Iterable[int | None]) -> dict[str, int | None]:
    materialized = [int(value) for value in values if value is not None]
    return {
        f"p{percentile}": _percentile(materialized, percentile)
        for percentile in ANALYTICS_PERCENTILES
    }


def _confidence(sample_count: int) -> str:
    if sample_count >= ANALYTICS_HIGH_MINIMUM_SAMPLES:
        return "high"
    if sample_count >= ANALYTICS_MEDIUM_MINIMUM_SAMPLES:
        return "medium"
    if sample_count >= ANALYTICS_MINIMUM_SAMPLES:
        return "low"
    return "insufficient"


def _ratio(value: int | None, baseline: int | None) -> float | None:
    if value is None or baseline is None or baseline <= 0:
        return None
    return round(value / baseline, 4)


def _severity(score: int) -> str:
    if score >= ANOMALY_CRITICAL_SCORE:
        return "critical"
    if score >= ANOMALY_HIGH_SCORE:
        return "high"
    if score >= ANOMALY_WATCH_SCORE:
        return "watch"
    return "nominal"


def _run_score(
    metric: SourceRunMetrics,
    duration_p95: int | None,
    queue_p95: int | None,
    schedule_p95: int | None,
) -> dict[str, Any]:
    duration_ratio = _ratio(metric.duration_ms, duration_p95)
    queue_ratio = _ratio(metric.queue_delay_ms, queue_p95)
    schedule_ratio = _ratio(metric.schedule_delay_ms, schedule_p95)
    reasons: list[str] = []
    components: list[float] = []
    for name, ratio, weight in (
        ("duration", duration_ratio, 45.0),
        ("queue-delay", queue_ratio, 25.0),
        ("schedule-delay", schedule_ratio, 20.0),
    ):
        if ratio is None:
            continue
        components.append(min(weight, max(0.0, ratio - 1.0) * weight))
        if ratio >= 1.25:
            reasons.append(f"{name}>{ratio:.2f}x-p95")
    state_weight = {"failed": 35.0, "active": 12.0, "queued": 10.0}.get(
        metric.state, 0.0
    )
    if state_weight:
        components.append(state_weight)
        reasons.append(f"state:{metric.state}")
    score = min(100, round(sum(components)))
    return {
        "sourceRunId": metric.source_run_id,
        "score": score,
        "severity": _severity(score),
        "durationRatio": duration_ratio,
        "queueDelayRatio": queue_ratio,
        "scheduleDelayRatio": schedule_ratio,
        "reasons": reasons[:4],
    }


def historical_analytics_payload(report: Report) -> dict[str, Any]:
    """Build compact per-DAG baselines and per-source-run anomaly scores."""
    metrics = _source_run_metrics(report.runs)
    by_dag: dict[str, list[SourceRunMetrics]] = defaultdict(list)
    for metric in metrics:
        by_dag[metric.dag_id].append(metric)
    baselines: list[dict[str, Any]] = []
    run_scores: list[dict[str, Any]] = []
    for dag_id in sorted(by_dag, key=lambda value: (value.casefold(), value)):
        rows = by_dag[dag_id]
        sample_count = len(rows)
        duration = _percentile_set(row.duration_ms for row in rows)
        queue = _percentile_set(row.queue_delay_ms for row in rows)
        schedule = _percentile_set(row.schedule_delay_ms for row in rows)
        confidence = _confidence(sample_count)
        qualified = sample_count >= ANALYTICS_MINIMUM_SAMPLES
        baselines.append(
            {
                "dag": dag_id,
                "sampleCount": sample_count,
                "confidence": confidence,
                "qualified": qualified,
                "durationMs": duration,
                "queueDelayMs": queue,
                "scheduleDelayMs": schedule,
            }
        )
        if qualified:
            for row in rows:
                run_scores.append(
                    _run_score(
                        row,
                        duration.get("p95"),
                        queue.get("p95"),
                        schedule.get("p95"),
                    )
                )
    return {
        "schema": HISTORICAL_ANALYTICS_SCHEMA,
        "method": "r7-linear-interpolation-v1",
        "minimumSamples": ANALYTICS_MINIMUM_SAMPLES,
        "sourceRunCount": len(metrics),
        "dagCount": len(baselines),
        "qualifiedDagCount": sum(bool(row["qualified"]) for row in baselines),
        "dagBaselines": baselines,
        "runScores": sorted(run_scores, key=lambda row: row["sourceRunId"]),
    }
