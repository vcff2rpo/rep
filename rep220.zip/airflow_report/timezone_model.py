# SPDX-License-Identifier: Apache-2.0
"""Explicit display, Airflow-default, and per-DAG schedule timezone contracts."""

from __future__ import annotations

from functools import lru_cache

from .configuration_security import redact_secret_text
from .preamble import (
    AirflowFailException,
    Any,
    CroniterBadCronError,
    Mapping,
    conf,
    croniter,
    datetime,
    pendulum,
)

_SCHEDULE_TIMEZONE_KEYS = (
    "timezone",
    "schedule_timezone",
    "scheduleTimezone",
    "timetable_timezone",
    "timetableTimezone",
)


def validated_timezone(value: object, label: str) -> str:
    """Return one canonical IANA timezone name or fail closed."""
    text = str(value or "").strip()
    if not text:
        raise AirflowFailException(f"{label} is missing")
    try:
        zone = (
            pendulum.local_timezone()
            if text.casefold() == "system"
            else pendulum.timezone(text)
        )
    except (TypeError, ValueError, LookupError) as exc:
        raise AirflowFailException(
            f"invalid {label} {redact_secret_text(text, 80)!r}"
        ) from exc
    return str(getattr(zone, "name", zone))


@lru_cache(maxsize=1)
def airflow_default_timezone() -> str:
    """Return Airflow's scheduler default timezone as a canonical name."""
    configured = conf.get("core", "default_timezone", fallback="UTC")
    return validated_timezone(configured or "UTC", "Airflow default timezone")


def explicit_schedule_timezone(row: Mapping[str, Any]) -> str:
    """Return the authoritative schedule timezone exposed by the DAG API row."""
    for key in _SCHEDULE_TIMEZONE_KEYS:
        value = row.get(key)
        if value not in (None, ""):
            return validated_timezone(value, f"DAG {key}")
    return ""


def _cron_datetime(value: datetime, timezone: str) -> pendulum.DateTime:
    """Normalize one croniter result into the schedule timezone."""
    if isinstance(value, pendulum.DateTime):
        return value.in_timezone(timezone)
    if value.tzinfo is None:
        return pendulum.instance(value, tz=timezone)
    return pendulum.instance(value).in_timezone(timezone)


def cron_anchor_matches(
    expression: str, moment: pendulum.DateTime, timezone: str
) -> bool:
    """Return whether one absolute next-run instant is a cron hit in a timezone."""
    base = moment.in_timezone(timezone).subtract(seconds=1)
    try:
        candidate = _cron_datetime(
            croniter(expression, base, ret_type=datetime).get_next(datetime), timezone
        )
    except (
        CroniterBadCronError,
        KeyError,
        OverflowError,
        TypeError,
        ValueError,
    ):
        return False
    return (
        candidate.in_timezone("UTC").to_iso8601_string()
        == moment.in_timezone("UTC").to_iso8601_string()
    )


def _candidate_timezones(report_timezone: str) -> tuple[str, ...]:
    """Return a small deterministic candidate set without global timezone scans."""
    ordered = (airflow_default_timezone(), "UTC", report_timezone)
    return tuple(
        dict.fromkeys(
            validated_timezone(item, "candidate timezone") for item in ordered
        )
    )


def resolve_schedule_timezone(
    row: Mapping[str, Any],
    report_timezone: str,
    schedule_kind: str,
    expression: str,
    authoritative_next: pendulum.DateTime | None,
) -> tuple[str, str]:
    """Resolve the timezone used to evaluate one DAG schedule.

    Explicit API metadata is authoritative. When it is absent, a cron schedule may
    be inferred only when the authoritative next-run instant matches a bounded,
    deterministic candidate timezone. Ambiguous schedules use Airflow's configured
    default only when that timezone is one of the matching candidates. No report
    display timezone is silently substituted for an unresolved cron timezone.
    """
    explicit = explicit_schedule_timezone(row)
    if explicit:
        return explicit, "api-field"
    if schedule_kind not in {"cron", "preset"}:
        return "", "not-required"
    if authoritative_next is None or not expression:
        return "", "unresolved"

    matches = tuple(
        timezone
        for timezone in _candidate_timezones(report_timezone)
        if cron_anchor_matches(expression, authoritative_next, timezone)
    )
    if len(matches) == 1:
        return matches[0], "next-run-inference"
    default_timezone = airflow_default_timezone()
    if default_timezone in matches:
        return default_timezone, "airflow-default-match"
    return "", "unresolved"
