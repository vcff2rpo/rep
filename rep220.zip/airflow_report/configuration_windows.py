# SPDX-License-Identifier: Apache-2.0
"""Calendar-bounded historical and projection window derivation."""

from __future__ import annotations

from .calendar_windows import calendar_intervals
from .configuration_errors import fail
from .configuration_security import redact_secret_text
from .configuration_values import instant_microseconds, parse_datetime, parsed_datetime
from .models import Config
from .preamble import (
    DEFAULT_HISTORY_HOURS,
    DEFAULT_TIMEZONE,
    ISO_DATE_RE,
    MAX_FUTURE_DAYS,
    MAX_HISTORY_DAYS,
    NICE_BUCKETS,
    AirflowFailException,
    Any,
    Mapping,
    math,
    pendulum,
    re,
)


def parse_days(
    value: object, timezone: str, now: pendulum.DateTime
) -> tuple[pendulum.DateTime, ...]:
    """Parse and deterministically limit explicitly selected history dates."""
    if value in (None, "", []):
        return ()
    raw = (
        re.split("[;,]", value)
        if isinstance(value, str)
        else list(value)
        if isinstance(value, (list, tuple, set))
        else []
    )
    if not raw:
        fail("report_days must be a string or list of dates")
    maximum_key = instant_microseconds(now.end_of("day"))
    minimum = now.subtract(days=30).start_of("day")
    minimum_key = instant_microseconds(minimum)
    selected: dict[str, pendulum.DateTime] = {}
    for item in raw:
        text = str(item).strip()
        if not ISO_DATE_RE.fullmatch(text):
            fail("invalid report_days entry; expected YYYY-MM-DD")
        day = parsed_datetime(text, timezone, "report_days").start_of("day")
        if not minimum_key <= instant_microseconds(day) <= maximum_key:
            fail(
                "report_days must be within the latest 31 local calendar days; "
                "the newest 10 selected dates are retained automatically: "
                f"{minimum.to_date_string()}..{now.to_date_string()}"
            )
        selected[text] = day
    return tuple(selected[key] for key in sorted(selected))


def history_window(
    values: Mapping[str, Any], timezone: str, now: pendulum.DateTime
) -> tuple[
    pendulum.DateTime,
    pendulum.DateTime,
    pendulum.DateTime,
    pendulum.DateTime,
    tuple[str, ...],
    tuple[str, ...],
    bool,
]:
    """Derive requested and 10-day-clamped historical report windows."""
    requested_selected = parse_days(values.get("report_days"), timezone, now)
    has_start = values.get("start") not in (None, "")
    has_end = values.get("end") not in (None, "")
    if requested_selected and (has_start or has_end):
        fail("use report_days or start/end, not both")
    if requested_selected:
        requested_start = requested_selected[0]
        requested_end = min(
            requested_selected[-1].add(days=1), now, key=instant_microseconds
        )
    elif has_start and has_end:
        requested_start = parse_datetime(values["start"], timezone, "start")
        requested_end = parse_datetime(values["end"], timezone, "end", date_end=True)
    elif has_start:
        requested_start = parse_datetime(values["start"], timezone, "start")
        requested_end = now
    elif has_end:
        requested_end = min(
            parse_datetime(values["end"], timezone, "end", date_end=True),
            now,
            key=instant_microseconds,
        )
        requested_start = requested_end.subtract(days=MAX_HISTORY_DAYS)
    else:
        requested_end = now
        requested_start = now.subtract(hours=DEFAULT_HISTORY_HOURS)
    requested_end = min(requested_end, now, key=instant_microseconds)
    if instant_microseconds(requested_end) <= instant_microseconds(requested_start):
        fail(
            "empty historical window after validation: "
            f"{requested_start}..{requested_end}"
        )

    if requested_selected:
        retained = requested_selected[-MAX_HISTORY_DAYS:]
        selected_days = tuple(day.to_date_string() for day in retained)
        start = retained[0]
        end = min(retained[-1].add(days=1), requested_end, key=instant_microseconds)
        clamped = len(requested_selected) > len(retained)
    else:
        intervals = calendar_intervals(requested_start, requested_end)
        retained_intervals = intervals[-MAX_HISTORY_DAYS:]
        start = retained_intervals[0][0]
        end = requested_end
        selected_days = ()
        clamped = len(intervals) > len(retained_intervals)
    return (
        requested_start,
        requested_end,
        start,
        end,
        tuple(day.to_date_string() for day in requested_selected),
        selected_days,
        clamped,
    )


def selected_day_intervals(
    config: Config,
) -> tuple[tuple[pendulum.DateTime, pendulum.DateTime, str | None], ...]:
    """Return clipped intervals for explicitly selected report days."""
    if not config.selected_days:
        return ((config.history_start, config.history_end, None),)
    history_start_key = instant_microseconds(config.history_start)
    history_end_key = instant_microseconds(config.history_end)
    intervals: list[tuple[pendulum.DateTime, pendulum.DateTime, str | None]] = []
    for key in config.selected_days:
        start = parsed_datetime(key, config.timezone, "selected day").start_of("day")
        end = start.add(days=1)
        start_key = instant_microseconds(start)
        end_key = instant_microseconds(end)
        if min(end_key, history_end_key) > max(start_key, history_start_key):
            bounded_start = config.history_start if history_start_key > start_key else start
            bounded_end = config.history_end if history_end_key < end_key else end
            intervals.append((bounded_start, bounded_end, key))
    return tuple(intervals)


def calendar_day_intervals(
    config: Config,
) -> tuple[tuple[pendulum.DateTime, pendulum.DateTime, str], ...]:
    """Return one clipped local-calendar interval per report day.

    Selected-day reports expose only the explicitly selected dates. Continuous
    start/end reports expose every local date intersecting the effective,
    clamped historical window. This is intentionally separate from
    ``selected_day_intervals`` because normal run normalization must not split
    every source run at midnight when no explicit day selection was requested.
    """
    if config.selected_days:
        return tuple(
            (start, end, day or start.to_date_string())
            for start, end, day in selected_day_intervals(config)
        )

    return tuple(
        (start, end, start.to_date_string())
        for start, end in calendar_intervals(config.history_start, config.history_end)
    )


def selected_history_seconds(config: Config) -> float:
    """Return the total selected historical duration in seconds."""
    return sum(
        (instant_microseconds(end) - instant_microseconds(start)) / 1_000_000
        for start, end, _ in selected_day_intervals(config)
    )


def projection_window(
    value: object, timezone: str, now: pendulum.DateTime
) -> tuple[bool, pendulum.DateTime | None, pendulum.DateTime | None, bool]:
    """Derive and clamp the optional future interval to 10 calendar days."""
    text = str(value or "").strip()
    if not text:
        return (False, None, None, False)
    if not ISO_DATE_RE.fullmatch(text):
        fail("future_end must be YYYY-MM-DD")
    requested = (
        parsed_datetime(text, timezone, "future_end").start_of("day").add(days=1)
    )
    if instant_microseconds(requested) <= instant_microseconds(now):
        fail("future_end must include the trigger date or a later date")
    hard_cap = now.start_of("day").add(days=MAX_FUTURE_DAYS)
    effective = min(requested, hard_cap, key=instant_microseconds)
    return (
        True,
        requested,
        effective,
        instant_microseconds(requested) > instant_microseconds(hard_cap),
    )


def nice_bucket(required: float) -> float:
    """Select the smallest supported bucket at or above a requirement."""
    for candidate in NICE_BUCKETS:
        if candidate >= required:
            return float(candidate)
    return float(math.ceil(required))


def timezone_context(values: Mapping[str, Any]) -> tuple[str, pendulum.DateTime]:
    """Validate the configured timezone and return current local time."""
    timezone = str(values.get("timezone") or DEFAULT_TIMEZONE).strip()
    try:
        return timezone, pendulum.now(timezone)
    except (TypeError, ValueError, LookupError) as exc:
        raise AirflowFailException(
            f"invalid timezone {redact_secret_text(timezone, 80)!r}"
        ) from exc
