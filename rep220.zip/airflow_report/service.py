# SPDX-License-Identifier: Apache-2.0
"""Reusable report collection service independent of Airflow DAG declaration."""

from __future__ import annotations

from .aggregation import build_buckets
from .api import ApiClient
from .configuration_errors import fail
from .configuration_security import sha256_file
from .configuration_values import instant_microseconds, iso, stable_id
from .models import (
    ApiStats,
    CapacityPlan,
    Config,
    DagInfo,
    FutureRun,
    RendererTemplate,
    Report,
    Run,
    ScheduleAudit,
)
from .payload import output_path
from .preamble import (
    LOG,
    MAX_TOTAL_TIMELINE_ITEMS_HARD,
    REPORT_ID,
    Any,
    Counter,
    Mapping,
    Path,
    Sequence,
    dataclass,
    pendulum,
    replace,
    socket,
    time,
)
from .renderer_runtime import load_renderer
from .scheduling import project
from .service_stages import (
    ProjectionStage,
    ReportAssemblyStage,
)


def apply_render_cap(
    runs: Sequence[Run], config: Config, stats: ApiStats
) -> tuple[Run, ...]:
    """Retain newest historical rows within both source and segment ceilings."""
    ordered = tuple(runs)
    source_order = tuple(dict.fromkeys(run.source_run_id for run in ordered))
    if (
        len(source_order) <= config.max_rendered_runs
        and len(ordered) <= config.max_rendered_runs
    ):
        return ordered
    retained_sources = frozenset(source_order[-config.max_rendered_runs :])
    retained = [run for run in ordered if run.source_run_id in retained_sources]
    if len(retained) > config.max_rendered_runs:
        retained = retained[-config.max_rendered_runs :]
    retained_ids = frozenset(run.source_run_id for run in retained)
    omitted_sources = frozenset(source_order) - retained_ids
    omitted_representatives: dict[str, Run] = {}
    for run in ordered:
        if run.source_run_id in omitted_sources:
            omitted_representatives.setdefault(run.source_run_id, run)
    grouped: dict[str, list[Run]] = {}
    for run in retained:
        grouped.setdefault(run.source_run_id, []).append(run)
    normalized: list[Run] = []
    for source_id in sorted(grouped):
        rows = sorted(
            grouped[source_id],
            key=lambda row: (
                instant_microseconds(row.start), instant_microseconds(row.end), row.segment_index
            ),
        )
        normalized.extend(
            replace(row, segment_index=index, segment_count=len(rows))
            for index, row in enumerate(rows, start=1)
        )
    stats.omitted_runs += len(omitted_representatives)
    stats.omitted_dags = len({run.dag_id for run in omitted_representatives.values()})
    stats.omitted_state_counts.update(
        run.state for run in omitted_representatives.values()
    )
    stats.mark_incomplete("dagRuns:render_cap")
    LOG.warning(
        "render cap applied collected_sources=%s retained_sources=%s "
        "omitted_sources=%s collected_segments=%s retained_segments=%s "
        "omitted_dags=%s",
        len(source_order),
        len(retained_ids),
        len(omitted_representatives),
        len(ordered),
        len(normalized),
        stats.omitted_dags,
    )
    return tuple(
        sorted(
            normalized,
            key=lambda row: (
                instant_microseconds(row.start),
                instant_microseconds(row.end),
                row.dag_id.casefold(),
                row.run_id,
                row.segment_index,
            ),
        )
    )


def historical_ledger(
    stats: ApiStats,
    collected: int,
    emitted: int,
    collected_segments: int | None = None,
    emitted_segments: int | None = None,
) -> dict[str, Any]:
    """Build historical completeness and omission metadata."""
    return {
        "inputMembers": stats.input_members,
        "acceptedMembers": stats.accepted_members,
        "rejectedMembers": stats.rejected_members,
        "identityRejections": stats.identity_rejections,
        "normalizationRejections": stats.normalization_rejections,
        "duplicateConflicts": stats.duplicate_conflicts,
        "collectedRuns": collected,
        "emittedRuns": emitted,
        "collectedSegments": collected
        if collected_segments is None
        else collected_segments,
        "emittedSegments": emitted if emitted_segments is None else emitted_segments,
        "selectedDayRejections": stats.selected_day_rejections,
        "selectedDaySegments": stats.selected_day_segments,
        "omittedRuns": stats.omitted_runs,
        "omittedDags": stats.omitted_dags,
        "omittedStateCounts": dict(stats.omitted_state_counts),
        "activeQueryStrategy": stats.active_query_strategy,
        "incompleteReasons": list(stats.incomplete_reasons),
        "projectionIncompleteReasons": list(stats.projection_incomplete_reasons),
    }


def projection_ledger(
    config: Config, audits: Sequence[ScheduleAudit], future: Sequence[FutureRun]
) -> dict[str, Any]:
    """Build future projection completeness and truncation metadata."""
    reasons = Counter(row.reason for row in audits)
    unsupported = [
        row.dag_id
        for row in audits
        if row.kind == "unsupported"
        or row.reason.startswith("unsupported or malformed")
    ]
    truncated = [row.dag_id for row in audits if row.truncated]
    return {
        "requested": config.future_enabled,
        "dagCount": len(audits),
        "eligibleDags": sum(row.eligible for row in audits),
        "projectedDags": len({item.dag_id for item in future}),
        "occurrences": len(future),
        "availableOccurrences": sum(row.available_occurrences for row in audits),
        "omittedOccurrences": sum(row.omitted_occurrences for row in audits),
        "coverageStatusCounts": dict(Counter(row.coverage_status for row in audits)),
        "unsupportedDags": unsupported,
        "truncatedDags": truncated,
        "reasonCounts": dict(reasons),
    }


def _human_size(size: int) -> str:
    """Format a byte count using one suitable operator unit."""
    value = float(max(0, size))
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1000 or unit == "GB":
            decimals = 0 if unit == "B" else 1 if value >= 100 else 2
            return f"{value:.{decimals}f}{unit}"
        value /= 1000
    return f"{size}B"


def _bool_text(value: bool) -> str:
    """Format a Boolean using stable lowercase text."""
    return "true" if value else "false"


def _counter_text(values: Mapping[str, int], *, zero_keys: Sequence[str] = ()) -> str:
    """Format sorted counters with optional zero-valued keys."""
    merged = {key: int(values.get(key, 0)) for key in zero_keys}
    merged.update({str(key): int(value) for key, value in values.items()})
    return ", ".join(f"{key}={merged[key]}" for key in sorted(merged)) or "none"


def _separator() -> None:
    """Write the canonical intra-phase separator line."""
    LOG.info("REPORT | %s", "-" * 78)


def _phase_banner(number: int, total: int, title: str) -> None:
    """Write a delimited structured phase start record."""
    label = f" {number:02d}/{total:02d} {title.upper()} "
    LOG.info("REPORT | %s", label.center(78, "="))
    LOG.info("REPORT | status         : START")


def _phase_end(number: int, total: int, title: str, started: float) -> int:
    """Write a phase completion record and return elapsed milliseconds."""
    elapsed = max(0, int((time.monotonic() - started) * 1000))
    LOG.info("REPORT | status         : OK")
    LOG.info("REPORT | phase_elapsed  : %s ms", elapsed)
    LOG.info("REPORT | %s", "=" * 78)
    return elapsed


def _summary(
    title: str,
    values: Mapping[str, object],
    *,
    leading_separator: bool = True,
    heading_separator: bool = True,
    split_after: Sequence[str] = (),
) -> None:
    """Write one canonical operator summary block.

    The default layout is ``separator -> heading -> separator -> fields``.
    Optional switches preserve the compact composite blocks in the approved
    task-output pattern without duplicating formatting logic at call sites.
    """
    if leading_separator:
        _separator()
    LOG.info("REPORT | %s", title.upper())
    if heading_separator:
        _separator()
    split_keys = frozenset(split_after)
    items = tuple(values.items())
    for index, (key, value) in enumerate(items):
        LOG.info("REPORT | %-14s : %s", key, value)
        if key in split_keys and index + 1 < len(items):
            _separator()


def _capacity_reason(plan: CapacityPlan) -> str:
    """Format deterministic capacity-plan reasons."""
    return ", ".join(plan.reasons) if plan.reasons else "none"


def _projection_eligibility_summary(
    audits: Sequence[ScheduleAudit],
) -> dict[str, object]:
    """Validate and summarize projection eligibility for normal INFO logs.

    ``excluded`` is valid only for an audit row whose effective eligibility is
    false. Every eligible row must use one of the explicit ``eligible-*``
    coverage states. The function fails closed when this relationship is
    violated so operator summaries cannot silently misrepresent projection
    behavior.
    """
    allowed = {
        "excluded",
        "eligible-complete",
        "eligible-covered-20",
        "eligible-partially-truncated",
        "eligible-omitted-capacity",
        "eligible-no-occurrence",
    }
    counts = Counter(row.coverage_status for row in audits)
    unknown = sorted(set(counts) - allowed)
    invalid = [
        row.dag_id
        for row in audits
        if (row.eligible and not row.coverage_status.startswith("eligible-"))
        or (not row.eligible and row.coverage_status != "excluded")
    ]
    if unknown or invalid:
        fail(
            "projection eligibility audit invariant violated; "
            f"unknown_statuses={unknown!r} invalid_rows={len(invalid)}"
        )
    eligible_total = sum(row.eligible for row in audits)
    excluded_total = counts["excluded"]
    if eligible_total + excluded_total != len(audits):
        fail(
            "projection eligibility audit count mismatch; "
            f"eligible={eligible_total} excluded={excluded_total} "
            f"total={len(audits)}"
        )
    return {
        "eligible_total": eligible_total,
        "excluded": excluded_total,
        "complete": counts["eligible-complete"],
        "covered_target": counts["eligible-covered-20"],
        "partial": counts["eligible-partially-truncated"],
        "omitted_capacity": counts["eligible-omitted-capacity"],
        "no_occurrence": counts["eligible-no-occurrence"],
        "rule": "eligible=false => excluded; eligible=true => eligible-*",
        "status_valid": "true",
    }


@dataclass(frozen=True, slots=True)
class _ProjectionCounts:
    available: int
    omitted: int
    target_met: int
    target_total: int


def _projection_counts(
    config: Config, schedule_audit: Sequence[ScheduleAudit]
) -> _ProjectionCounts:
    return _ProjectionCounts(
        available=sum(row.available_occurrences for row in schedule_audit),
        omitted=sum(row.omitted_occurrences for row in schedule_audit),
        target_met=sum(
            row.eligible
            and row.available_occurrences > 0
            and row.occurrences
            >= min(config.future_target_per_dag, row.available_occurrences)
            for row in schedule_audit
        ),
        target_total=sum(
            row.eligible and row.available_occurrences > 0 for row in schedule_audit
        ),
    )


def _final_capacity_plan(
    plan: CapacityPlan,
    runs: Sequence[Run],
    future_runs: Sequence[FutureRun],
    effective_target: int,
    counts: _ProjectionCounts,
) -> CapacityPlan:
    return replace(
        plan,
        historical_rendered=len(runs),
        historical_omitted=max(0, plan.historical_available - len(runs)),
        future_available=counts.available,
        future_rendered=len(future_runs),
        future_omitted=counts.omitted,
        combined_available=plan.historical_available + counts.available,
        combined_rendered=len(runs) + len(future_runs),
        effective_future_target=effective_target,
        future_target_met_dags=counts.target_met,
        future_target_total_dags=counts.target_total,
    )


def _project_future_runs(
    config: Config,
    client: ApiClient,
    dags: dict[str, DagInfo],
    runs: tuple[Run, ...],
    capacity_plan: CapacityPlan,
) -> ProjectionStage:
    """Project future occurrences and finalize the capacity/projection ledgers."""
    phase_started = time.monotonic()
    _phase_banner(4, 6, "Project")
    future_runs, schedule_audit, effective_target = project(
        config, dags, historical_items=len(runs)
    )
    counts = _projection_counts(config, schedule_audit)
    final_capacity_plan = _final_capacity_plan(
        capacity_plan, runs, future_runs, effective_target, counts
    )
    if counts.omitted:
        client.stats.mark_incomplete(
            "capacity:future_occurrences_reduced", projection=True
        )
    buckets = build_buckets(config, runs)
    projection_report = projection_ledger(config, schedule_audit, future_runs)
    projection_complete = not config.future_enabled or not (
        client.stats.projection_incomplete_reasons
        or projection_report["unsupportedDags"]
        or projection_report["truncatedDags"]
    )
    _summary(
        "Projection summary",
        {
            "eligible_dags": sum(row.eligible for row in schedule_audit),
            "projected_dags": len({item.dag_id for item in future_runs}),
            "occurrences": len(future_runs),
            "excluded_dags": sum(not row.eligible for row in schedule_audit),
            "clamped": _bool_text(config.future_clamped),
            "complete": _bool_text(projection_complete),
        },
    )
    _summary("Projection eligibility", _projection_eligibility_summary(schedule_audit))
    _summary(
        "Capacity result",
        {
            "hist_rendered": len(runs),
            "hist_omitted": final_capacity_plan.historical_omitted,
            "future_rendered": len(future_runs),
            "future_omitted": final_capacity_plan.future_omitted,
            "total_rendered": (
                f"{len(runs) + len(future_runs)}/{MAX_TOTAL_TIMELINE_ITEMS_HARD}"
            ),
            "target": (
                f"configured={config.future_target_per_dag}, "
                f"effective={effective_target}"
            ),
            "target_met": f"{counts.target_met}/{counts.target_total} DAGs",
            "recalc": _bool_text(final_capacity_plan.recalculated),
            "reason": _capacity_reason(final_capacity_plan),
            "complete": _bool_text(
                final_capacity_plan.historical_omitted == 0
                and final_capacity_plan.future_omitted == 0
            ),
        },
    )
    _phase_end(4, 6, "Project", phase_started)
    return ProjectionStage(
        future_runs=future_runs,
        schedule_audit=schedule_audit,
        buckets=buckets,
        capacity_plan=final_capacity_plan,
        projection_ledger=projection_report,
        projection_complete=projection_complete,
    )


def _report_hostname() -> str:
    """Return one non-empty local host identity for report naming."""
    return socket.getfqdn().strip() or socket.gethostname().strip() or "airflow-host"


def _assemble_report(
    stage: ReportAssemblyStage,
    renderer: RendererTemplate | None,
    backend_sha256: str | None,
) -> Report:
    """Construct one canonical report from already-normalized stage results."""
    config = stage.config
    generated = pendulum.now(config.timezone)
    hostname = _report_hostname()
    report_id = stable_id(
        REPORT_ID,
        config.run_id,
        iso(config.history_start),
        iso(config.history_end),
        iso(config.future_effective_end),
        config.timezone,
        *stage.report_id_suffix,
    )
    projection = stage.projection
    return Report(
        config=config,
        generated_at=generated,
        output_path=output_path(generated, hostname),
        hostname=hostname,
        dags=stage.dags,
        runs=stage.runs,
        future_runs=projection.future_runs,
        schedule_audit=projection.schedule_audit,
        buckets=projection.buckets,
        stats=stage.stats,
        backend_sha256=backend_sha256 or sha256_file(Path(__file__)),
        renderer_sha256=(renderer or load_renderer(config.renderer_path)).sha256,
        report_id=report_id,
        historical_complete=stage.historical_complete,
        projection_complete=projection.projection_complete,
        capacity_plan=projection.capacity_plan,
        historical_ledger=historical_ledger(
            stage.stats,
            len({run.source_run_id for run in stage.collected_runs}),
            len({run.source_run_id for run in stage.runs}),
            len(stage.collected_runs),
            len(stage.runs),
        ),
        projection_ledger=projection.projection_ledger,
        historical_tag_source_runs=stage.historical_tag_runs,
        historical_tag_window_start=config.history_start,
        historical_tag_window_end=config.history_end,
        source_name=stage.source_name,
        source_mode=stage.source_mode,
        source_origin=stage.source_origin,
        airflow_ui_base_path=stage.airflow_ui_base_path,
        materialized_coverage=stage.materialized_coverage or {},
    )
