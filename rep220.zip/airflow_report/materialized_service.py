# SPDX-License-Identifier: Apache-2.0
"""Request-driven report assembly from validated local materialized partitions."""

from __future__ import annotations

from .api import ApiClient
from .capacity import apply_capacity_plan, plan_capacity, trim_runs_to_config
from .configuration_errors import fail
from .materialized import MaterializedDataset
from .api_contract import API_VERSION
from .models import ApiStats, Config, RendererTemplate, Report
from .normalization import merge_historic_dags, normalize_runs
from .preamble import Any, cast
from .service import _assemble_report, _project_future_runs, apply_render_cap
from .service_stages import ReportAssemblyStage


class _MaterializedClient:
    """Expose normalization-only client state and reject every API request."""

    def __init__(self, config: Config, stats: ApiStats) -> None:
        self.config = config
        self.stats = stats

    def get(self, *_args: object, **_kwargs: object) -> dict[str, Any]:
        """Reject a detail request because materialized builds are API-free."""
        fail("materialized report attempted an unexpected API detail request")

    def page(self, *_args: object, **_kwargs: object) -> list[dict[str, Any]]:
        """Reject a page request because materialized builds are API-free."""
        fail("materialized report attempted an unexpected API page request")


def build_materialized_report(
    config: Config,
    dataset: object,
    renderer: RendererTemplate | None = None,
    backend_sha256: str | None = None,
    *,
    airflow_ui_base_path: str = "",
) -> Report:
    """Build one report from validated local daily partitions without API reads."""
    if not isinstance(dataset, MaterializedDataset):
        fail("materialized dataset type is invalid")
    client = cast(ApiClient, _MaterializedClient(config, dataset.stats))
    dags = merge_historic_dags(dataset.dags, dataset.raw_runs)
    collected_runs = normalize_runs(client, dataset.raw_runs, dags)
    capacity_plan = plan_capacity(config, dags, collected_runs)
    effective_config = apply_capacity_plan(config, capacity_plan)
    historical_tag_runs = trim_runs_to_config(collected_runs, effective_config)
    runs = apply_render_cap(historical_tag_runs, effective_config, client.stats)
    if capacity_plan.historical_omitted:
        client.stats.mark_incomplete("capacity:historical_days_reduced")
    projection = _project_future_runs(
        effective_config, client, dags, runs, capacity_plan
    )
    return _assemble_report(
        ReportAssemblyStage(
            config=effective_config,
            dags=dags,
            collected_runs=collected_runs,
            historical_tag_runs=historical_tag_runs,
            runs=runs,
            projection=projection,
            stats=client.stats,
            historical_complete=(
                dataset.complete and not client.stats.incomplete_reasons
            ),
            source_name=(
                f"Airflow local daily materialization : Airflow REST API {API_VERSION}"
            ),
            source_mode="materialized",
            source_origin="local-fs:airflow-logs/report/json",
            airflow_ui_base_path=airflow_ui_base_path,
            materialized_coverage=dataset.coverage,
            report_id_suffix=(str(dataset.coverage.get("generation") or ""),),
        ),
        renderer,
        backend_sha256,
    )
