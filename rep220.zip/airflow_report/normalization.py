# SPDX-License-Identifier: Apache-2.0
"""Public normalization facade for DAG inventory and DAG-run processing."""

from __future__ import annotations

from .normalization_dags import fetch_dags as fetch_dags
from .normalization_records import (
    deduplicate_runs as deduplicate_runs,
)
from .normalization_records import (
    fetch_run_rows as fetch_run_rows,
)
from .normalization_records import (
    merge_historic_dags as merge_historic_dags,
)
from .normalization_records import (
    run_key as run_key,
)
from .normalization_runs import normalize_runs as normalize_runs
