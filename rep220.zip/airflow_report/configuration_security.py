# SPDX-License-Identifier: Apache-2.0
"""Trusted filesystem, redaction, URL, query, and hashing primitives."""

from __future__ import annotations

from .configuration_errors import fail, size_text
from .preamble import (
    AirflowFailException,
    Mapping,
    Path,
    Sequence,
    hashlib,
    json,
    os,
    re,
    stat,
    unquote,
    urlencode,
    urlsplit,
)


def _replace_quoted_secret(match: re.Match[str]) -> str:
    """Replace a matched quoted credential while preserving delimiters."""
    quote_char = match.group("quote")
    return f"{match.group('prefix')}{quote_char}<redacted>{quote_char}"


def redact_secret_text(value: object, limit: int = 500) -> str:
    """Redact supported credential forms from bounded diagnostic text."""
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    key = (
        r"(?:password|passwd|pwd|passphrase|secret|client[_-]?secret|"
        r"access[_-]?token|refresh[_-]?token|bearer[_-]?token|"
        r"session[_-]?token|id[_-]?token|api[_-]?key|secret[_-]?key|"
        r"private[_-]?key|token)"
    )
    boundary_key = rf"(?<![A-Za-z0-9_-]){key}(?![A-Za-z0-9_-])"
    quoted = re.compile(
        rf"(?is)(?P<prefix>(?:[\"'])?{boundary_key}(?:[\"'])?\s*[:=]\s*)"
        rf"(?P<quote>[\"'])(?:\\.|(?!\\|(?P=quote)).)*(?:(?P=quote)|\\?$)"
    )
    text = quoted.sub(_replace_quoted_secret, text)
    auth_quoted = re.compile(
        r"(?is)(?P<prefix>(?<![A-Za-z0-9_-])(?:[\"'])?(?:proxy-)?authorization"
        r"(?:[\"'])?(?![A-Za-z0-9_-])\s*[:=]\s*"
        r"(?P<quote>[\"'])(?:bearer|basic)\s+)"
        r"(?:\\.|(?!\\|(?P=quote)).)*(?:(?P=quote)|\\?$)"
    )
    text = auth_quoted.sub(
        lambda match: f"{match.group('prefix')}<redacted>{match.group('quote')}",
        text,
    )
    text = re.sub(
        r"(?i)((?<![A-Za-z0-9_-])(?:proxy-)?authorization"
        r"(?![A-Za-z0-9_-])\s*[:=]\s*(?:bearer|basic)\s+)"
        r"[^\s,;}&]+",
        r"\1<redacted>",
        text,
    )
    text = re.sub(
        rf"(?i)({boundary_key}\s*[:=]\s*)[^\s,;}}\]&\"']+",
        r"\1<redacted>",
        text,
    )
    text = re.sub(
        rf"(?i)([?&]{key}(?![A-Za-z0-9_-])=)(?:[\"'](?:\\.|[^\"'])*[\"']|[^&\s]+)",
        r"\1<redacted>",
        text,
    )
    text = re.sub(
        r"(?i)([a-z][a-z0-9+.-]*://[^/\s:@]+:)[^@/\s]+(@)",
        r"\1<redacted>\2",
        text,
    )
    return text[:limit]


def absolute_path_without_resolving(value: object, label: str) -> Path:
    """Return an absolute lexical path without dereferencing filesystem links.

    Explicit ``.`` and ``..`` components are rejected before normalization so
    the configured intent remains auditable and cannot be hidden by
    :func:`os.path.abspath`.
    """
    text = str(value or "").strip()
    if not text or "\x00" in text:
        fail(f"{label} must be a non-empty filesystem path")
    raw_components = tuple(part for part in text.split("/") if part)
    if any(component in {".", ".."} for component in raw_components):
        fail(f"{label} must not contain traversal components")
    try:
        expanded = os.path.expanduser(text)
        expanded_components = tuple(part for part in expanded.split("/") if part)
        if any(component in {".", ".."} for component in expanded_components):
            fail(f"{label} must not contain traversal components")
        return Path(os.path.abspath(expanded))
    except AirflowFailException:
        raise
    except (OSError, ValueError) as exc:
        raise AirflowFailException(
            f"invalid {label}: {redact_secret_text(exc, 240)}"
        ) from exc


def _directory_component_metadata(
    parent_descriptor: int,
    component: str,
    configured_mode: int | None,
    create: bool,
) -> tuple[os.stat_result, bool]:
    """Inspect one component and report whether this call created it."""
    try:
        return (
            os.stat(
                component,
                dir_fd=parent_descriptor,
                follow_symlinks=False,
            ),
            False,
        )
    except FileNotFoundError:
        if not create:
            raise
    mode = configured_mode if configured_mode is not None else 0o777
    created = False
    try:
        os.mkdir(component, mode=mode, dir_fd=parent_descriptor)
        created = True
    except FileExistsError:
        pass
    return (
        os.stat(
            component,
            dir_fd=parent_descriptor,
            follow_symlinks=False,
        ),
        created,
    )


def _validate_directory_component(metadata: os.stat_result, label: str) -> None:
    """Require one inspected component to be a real directory."""
    if stat.S_ISLNK(metadata.st_mode):
        fail(f"{label} contains a symbolic-link component")
    if not stat.S_ISDIR(metadata.st_mode):
        fail(f"{label} component is not a directory")


def _open_verified_directory_component(
    parent_descriptor: int,
    component: str,
    metadata: os.stat_result,
    flags: int,
    label: str,
    *,
    created: bool,
    configured_mode: int | None,
) -> int:
    """Open one component, verify its identity, and finalize a new mode."""
    descriptor: int | None = None
    try:
        descriptor = os.open(component, flags, dir_fd=parent_descriptor)
        opened = os.fstat(descriptor)
        if (
            not stat.S_ISDIR(opened.st_mode)
            or opened.st_dev != metadata.st_dev
            or opened.st_ino != metadata.st_ino
        ):
            fail(f"{label} component changed while being opened")
        if created and configured_mode is not None:
            expected_mode = stat.S_IMODE(configured_mode)
            os.fchmod(descriptor, expected_mode)
            actual_mode = stat.S_IMODE(os.fstat(descriptor).st_mode)
            if actual_mode != expected_mode:
                fail(
                    f"{label} component mode verification failed: "
                    f"expected={expected_mode:04o}, actual={actual_mode:04o}"
                )
        return descriptor
    except (OSError, AirflowFailException):
        if descriptor is not None:
            os.close(descriptor)
        raise


def open_trusted_directory(
    path: Path,
    configured_mode: int | None = None,
    *,
    create: bool = False,
    label: str = "filesystem directory",
) -> int:
    """Open or create an absolute directory through no-follow descriptors."""
    if any(component in {".", ".."} for component in path.parts):
        fail(f"{label} must not contain traversal components")
    absolute = absolute_path_without_resolving(path, label)
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_CLOEXEC", 0)
    nofollow = getattr(os, "O_NOFOLLOW", 0)
    descriptor: int | None = None
    keep_open = False
    try:
        descriptor = os.open("/", flags)
        for component in absolute.parts[1:]:
            if component in {"", ".", ".."}:
                fail(f"{label} contains an invalid path component")
            metadata, created = _directory_component_metadata(
                descriptor,
                component,
                configured_mode,
                create,
            )
            _validate_directory_component(metadata, label)
            next_descriptor = _open_verified_directory_component(
                descriptor,
                component,
                metadata,
                flags | nofollow,
                label,
                created=created,
                configured_mode=configured_mode,
            )
            os.close(descriptor)
            descriptor = next_descriptor
        keep_open = True
        return descriptor
    except AirflowFailException:
        raise
    except (OSError, ValueError, NotImplementedError) as exc:
        raise AirflowFailException(
            f"{label} access failed: {redact_secret_text(exc, 300)}"
        ) from exc
    finally:
        if descriptor is not None and not keep_open:
            os.close(descriptor)


def _file_signature(metadata: os.stat_result) -> tuple[int, int, int, int, int]:
    """Return the identity and mutable metadata used for TOCTOU detection."""
    return (
        metadata.st_dev,
        metadata.st_ino,
        metadata.st_size,
        metadata.st_mtime_ns,
        metadata.st_ctime_ns,
    )


def _validate_regular_file(
    metadata: os.stat_result, max_bytes: int, label: str
) -> None:
    """Reject non-regular or already-oversized input before reading."""
    if not stat.S_ISREG(metadata.st_mode):
        fail(f"{label} must be a regular file")
    if metadata.st_size > max_bytes:
        fail(
            f"{label} exceeds byte limit size=({size_text(metadata.st_size)}) "
            f"limit=({size_text(max_bytes)})"
        )


def _read_bounded_descriptor(descriptor: int, max_bytes: int, label: str) -> bytes:
    """Read one descriptor with a hard byte ceiling and bounded chunks."""
    chunks: list[bytes] = []
    total = 0
    while True:
        remaining = max_bytes + 1 - total
        if remaining <= 0:
            fail(f"{label} exceeds byte limit")
        chunk = os.read(descriptor, min(1024 * 1024, remaining))
        if not chunk:
            break
        chunks.append(chunk)
        total += len(chunk)
    payload = b"".join(chunks)
    if len(payload) > max_bytes:
        fail(f"{label} exceeds byte limit")
    return payload


def _verify_stable_descriptor(
    descriptor: int,
    payload: bytes,
    final_signature: tuple[int, int, int, int, int],
    max_bytes: int,
    label: str,
) -> None:
    """Re-read and hash one descriptor to prove stable content when requested."""
    first_digest = hashlib.sha256(payload).digest()
    os.lseek(descriptor, 0, os.SEEK_SET)
    verification = hashlib.sha256()
    verified_size = 0
    while True:
        chunk = os.read(descriptor, min(1024 * 1024, max_bytes + 1 - verified_size))
        if not chunk:
            break
        verification.update(chunk)
        verified_size += len(chunk)
        if verified_size > max_bytes:
            fail(f"{label} exceeds byte limit during stability verification")
    if (
        _file_signature(os.fstat(descriptor)) != final_signature
        or verified_size != len(payload)
        or verification.digest() != first_digest
    ):
        fail(f"{label} changed during stable-content verification")


def read_bounded_regular_file(
    path: Path,
    max_bytes: int,
    label: str,
    *,
    verify_stable_content: bool = False,
) -> tuple[bytes, int, int]:
    """Read one regular file through a bounded no-follow descriptor."""
    absolute = absolute_path_without_resolving(path, label)
    directory_fd = open_trusted_directory(absolute.parent, label=f"{label} parent")
    descriptor: int | None = None
    try:
        flags = (
            os.O_RDONLY
            | getattr(os, "O_CLOEXEC", 0)
            | getattr(os, "O_NOFOLLOW", 0)
            | getattr(os, "O_NONBLOCK", 0)
        )
        descriptor = os.open(absolute.name, flags, dir_fd=directory_fd)
        initial = os.fstat(descriptor)
        _validate_regular_file(initial, max_bytes, label)
        payload = _read_bounded_descriptor(descriptor, max_bytes, label)
        final = os.fstat(descriptor)
        final_signature = _file_signature(final)
        if _file_signature(initial) != final_signature or final.st_size != len(payload):
            fail(f"{label} content or metadata changed while being read")
        if verify_stable_content:
            _verify_stable_descriptor(
                descriptor, payload, final_signature, max_bytes, label
            )
        return payload, final.st_dev, final.st_ino
    except AirflowFailException:
        raise
    except OSError as exc:
        raise AirflowFailException(
            f"{label} open/read failed: {redact_secret_text(exc, 300)}"
        ) from exc
    finally:
        if descriptor is not None:
            os.close(descriptor)
        os.close(directory_fd)


def sha256_file(path: Path) -> str:
    """Compute a streaming SHA-256 digest for a regular file path."""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_problem_detail_bytes(content: bytes, reason: object) -> tuple[str, str]:
    """Extract a bounded redacted problem code and detail from bytes."""
    code = "http_error"
    values: list[str] = []
    try:
        payload = json.loads(content)
    except (UnicodeDecodeError, ValueError):
        payload = None
    if isinstance(payload, Mapping):
        code = redact_secret_text(
            payload.get("code") or payload.get("type") or "http_error", 80
        )
        for key_name in ("title", "detail", "message"):
            item = payload.get(key_name)
            if item not in (None, ""):
                values.append(redact_secret_text(item, 240))
    if not values:
        values.append(redact_secret_text(reason or "request failed", 240))
    return code, " | ".join(values)[:500]


def safe_url_path_segments(path: str, label: str) -> list[str]:
    """Validate and return decoded URL path segments."""
    decoded = unquote(path)
    segments = [part for part in decoded.split("/") if part]
    if "%" in path:
        fail(f"{label} path must not contain percent encoding")
    if "\\" in decoded:
        fail(f"{label} path must not contain backslashes")
    if any(ord(char) < 32 or char.isspace() for char in decoded):
        fail(f"{label} path must not contain whitespace or control characters")
    if any(part in {".", ".."} for part in segments):
        fail(f"{label} path must not contain traversal segments")
    return segments


def validate_relative_endpoint(value: object, label: str) -> str:
    """Validate an absolute-path-only relative API endpoint."""
    text = str(value or "").strip()
    try:
        parsed = urlsplit(text)
    except ValueError as exc:
        raise AirflowFailException(f"invalid {label}") from exc
    invalid_reference = (
        not text.startswith("/")
        or text.startswith("//")
        or bool(parsed.scheme or parsed.netloc or parsed.query or parsed.fragment)
    )
    if invalid_reference:
        fail(
            f"{label} must be an absolute-path reference without host, query, or fragment"
        )
    segments = safe_url_path_segments(parsed.path, label)
    if not segments:
        fail(f"{label} must identify a non-root endpoint")
    return "/" + "/".join(segments)


def query_pairs(
    values: Mapping[str, object] | Sequence[tuple[str, object]] | None,
) -> list[tuple[str, object]]:
    """Flatten mapping or sequence query parameters deterministically."""
    if values is None:
        return []
    source = values.items() if isinstance(values, Mapping) else values
    pairs: list[tuple[str, object]] = []
    for key, value in source:
        if value is None:
            continue
        if isinstance(value, set):
            pairs.extend((str(key), item) for item in sorted(value, key=str))
        elif isinstance(value, (list, tuple)):
            pairs.extend((str(key), item) for item in value)
        else:
            pairs.append((str(key), value))
    return pairs


def canonical_query(pairs: Sequence[tuple[str, object]]) -> str:
    """Serialize query pairs in deterministic canonical order."""
    normalized = sorted(
        (
            (str(key), str(value).lower() if isinstance(value, bool) else str(value))
            for key, value in pairs
        )
    )
    return urlencode(normalized, doseq=True)


def request_fingerprint(
    method: str, endpoint: str, pairs: Sequence[tuple[str, object]]
) -> str:
    """Hash one method, endpoint, and canonical query tuple."""
    raw = f"{method.upper()}\n{endpoint}\n{canonical_query(pairs)}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()
