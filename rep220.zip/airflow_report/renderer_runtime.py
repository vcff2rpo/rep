# SPDX-License-Identifier: Apache-2.0
"""Renderer validation and bounded in-memory or streamed HTML assembly."""

from __future__ import annotations

from .configuration_errors import fail, size_text
from .configuration_security import read_bounded_regular_file, redact_secret_text
from .models import RendererTemplate, Report
from .payload import build_payload
from .preamble import (
    DATA_PLACEHOLDER,
    EXPECTED_RENDERER_SHA256,
    LOG,
    MAX_RENDERER_BYTES,
    RELEASE_ID,
    RENDERER_CONTRACT,
    REQUIRED_DOM_IDS,
    AirflowFailException,
    Any,
    Counter,
    Final,
    HTMLParser,
    Iterable,
    Mapping,
    Path,
    hashlib,
    json,
    tempfile,
)

CONTRACT_TOKEN = (
    f'<meta name="airflow-report-renderer-contract" content="{RENDERER_CONTRACT}">'
)
RELEASE_TOKEN = f'<meta name="airflow-report-renderer-release" content="{RELEASE_ID}">'


class _StaticIdParser(HTMLParser):
    """Collect static HTML id attributes without interpreting scripts."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=False)
        self.ids: list[str] = []

    def _collect(self, attrs: list[tuple[str, str | None]]) -> None:
        for name, value in attrs:
            if name.lower() == "id" and value is not None:
                self.ids.append(value)

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        """Collect id attributes from a standard HTML start tag."""
        self._collect(attrs)

    handle_startendtag = handle_starttag


def static_dom_ids(markup: str) -> tuple[str, ...]:
    """Parse and return all static DOM ids from renderer markup."""
    parser = _StaticIdParser()
    try:
        parser.feed(markup)
        parser.close()
    except (AssertionError, TypeError, ValueError) as exc:
        raise AirflowFailException(
            f"renderer static HTML parse failed: {redact_secret_text(exc, 300)}"
        ) from exc
    return tuple(parser.ids)


def validate_static_renderer_contract(markup: str, *, rendered: bool = False) -> None:
    """Validate required and duplicate static DOM ids."""
    ids = static_dom_ids(markup)
    duplicates = sorted(value for value, count in Counter(ids).items() if count > 1)
    if duplicates:
        fail(f"renderer static HTML contains duplicate DOM ids: {duplicates[:12]}")
    available = set(ids)
    missing = [dom_id for dom_id in REQUIRED_DOM_IDS if dom_id not in available]
    if missing:
        phase = "rendered HTML" if rendered else "HTML renderer template"
        fail(f"{phase} contract missing static DOM ids: {missing}")


def load_renderer(path: Path) -> RendererTemplate:
    """Load and validate one bounded renderer object without pathname dereference."""
    payload, _device, _inode = read_bounded_regular_file(
        path, MAX_RENDERER_BYTES, "renderer template 8 MiB hard limit"
    )
    actual_sha256 = hashlib.sha256(payload).hexdigest()
    if actual_sha256 != EXPECTED_RENDERER_SHA256:
        fail(
            "renderer template SHA-256 mismatch "
            f"expected={EXPECTED_RENDERER_SHA256} actual={actual_sha256}"
        )
    try:
        template = payload.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise AirflowFailException(
            f"renderer template is not valid UTF-8: {redact_secret_text(exc, 300)}"
        ) from exc
    missing: list[str] = []
    if CONTRACT_TOKEN not in template:
        missing.append("semantic renderer contract token")
    if RELEASE_TOKEN not in template:
        missing.append("exact renderer release token")
    if template.count(DATA_PLACEHOLDER) != 1:
        missing.append("exactly one runtime data placeholder")
    if missing:
        fail(f"HTML renderer template contract mismatch: {missing}")
    validate_static_renderer_contract(template)
    LOG.debug(
        "REPORT | RENDERER_PREREQUISITE | file=%s | size=%s | sha256=%s",
        path.name,
        size_text(len(payload)),
        actual_sha256,
    )
    return RendererTemplate(text=template, sha256=actual_sha256, size=len(payload))


def _escape_inline_json(text: str) -> str:
    """Escape characters unsafe inside an inline script JSON literal."""
    return (
        text.replace("&", "\\u0026")
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    )


def _iter_json_bytes(payload: object) -> Iterable[bytes]:
    """Encode canonical JSON into bounded UTF-8 chunks."""
    encoder = json.JSONEncoder(
        ensure_ascii=False, separators=(",", ":"), sort_keys=True
    )
    buffer = bytearray()
    flush_bytes = 256 * 1024
    for chunk in encoder.iterencode(payload):
        escaped = _escape_inline_json(chunk)
        if not escaped:
            continue
        buffer.extend(escaped.encode("utf-8"))
        if len(buffer) >= flush_bytes:
            yield bytes(buffer)
            buffer.clear()
    if buffer:
        yield bytes(buffer)


PAYLOAD_BYTE_MARKER: Final[bytes] = b"__000000000000__"
REPORT_BYTE_MARKER: Final[bytes] = b"__111111111111__"


def _iter_replaced_spool(
    handle: Any, replacements: Mapping[bytes, bytes], chunk_size: int = 256 * 1024
) -> Iterable[bytes]:
    """Stream a spool while replacing fixed-width markers across chunk edges."""
    overlap = max((len(marker) for marker in replacements), default=1) - 1
    carry = b""
    while True:
        chunk = handle.read(chunk_size)
        if not chunk:
            data = carry
            for marker, replacement in replacements.items():
                data = data.replace(marker, replacement)
            if data:
                yield data
            return
        data = carry + chunk
        if len(data) <= overlap:
            carry = data
            continue
        emit, carry = data[:-overlap], data[-overlap:]
        for marker, replacement in replacements.items():
            emit = emit.replace(marker, replacement)
        yield emit


def _renderer_chunks(report: Report, renderer: RendererTemplate) -> Iterable[bytes]:
    """Yield renderer bytes with exact payload/report byte telemetry."""
    prefix, separator, suffix = renderer.text.partition(DATA_PLACEHOLDER)
    if not separator or DATA_PLACEHOLDER in suffix:
        fail("renderer must contain exactly one runtime data placeholder")
    prefix_bytes = prefix.encode("utf-8")
    suffix_bytes = suffix.encode("utf-8")
    payload = build_payload(report)
    with tempfile.SpooledTemporaryFile(max_size=8 * 1024 * 1024, mode="w+b") as spool:
        payload_bytes = 0
        for chunk in _iter_json_bytes(payload):
            spool.write(chunk)
            payload_bytes += len(chunk)
        report_bytes = len(prefix_bytes) + payload_bytes + len(suffix_bytes)
        replacements = {
            PAYLOAD_BYTE_MARKER: f"{payload_bytes:016d}".encode("ascii"),
            REPORT_BYTE_MARKER: f"{report_bytes:016d}".encode("ascii"),
        }
        if any(len(marker) != len(value) for marker, value in replacements.items()):
            fail("internal fixed-width byte telemetry marker mismatch")
        spool.seek(0)
        yield prefix_bytes
        yield from _iter_replaced_spool(spool, replacements)
        yield suffix_bytes


def render_html(report: Report, renderer: RendererTemplate) -> str:
    """Render one bounded in-memory document for request-driven delivery and tests."""
    chunks: list[bytes] = []
    total = 0
    for chunk in _renderer_chunks(report, renderer):
        total += len(chunk)
        if total > report.config.max_html_bytes:
            fail(
                "rendered HTML exceeds MAX_HTML_BYTES "
                f"size>(limit={size_text(report.config.max_html_bytes)})"
            )
        chunks.append(chunk)
    try:
        return b"".join(chunks).decode("utf-8")
    except UnicodeDecodeError as exc:
        raise AirflowFailException(
            f"rendered HTML is not valid UTF-8: {redact_secret_text(exc, 300)}"
        ) from exc
