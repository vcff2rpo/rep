# SPDX-License-Identifier: Apache-2.0
"""Shared local-calendar interval construction for report window planning."""

from __future__ import annotations

from .configuration_values import instant_microseconds
from .preamble import pendulum


def calendar_intervals(
    start: pendulum.DateTime, end: pendulum.DateTime
) -> tuple[tuple[pendulum.DateTime, pendulum.DateTime], ...]:
    """Split absolute instants at local midnights, preserving variable day lengths."""
    start_key = instant_microseconds(start)
    end_key = instant_microseconds(end)
    if end_key <= start_key:
        return ()
    if start.date() == end.date():
        return ((start, end),)
    values: list[tuple[pendulum.DateTime, pendulum.DateTime]] = []
    cursor = start.start_of("day")
    bounded_start = start
    while True:
        next_day = cursor.add(days=1)
        next_key = instant_microseconds(next_day)
        if next_key >= end_key:
            values.append((bounded_start, end))
            break
        values.append((bounded_start, next_day))
        bounded_start = next_day
        cursor = next_day
    return tuple(values)
