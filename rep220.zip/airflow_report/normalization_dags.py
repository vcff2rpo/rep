# SPDX-License-Identifier: Apache-2.0
"""DAG inventory collection and bounded detail enrichment."""

from __future__ import annotations

from .api import ApiClient
from .api_contract import API_SOURCE_LABEL, DAG_INVENTORY_QUERY
from .configuration_errors import ApiError
from .configuration_security import redact_secret_text
from .configuration_values import first_text
from .models import ApiStats, DagInfo
from .normalization_schedule import classify_dag
from .preamble import (
    LOG,
    AirflowFailException,
    Any,
    Counter,
    Mapping,
    Sequence,
    quote,
    replace,
)


def unwrap_detail(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Unwrap a nested DAG-detail response when present."""
    for key in ("dag", "details", "data"):
        nested = payload.get(key)
        if isinstance(nested, Mapping):
            merged = dict(payload)
            merged.update(nested)
            return merged
    return dict(payload)


def detail_failure_status(exc: BaseException) -> tuple[str, str, bool]:
    """Map a DAG-detail HTTP failure into a bounded status label."""
    if isinstance(exc, ApiError):
        if exc.status == 401:
            return ("authentication-failed", "DAG details authentication failed", True)
        mapping = {
            400: ("validation-error", "DAG details validation failed"),
            403: ("details-forbidden", "DAG details forbidden"),
            404: ("not-found", "DAG details unavailable"),
            405: ("not-supported", "DAG details endpoint unsupported"),
            422: ("validation-error", "DAG details validation failed"),
            429: ("rate-limited", "DAG details rate limited"),
        }
        if exc.status in mapping:
            status, reason = mapping[exc.status]
            return (status, reason, False)
        if exc.status >= 500:
            return ("server-unavailable", "DAG details service unavailable", False)
    return ("transport-unavailable", "DAG details transport unavailable", False)


def enrich_dag_details(
    client: ApiClient,
    raw_rows: Mapping[str, Mapping[str, Any]],
    result: dict[str, DagInfo],
) -> None:
    """Fetch bounded detail records only where collection data is insufficient."""
    deficient = [
        dag_id
        for dag_id, info in result.items()
        if not info.stale
        and (info.next_run is None or info.schedule_timezone_source == "unresolved")
    ]
    for dag_id in deficient[: client.config.max_detail_calls]:
        try:
            detail = unwrap_detail(client.get(f"dags/{quote(dag_id, safe='')}/details"))
        except AirflowFailException as exc:
            status, reason, fatal = detail_failure_status(exc)
            if fatal:
                raise
            client.stats.dag_detail_unavailable += 1
            client.stats.mark_incomplete(f"{dag_id}:{status}", projection=True)
            result[dag_id] = replace(
                result[dag_id], detail_status=status, exclusion_reason=reason
            )
            continue
        merged = dict(raw_rows[dag_id])
        merged.update(
            {
                key: value
                for key, value in detail.items()
                if value not in (None, "", [], {})
            }
        )
        result[dag_id] = classify_dag(
            merged,
            client.config.timezone,
            f"{API_SOURCE_LABEL}_details",
            "success",
        )
    for dag_id in deficient[client.config.max_detail_calls :]:
        client.stats.dag_detail_unavailable += 1
        client.stats.mark_incomplete(f"{dag_id}:budget-exhausted", projection=True)
        result[dag_id] = replace(
            result[dag_id],
            detail_status="budget-exhausted",
            exclusion_reason="DAG details request budget exhausted",
        )


def log_dag_inventory(
    rows: Sequence[Mapping[str, Any]], result: Mapping[str, DagInfo], stats: ApiStats
) -> None:
    """Write summarized and debug-level DAG inventory telemetry."""
    kind_counts = Counter(info.schedule_kind for info in result.values())
    source_counts = Counter(info.schedule_source for info in result.values())
    eligible = sum(info.eligible for info in result.values())
    paused_eligible = sum(info.eligible and info.paused for info in result.values())
    exclusions = Counter(
        info.exclusion_reason or "none" for info in result.values() if not info.eligible
    )
    detail_statuses = Counter(info.detail_status for info in result.values())
    timezone_sources = Counter(
        info.schedule_timezone_source for info in result.values()
    )
    LOG.debug(
        "REPORT | INVENTORY | rows=%s | normalized=%s | eligible=%s | "
        "paused_eligible=%s | detail_calls=%s | detail_unavailable=%s",
        len(rows),
        len(result),
        eligible,
        paused_eligible,
        stats.dag_detail_calls,
        stats.dag_detail_unavailable,
    )
    LOG.debug(
        "REPORT | INVENTORY | schedule_kinds=%s | schedule_sources=%s | "
        "timezone_sources=%s",
        dict(kind_counts),
        dict(source_counts),
        dict(timezone_sources),
    )
    LOG.debug(
        "REPORT | INVENTORY | exclusion_counts=%s | detail_statuses=%s",
        dict(exclusions),
        dict(detail_statuses),
    )
    for dag_id, info in sorted(result.items(), key=lambda item: item[0].casefold()):
        LOG.debug(
            "REPORT | INVENTORY_DETAIL | dag_id=%s | kind=%s | source=%s | "
            "timezone=%s | timezone_source=%s | eligible=%s | reason=%s | "
            "detail=%s",
            dag_id,
            info.schedule_kind,
            info.schedule_source,
            info.schedule_timezone or "none",
            info.schedule_timezone_source,
            info.eligible,
            info.exclusion_reason or "none",
            info.detail_status,
        )


def fetch_dags(client: ApiClient) -> dict[str, DagInfo]:
    """Fetch, normalize, enrich, and deterministically order DAG metadata."""
    rows = client.page("dags", "dags", DAG_INVENTORY_QUERY)
    raw_rows: dict[str, dict[str, Any]] = {}
    result: dict[str, DagInfo] = {}
    for row in rows:
        dag_id = first_text(row, "dag_id", "dagId")
        if not dag_id:
            client.stats.identity_rejections += 1
            client.stats.rejected_members += 1
            client.stats.mark_incomplete("dags:missing_identity")
            continue
        try:
            info = classify_dag(
                row, client.config.timezone, f"{API_SOURCE_LABEL}_collection"
            )
        except AirflowFailException as exc:
            client.stats.normalization_rejections += 1
            client.stats.rejected_members += 1
            client.stats.mark_incomplete("dags:normalization_rejection")
            LOG.warning(
                "rejected malformed DAG row dag_id=%s error=%s",
                dag_id,
                redact_secret_text(exc, 200),
            )
            continue
        raw_rows[dag_id] = dict(row)
        result[dag_id] = info
    if client.config.future_enabled:
        enrich_dag_details(client, raw_rows, result)
    log_dag_inventory(rows, result, client.stats)
    return result
