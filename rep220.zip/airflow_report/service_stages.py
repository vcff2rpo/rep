# SPDX-License-Identifier: Apache-2.0
"""Typed stage results for report collection and projection orchestration."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from .models import Bucket, CapacityPlan, Config, DagInfo, FutureRun, Run, ScheduleAudit


@dataclass(frozen=True, slots=True)
class HistoricalCollectionStage:
    """Contain the complete historical collection stage result."""

    config: Config
    dags: dict[str, DagInfo]
    collected_runs: tuple[Run, ...]
    capacity_retained_runs: tuple[Run, ...]
    runs: tuple[Run, ...]
    capacity_plan: CapacityPlan


@dataclass(frozen=True, slots=True)
class ProjectionStage:
    """Contain the complete future projection stage result."""

    future_runs: tuple[FutureRun, ...]
    schedule_audit: tuple[ScheduleAudit, ...]
    buckets: tuple[Bucket, ...]
    capacity_plan: CapacityPlan
    projection_ledger: dict[str, Any]
    projection_complete: bool


@dataclass(frozen=True, slots=True)
class ReportAssemblyStage:
    """Contain normalized inputs required to construct one canonical report."""

    config: Config
    dags: Mapping[str, DagInfo]
    collected_runs: tuple[Run, ...]
    historical_tag_runs: tuple[Run, ...]
    runs: tuple[Run, ...]
    projection: ProjectionStage
    stats: Any
    historical_complete: bool
    source_name: str
    source_mode: str
    source_origin: str
    airflow_ui_base_path: str = ""
    materialized_coverage: Mapping[str, Any] | None = None
    report_id_suffix: tuple[str, ...] = ()
