# SPDX-License-Identifier: Apache-2.0
"""DAG-run retrieval, identity, and deterministic deduplication."""

from __future__ import annotations

from .api import ApiClient
from .configuration_errors import ApiError, fail
from .configuration_values import dt_or_none, first_text
from .api_contract import API_MULTI_VALUE_PARAMETERS, API_VALIDATION_STATUSES, API_VERSION
from .models import ApiStats, Config, DagInfo
from .preamble import LOG, Any, Iterable, Mapping, Sequence, json


def run_key(row: Mapping[str, Any]) -> tuple[str, str]:
    """Return the canonical DAG/run identity tuple for an API row."""
    return (
        first_text(row, "dag_id", "dagId"),
        first_text(row, "dag_run_id", "dagRunId", "run_id", "runId"),
    )


def record_quality(row: Mapping[str, Any]) -> tuple[int, int, str]:
    """Rank duplicate API rows by freshness, completeness, and canonical form."""
    timestamp = dt_or_none(
        row,
        "UTC",
        "last_updated",
        "lastUpdated",
        "end_date",
        "endDate",
        "start_date",
        "startDate",
        "queued_at",
        "queuedAt",
    )
    timestamp_rank = (
        timestamp.int_timestamp * 1_000_000 + timestamp.microsecond if timestamp else -1
    )
    meaningful = sum(
        value not in (None, "", [], {})
        for key, value in row.items()
        if key not in {"conf", "note"}
    )
    canonical = json.dumps(row, sort_keys=True, separators=(",", ":"), default=str)
    return timestamp_rank, meaningful, canonical


def deduplicate_runs(
    rows: Iterable[dict[str, Any]], stats: ApiStats | None = None
) -> list[dict[str, Any]]:
    """Select one deterministic record for each DAG/run identity."""
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for row in rows:
        key = run_key(row)
        if not all(key):
            if stats is not None:
                stats.identity_rejections += 1
                stats.rejected_members += 1
                stats.mark_incomplete("dagRuns:missing_identity")
            continue
        grouped.setdefault(key, []).append(dict(row))
    selected: list[dict[str, Any]] = []
    for key in sorted(grouped, key=lambda value: (value[0].casefold(), value[1])):
        candidates = grouped[key]
        winner = max(candidates, key=record_quality)
        if len(candidates) > 1 and any(candidate != winner for candidate in candidates):
            if stats is not None:
                stats.duplicate_conflicts += len(candidates) - 1
                stats.mark_incomplete("dagRuns:duplicate_conflicts")
        selected.append(winner)
    return selected


def encoded_list_pairs(
    key: str, values: Sequence[object]
) -> tuple[tuple[str, object], ...]:
    """Encode list-valued query parameters for the API v2 contract."""
    cleaned = tuple((value for value in values if value not in (None, "")))
    if not cleaned:
        return ()
    if key in API_MULTI_VALUE_PARAMETERS:
        return tuple((key, value) for value in cleaned)
    if len(cleaned) != 1:
        fail(f"query parameter {key!r} is scalar but received {len(cleaned)} values")
    return ((key, cleaned[0]),)


def global_run_queries(
    config: Config,
) -> tuple[tuple[tuple[str, object], ...], ...]:
    """Build bounded historical and active-run queries for API v2."""
    start = config.history_start.in_timezone("UTC").to_iso8601_string()
    end = config.history_end.in_timezone("UTC").to_iso8601_string()
    order_field = "id"
    closed = (
        ("start_date_lte", end),
        ("end_date_gte", start),
        ("order_by", order_field),
    )
    active = (
        *encoded_list_pairs("state", ("running", "queued")),
        ("order_by", order_field),
    )
    return closed, active


def fetch_run_rows(client: ApiClient) -> list[dict[str, Any]]:
    """Fetch, combine, and deduplicate global DAG-run rows."""
    rows: list[dict[str, Any]] = []
    plans = global_run_queries(client.config)
    client.stats.active_query_strategy = (
        "bounded-active-state-without-start-lower-bound"
    )
    LOG.debug(
        "REPORT | RUN_QUERY | global_shapes=%s | active_strategy=%s | "
        "exceptional_fallbacks=0 | per_dag_default=0 | timezone=UTC",
        len(plans),
        client.stats.active_query_strategy,
    )
    for plan in plans:
        try:
            rows.extend(client.page("dags/~/dagRuns", "dag_runs", plan))
        except ApiError as exc:
            if exc.status in API_VALIDATION_STATUSES:
                fail(
                    f"bounded DAG-run query rejected by API {API_VERSION}; "
                    "no unbounded fallback is permitted. Verify the API v2 endpoint "
                    "profile or reduce the requested window"
                )
            raise
    deduplicated = deduplicate_runs(rows, client.stats)
    client.stats.raw_run_rows = len(rows)
    client.stats.deduplicated_run_rows = len(deduplicated)
    LOG.debug(
        "REPORT | RUN_RETRIEVAL | raw=%s | deduplicated=%s | conflicts=%s | "
        "identity_rejections=%s | global_calls=%s",
        len(rows),
        len(deduplicated),
        client.stats.duplicate_conflicts,
        client.stats.identity_rejections,
        client.stats.global_run_calls,
    )
    return deduplicated


def merge_historic_dags(
    dags: Mapping[str, DagInfo], rows: Iterable[Mapping[str, Any]]
) -> dict[str, DagInfo]:
    """Add deterministic stale metadata for historical-only DAGs."""
    merged = dict(dags)
    for row in rows:
        dag_id, _ = run_key(row)
        if dag_id and dag_id not in merged:
            merged[dag_id] = DagInfo(
                dag_id=dag_id,
                tags=("historic", "stale"),
                owner="unknown",
                fileloc="<not present in current DAG inventory>",
                paused=False,
                stale=True,
                schedule_kind="none",
                schedule_expression="",
                schedule_summary="",
                schedule_timezone="",
                schedule_timezone_source="not-applicable",
                schedule_source="historic-run",
                next_run=None,
                eligible=False,
                exclusion_reason=(
                    "historical run only; no authoritative current schedule"
                ),
                detail_status="not-applicable",
            )
    return merged
