# SPDX-License-Identifier: Apache-2.0
"""Bounded, read-only task and attempt data for a DAG run or complete DAG-lane run scope.

No credentials, executor metadata, caches or materialized report partitions are
included in this contract. REST history is an unpaginated collection; the current
instance list uses the existing client's complete offset pagination.
"""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime, timezone
from time import monotonic
from typing import TYPE_CHECKING, Any, Literal, TypedDict
from urllib.parse import quote

from .generated_contracts import (
    TASK_TIMELINE_ERROR_SCHEMA,
    TASK_TIMELINE_ERRORS,
    TASK_TIMELINE_LIMITS,
)

MAX_RUNS = TASK_TIMELINE_LIMITS["runs"]
MAX_API_CALLS = TASK_TIMELINE_LIMITS["upstreamCalls"]
MAX_API_BYTES = TASK_TIMELINE_LIMITS["upstreamBytes"]
MAX_TASKS = TASK_TIMELINE_LIMITS["tasks"]
MAX_ATTEMPTS = TASK_TIMELINE_LIMITS["attempts"]
MAX_HISTORY_CALLS = TASK_TIMELINE_LIMITS["historyCalls"]
TIMELINE_SECONDS = TASK_TIMELINE_LIMITS["operationSeconds"]
TASK_STATES = frozenset(
    "success failed running queued scheduled up_for_retry up_for_reschedule "
    "deferred skipped upstream_failed restarting removed none awaiting_input no_status".split()
)

if TYPE_CHECKING:
    from .api import ApiClient


class TaskTimelineError(ValueError):
    """One bounded public cause; raw upstream exceptions never enter JSON."""

    def __init__(self, code: str, *, observed: int | None = None) -> None:
        self.code = code if isinstance(code, str) and code in TASK_TIMELINE_ERRORS else "unavailable"
        self.policy = TASK_TIMELINE_ERRORS[self.code]
        self.status = self.policy["status"]
        self.observed = observed
        limit_key = self.policy["limitKey"]
        self.limit = TASK_TIMELINE_LIMITS.get(limit_key)
        super().__init__(self.policy["note"].replace("{limit}", str(self.limit)))

    def payload(self) -> dict[str, Any]:
        """Publish allowlisted policy and safe numeric context only."""
        result: dict[str, Any] = {
            "schema": TASK_TIMELINE_ERROR_SCHEMA,
            "code": self.code,
            "retryable": self.policy["retryable"],
        }
        if self.limit is not None:
            result["limit"] = self.limit
        if isinstance(self.observed, int) and not isinstance(self.observed, bool) and 0 <= self.observed <= 2147483647:
            result["observed"] = self.observed
        return result


def task_timeline_failure(exc: Exception) -> TaskTimelineError:
    """Map typed transport failures without inspecting exception messages."""
    if isinstance(exc, TaskTimelineError):
        return exc
    code = getattr(exc, "code", None)
    if isinstance(code, str) and code in TASK_TIMELINE_ERRORS:
        return TaskTimelineError(code)
    status = getattr(exc, "status", None)
    if status in {401, 403, 404, 429, 500, 502, 503, 504}:
        return TaskTimelineError({401: "authentication", 403: "forbidden",
                                  404: "missing", 429: "busy", 504: "timeout"}.get(
                                      status, "temporarily_unavailable"))
    if isinstance(exc, TimeoutError):
        return TaskTimelineError("timeout")
    if isinstance(exc, PermissionError):
        return TaskTimelineError("forbidden")
    return TaskTimelineError("malformed" if isinstance(exc, ValueError) else "unavailable")


class TaskAttempt(TypedDict):
    """An actual execution interval or an authoritative timestamp marker."""

    tryNumber: int
    state: str
    start: str | None
    end: str | None
    marker: str | None


class TimelineTask(TypedDict):
    """One task instance; mapped instances always remain separate."""

    taskId: str
    mapIndex: int
    current: TaskAttempt
    attempts: list[TaskAttempt]


class TaskTimelinePayload(TypedDict):
    """Complete task identity set and explicitly qualified attempt coverage."""

    schema: Literal["task-timeline-v2"]
    dagId: str
    dagRunId: str
    complete: bool
    historyComplete: bool
    tasks: list[TimelineTask]


class DagTaskTimelinePayload(TypedDict):
    """Every requested run is enumerated before this payload is published."""

    schema: Literal["dag-task-timeline-v2"]
    dagId: str
    complete: bool
    runs: list[TaskTimelinePayload]


@dataclass(slots=True)
class TimelineBudget:
    """One shared task, attempt, history and time budget for a DAG expansion."""

    deadline: float = field(default_factory=lambda: monotonic() + TIMELINE_SECONDS)
    tasks: int = 0
    attempts: int = 0
    history_calls: int = 0


def validate_timeline_run_ids(run_ids: list[str]) -> list[str]:
    """Reject ambiguous or excessive scope before making any upstream request."""
    if not isinstance(run_ids, list) or not run_ids:
        raise TaskTimelineError("invalid_run_id")
    if len(run_ids) > MAX_RUNS:
        raise TaskTimelineError("run_limit", observed=len(run_ids))
    validated = [validate_timeline_identifier(run, TASK_TIMELINE_LIMITS["runIdCharacters"]) for run in run_ids]
    if len(set(validated)) != len(validated):
        raise TaskTimelineError("invalid_run_id")
    return sorted(validated)


def collect_dag_task_timeline(
    client: ApiClient, dag_id: str, run_ids: list[str]
) -> DagTaskTimelinePayload:
    """Collect a complete authorized run set using one shared bounded client."""
    validate_timeline_identifier(dag_id, TASK_TIMELINE_LIMITS["dagIdCharacters"])
    ids = validate_timeline_run_ids(run_ids)
    budget = TimelineBudget()
    runs = [collect_task_timeline(client, dag_id, run, budget=budget) for run in ids]
    _check_timeline_deadline(budget.deadline)
    return {'schema': 'dag-task-timeline-v2', 'dagId': dag_id, 'complete': True, 'runs': runs}


def validate_timeline_identifier(value: str, maximum: int) -> str:
    """Reject collection wildcards, path traversal and unbounded identifiers."""
    if (
        not isinstance(value, str)
        or not value
        or len(value) > maximum
        or value in {"~", ".", ".."}
        or any(ord(c) < 32 or ord(c) == 127 for c in value)
    ):
        raise TaskTimelineError("invalid_run_id")
    return value


def _timeline_integer(value: object, minimum: int) -> int:
    if (
        isinstance(value, bool)
        or not isinstance(value, int)
        or not minimum <= value <= 2147483647
    ):
        raise ValueError('Invalid task timeline integer')
    return value


def _timeline_timestamp(value: object) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or len(value) > 64:
        raise ValueError('Invalid task timeline timestamp')
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError('Task timeline timestamps require an offset')
    return parsed.astimezone(timezone.utc).isoformat()


def _instance_identity(
    row: Mapping[str, Any], dag_id: str, run_id: str
) -> tuple[str, int]:
    if row.get('dag_id') != dag_id or row.get('dag_run_id') != run_id:
        raise TaskTimelineError("membership_mismatch")
    try:
        return (
            validate_timeline_identifier(row.get("task_id"), TASK_TIMELINE_LIMITS["taskIdCharacters"]),
            _timeline_integer(row.get("map_index"), -1),
        )
    except ValueError as exc:
        raise TaskTimelineError("malformed") from exc


def _attempt(row: Mapping[str, Any]) -> TaskAttempt:
    number = _timeline_integer(row.get('try_number'), 0)
    state = row.get('state')
    state = 'none' if state is None else state
    state = state if isinstance(state, str) and state in TASK_STATES else 'unknown'
    start = _timeline_timestamp(row.get('start_date'))
    end = _timeline_timestamp(row.get('end_date'))
    if end is not None and (start is None or end < start):
        raise ValueError('Invalid task execution interval')
    marker_field = {'queued': 'queued_when', 'scheduled': 'scheduled_when'}.get(state)
    marker = (
        _timeline_timestamp(row.get(marker_field))
        if marker_field and start is None
        else None
    )
    return {
        "tryNumber": number,
        "state": state,
        "start": start,
        "end": end,
        "marker": marker,
    }


def _check_timeline_deadline(deadline: float) -> None:
    if monotonic() >= deadline:
        raise TimeoutError('Task timeline request deadline exceeded')


def _history_attempts(
    client: ApiClient,
    resource: str,
    current: Mapping[str, Any],
    identity: tuple[str, int],
    dag_id: str,
    run_id: str,
) -> tuple[list[TaskAttempt], bool]:
    """Prefer authoritative history; qualify only explicitly unavailable routes."""
    task_id, map_index = identity
    task_path = quote(task_id, safe='')
    suffix = (
        f"/{task_path}/{map_index}/tries"
        if map_index >= 0
        else f"/{task_path}/tries"
    )
    try:
        payload = client.get(resource + suffix, cache=False)
    except Exception as exc:
        if getattr(exc, 'status', None) not in {404, 405, 501}:
            raise
        return [_attempt(current)], False
    history, total = payload.get('task_instances'), payload.get('total_entries')
    if isinstance(total, int) and not isinstance(total, bool) and total > MAX_ATTEMPTS:
        raise TaskTimelineError("attempt_limit", observed=total)
    if (
        not isinstance(history, list)
        or isinstance(total, bool)
        or not isinstance(total, int)
        or total != len(history)
        or total > MAX_ATTEMPTS
    ):
        raise TaskTimelineError("incomplete")
    by_try: dict[int, TaskAttempt] = {}
    for row in history:
        if (
            not isinstance(row, Mapping)
            or _instance_identity(row, dag_id, run_id) != identity
        ):
            raise TaskTimelineError("membership_mismatch")
        attempt = _attempt(row)
        previous = by_try.get(attempt['tryNumber'])
        if previous is not None and previous != attempt:
            raise ValueError('Conflicting task attempt records')
        by_try[attempt['tryNumber']] = attempt
    current_attempt = _attempt(current)
    by_try.setdefault(current_attempt['tryNumber'], current_attempt)
    numbers = set(by_try)
    last = max(numbers, default=0)
    complete = last <= MAX_ATTEMPTS and all(
        n in numbers for n in range(1, min(last, MAX_ATTEMPTS) + 1)
    )
    return [by_try[n] for n in sorted(by_try)], complete


def collect_task_timeline(
    client: ApiClient, dag_id: str, run_id: str, *, budget: TimelineBudget | None = None
) -> TaskTimelinePayload:
    """Return a complete bounded task list, with only authoritative intervals."""
    budget = budget if budget is not None else TimelineBudget()
    deadline = budget.deadline
    validate_timeline_identifier(dag_id, TASK_TIMELINE_LIMITS["dagIdCharacters"])
    validate_timeline_identifier(run_id, TASK_TIMELINE_LIMITS["runIdCharacters"])
    resource = f'dags/{quote(dag_id, safe="")}/dagRuns/{quote(run_id, safe="")}'
    _check_timeline_deadline(deadline)
    run = client.get(resource, cache=False)
    if not isinstance(run, Mapping):
        raise TaskTimelineError("malformed")
    if run.get('dag_id') != dag_id or run.get('dag_run_id') != run_id:
        raise TaskTimelineError("membership_mismatch")
    resource += '/taskInstances'
    _check_timeline_deadline(deadline)
    try:
        rows = client.page(resource, 'task_instances', [("order_by", "id")])
    except Exception as exc:
        stats = getattr(client, "stats", None)
        if getattr(stats, "max_rows_hit", False):
            raise TaskTimelineError("task_limit") from exc
        if getattr(stats, "incomplete_reasons", ()):
            raise TaskTimelineError("incomplete") from exc
        raise
    if getattr(getattr(client, 'stats', None), 'incomplete_reasons', ()):
        raise TaskTimelineError("incomplete")
    budget.tasks += len(rows)
    if budget.tasks > MAX_TASKS:
        raise TaskTimelineError("task_limit", observed=budget.tasks)
    tasks: list[TimelineTask] = []
    seen: set[tuple[str, int]] = set()
    history_complete = True
    for row in rows:
        _check_timeline_deadline(deadline)
        if not isinstance(row, Mapping):
            raise ValueError('Invalid task instance record')
        identity = _instance_identity(row, dag_id, run_id)
        if identity in seen:
            raise ValueError('Duplicate task instance identity')
        seen.add(identity)
        current = _attempt(row)
        complete = True
        needs_history = current["tryNumber"] > 1 or current["state"] in {
            "up_for_retry", "up_for_reschedule", "deferred", "restarting"
        }
        if needs_history:
            budget.history_calls += 1
            if budget.history_calls > MAX_HISTORY_CALLS:
                raise TaskTimelineError("history_limit", observed=budget.history_calls)
            attempts, complete = _history_attempts(
                client, resource, row, identity, dag_id, run_id
            )
        else:
            attempts = [current]
        budget.attempts += len(attempts)
        if budget.attempts > MAX_ATTEMPTS:
            raise TaskTimelineError("attempt_limit", observed=budget.attempts)
        history_complete = history_complete and complete
        tasks.append(
            {"taskId": identity[0], "mapIndex": identity[1], "current": current, "attempts": attempts}
        )
    _check_timeline_deadline(deadline)
    tasks.sort(key=lambda item: (item['taskId'], item['mapIndex']))
    return {
        "schema": "task-timeline-v2",
        "dagId": dag_id,
        "dagRunId": run_id,
        "complete": True,
        "historyComplete": history_complete,
        "tasks": tasks,
    }
