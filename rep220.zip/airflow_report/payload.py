# SPDX-License-Identifier: Apache-2.0
"""Canonical renderer payload assembly facade."""

from __future__ import annotations

from .api_contract import API_VERSION
from .configuration_values import iso
from .configuration_windows import selected_day_intervals
from .generated_contracts import (
    HISTORICAL_TRANSPORT_SCHEMA_GENERATED,
    PAYLOAD_SCHEMA_GENERATED,
    TRANSPORT_SCHEMA_GENERATED,
)
from .models import Report
from .payload_context import PayloadAssemblyContext, build_payload_context
from .payload_integrity import payload_integrity
from .payload_io import base_log_folder as base_log_folder
from .payload_io import output_path as output_path
from .payload_metadata import (
    capacity_payload,
    dag_parameter_payload,
    identity_payload,
    live_filter_payload,
    ordered_run_types,
    performance_payload,
)
from .payload_rows import historical_run_transport
from .preamble import STATE_ORDER, Any
from .timezone_model import airflow_default_timezone


def _render_parameters(report: Report) -> dict[str, Any]:
    """Return the bounded renderer configuration contract."""
    config = report.config
    return {
        "selectedDays": list(config.selected_days),
        "maxRenderedRuns": config.max_rendered_runs,
        "maxTaskCountRuns": config.max_task_instance_calls,
        "maxHtmlBuckets": config.max_html_buckets,
        "apiPageLimit": config.page_limit,
        "apiMaxPages": config.max_pages,
        "apiMaxRows": config.max_rows,
        "selectedApiVersion": API_VERSION,
        "historicalComplete": report.historical_complete,
        "projectionComplete": report.projection_complete,
        "perDagEnrichment": False,
        "taskInstanceCounting": config.count_task_instances,
        "verifyOpenActiveRuns": config.verify_open_runs,
        "openRunUnverifiedMode": config.open_run_mode,
        "openRunMaxHours": config.open_run_max_hours,
        "staleDagOpenActiveMode": "marker_or_skip_never_active",
        "maxFutureOccurrences": config.max_future_occurrences,
        "maxFutureOccurrencesPerDag": config.max_future_per_dag,
    }


def _availability(report: Report, context: PayloadAssemblyContext) -> dict[str, bool]:
    """Return feature availability without creating secondary ledgers."""
    analytics = context.historical_analytics
    return {
        "taskCriticalPath": False,
        "historicalPercentileBands": analytics["qualifiedDagCount"] > 0,
        "explainableAnomalyScores": bool(analytics["runScores"]),
        "dependencyEdges": False,
        "manualBlackoutsEmbedded": False,
        "calendarGraphRemoved": True,
        "sparseBucketPayload": True,
        "externalRenderer": True,
        "futureProjection": True,
        "scheduleOnlyLanes": True,
        "semanticRendererContract": True,
        "liveFilters": report.source_mode == "materialized",
    }


def build_payload(report: Report) -> dict[str, Any]:
    """Build the complete canonical renderer payload exactly once."""
    context: PayloadAssemblyContext = build_payload_context(report)
    integrity = payload_integrity(context)
    return {
        "schema": PAYLOAD_SCHEMA_GENERATED,
        "sourceName": report.source_name,
        "sourceMode": report.source_mode,
        "sourceOrigin": report.source_origin,
        "airflowUiBasePath": report.airflow_ui_base_path,
        "sourceSha256": report.backend_sha256[:16],
        "sourceSchema": "airflow-public-api-runtime-v4",
        "hostFqdn": report.hostname,
        "title": f"AIRFLOW RUNTIME REPORT | {report.hostname}",
        "generatedAt": iso(report.generated_at),
        "windowStart": iso(report.config.history_start),
        "windowEnd": iso(report.config.history_end),
        "displayEnd": iso(context.display_end),
        "timezone": report.config.timezone,
        "timezoneContext": {
            "displayTimezone": report.config.timezone,
            "airflowDefaultTimezone": airflow_default_timezone(),
            "timestampPolicy": "absolute-instants-displayed-in-report-timezone",
            "schedulePolicy": "per-dag-schedule-timezone",
            "runIdPolicy": "opaque-unmodified",
        },
        "calendarDays": context.calendar_days,
        "bucketSeconds": report.config.bucket_seconds,
        "requestedBucketSeconds": report.config.requested_bucket_seconds,
        "bucketEncoding": {
            "type": "sparse-v1",
            "bucketCount": context.total_buckets,
            "nonEmptyBucketCount": context.non_empty_buckets,
            "emptyBucketCount": context.empty_buckets,
            "emptyBucketRatio": round(
                context.empty_buckets / max(1, context.total_buckets), 6
            ),
            "schema": [
                "i",
                "runCount",
                "dagCount",
                "success",
                "failed",
                "active",
                "queued",
                "skipped",
                "other",
                "used",
                "risk",
                "riskNorm",
                "dominant",
            ],
        },
        "summary": context.summary,
        "dataIntegrity": integrity,
        "performance": performance_payload(report),
        "identity": identity_payload(report),
        "historicalLedger": {
            **dict(report.historical_ledger),
            "sha256": context.historical_sha256,
        },
        "historicalLedgerSha256": context.historical_sha256,
        "projectionLedger": dict(report.projection_ledger),
        "futureProjection": context.future_projection,
        "historicalAnalytics": context.historical_analytics,
        "capacity": capacity_payload(report),
        "transport": {
            "schema": TRANSPORT_SCHEMA_GENERATED,
            "historicalRuns": HISTORICAL_TRANSPORT_SCHEMA_GENERATED,
            "futureRuns": "compact-object-v1",
        },
        "runs": historical_run_transport(context.runs),
        "futureRuns": context.future,
        "scheduleDiagnostics": context.audits,
        "liveFilters": live_filter_payload(report),
        "dagMeta": context.dags,
        "buckets": context.sparse_buckets,
        "freeWindows": context.free,
        "tags": context.tags,
        "historicalTagSource": context.historical_tag_source,
        "tagFilterOptions": context.tag_filter_options,
        "runTypes": ordered_run_types(report),
        "badges": ["ACTIVE", "PAUSED", "STALE"],
        "states": list(STATE_ORDER),
        "selectedIntervals": [
            {"day": day, "abs0": iso(start), "abs1": iso(end)}
            for start, end, day in selected_day_intervals(report.config)
        ],
        "dagParameters": dag_parameter_payload(report),
        "renderParams": _render_parameters(report),
        "availability": _availability(report, context),
    }
