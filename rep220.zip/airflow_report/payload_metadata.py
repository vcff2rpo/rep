# SPDX-License-Identifier: Apache-2.0
"""Canonical report metadata, summary, capacity, projection, and filter serialization."""

from __future__ import annotations

from .aggregation import report_mode_for_seconds, state_counts
from .api_contract import API_VERSION
from .configuration_values import iso
from .configuration_windows import calendar_day_intervals, selected_history_seconds
from .models import Report, Run
from .preamble import (
    AIRFLOW_VERSION,
    BUILD_ID,
    CONTENT_MANIFEST_FILENAME,
    MAX_FUTURE_DAYS,
    MAX_HISTORY_DAYS,
    MAX_TOTAL_TIMELINE_ITEMS_HARD,
    PARENT_SOURCE_ARCHIVE_SHA256,
    PARENT_SOURCE_RELEASE,
    RELEASE_ID,
    RENDERER_CONTRACT,
    REPORT_ID,
    Any,
    Counter,
    Mapping,
    Path,
    Sequence,
)


def performance_payload(report: Report) -> dict[str, Any]:
    """Build bounded collection and renderer performance metadata."""
    total = len(report.buckets)
    non_empty = sum(
        (1 for bucket in report.buckets if bucket.run_ids or bucket.risk > 0)
    )
    empty = max(0, total - non_empty)
    return {
        "reportMode": report_mode_for_seconds(
            (report.config.history_end - report.config.history_start).total_seconds()
        ),
        "payloadStrategy": "application-json-columnar-runs-sparse-buckets-v3",
        "transportCompaction": "historical-columnar-v1+dag-meta-rehydration-v1",
        "transportSchema": "report-transport-v1",
        "payloadByteCount": "__000000000000__",
        "reportByteCount": "__111111111111__",
        "performanceProfile": "auto",
        "maxGanttDomItems": 1200,
        "largeReportThresholdBytes": 768 * 1024,
        "cpuSafeTimelineItemThreshold": 800,
        "cpuSafeEstimatedDomThreshold": 3500,
        "largeReportMaxGanttDomItems": 650,
        "bucketAutoScaled": report.config.bucket_auto_scaled,
        "requestedBucketSeconds": report.config.requested_bucket_seconds,
        "effectiveBucketSeconds": report.config.bucket_seconds,
        "maxHtmlBuckets": report.config.max_html_buckets,
        "maxDomBucketCells": 1200,
        "largeReportMaxDomBucketCells": 320,
        "maxOverviewPoints": 1000,
        "largeReportMaxOverviewPoints": 320,
        "defaultLayers": {
            "buckets": False,
            "free": False,
            "risk": False,
            "annotations": False,
            "crossedTiming": False,
        },
        "totalBuckets": total,
        "nonEmptyBuckets": non_empty,
        "emptyBuckets": empty,
        "emptyBucketRatio": round(empty / max(1, total), 6),
        "perDagEnrichment": False,
        "taskInstanceCounting": report.config.count_task_instances,
        "verifyOpenActiveRuns": report.config.verify_open_runs,
        "openRunUnverifiedMode": report.config.open_run_mode,
        "openRunMaxHours": report.config.open_run_max_hours,
        "staleDagOpenActiveMode": "marker_or_skip_never_active",
        "note": (
            "Sparse historical buckets are expanded in-browser; DAG-stable run "
            "fields are rehydrated from dagMeta; historical rows use a columnar "
            "application/json transport; future points are separate and never "
            "enter historical buckets."
        ),
        "apiRequests": report.stats.requests,
        "apiPages": report.stats.pages,
        "apiRows": report.stats.rows,
        "apiResponseBytes": report.stats.response_bytes,
        "apiResponseByteLimitHits": report.stats.response_byte_limit_hits,
        "apiElapsedMs": report.stats.elapsed_ms,
        "apiCacheHits": report.stats.cache_hits,
        "apiCacheEntries": report.stats.cache_entries,
        "apiCacheBytes": report.stats.cache_bytes,
        "peakPageRows": report.stats.peak_page_rows,
        "maxRowsHit": report.stats.max_rows_hit,
        "duplicateRequestsPrevented": report.stats.duplicate_requests_prevented,
        "repeatedPagesStopped": report.stats.repeated_pages_stopped,
        "dagDetailCalls": report.stats.dag_detail_calls,
        "dagDetailUnavailable": report.stats.dag_detail_unavailable,
        "globalDagRunCalls": report.stats.global_run_calls,
        "perDagRunCalls": report.stats.per_dag_run_calls,
        "taskInstanceCalls": report.stats.task_instance_calls,
        "historicalMetricsExcludeFuture": True,
        "historicalComplete": report.historical_complete,
        "projectionComplete": report.projection_complete,
        "incompleteReasons": list(report.stats.incomplete_reasons),
        "projectionIncompleteReasons": list(report.stats.projection_incomplete_reasons),
        "selectedDayRejections": report.stats.selected_day_rejections,
        "selectedDaySegments": report.stats.selected_day_segments,
        "inputMembers": report.stats.input_members,
        "acceptedMembers": report.stats.accepted_members,
        "rejectedMembers": report.stats.rejected_members,
        "identityRejections": report.stats.identity_rejections,
        "normalizationRejections": report.stats.normalization_rejections,
        "duplicateConflicts": report.stats.duplicate_conflicts,
        "omittedRuns": report.stats.omitted_runs,
        "responseByteBudget": report.config.max_response_bytes,
        "maxHtmlBytes": report.config.max_html_bytes,
        "maxEmailAttachmentBytes": report.config.max_email_attachment_bytes,
        "insecureHttpAuth": report.stats.insecure_http_auth,
        "environmentProxyEnabled": report.stats.environment_proxy_enabled,
    }


def identity_payload(report: Report) -> dict[str, Any]:
    """Build release, runtime, and provenance identity metadata."""
    return {
        "runtimeId": REPORT_ID,
        "releaseId": RELEASE_ID,
        "buildId": BUILD_ID,
        "runId": report.config.run_id,
        "reportId": report.report_id,
        "backendFilename": Path(__file__).name,
        "backendSha256": report.backend_sha256,
        "backendDigestScope": "deployment-file-at-task-execution",
        "rendererFilename": report.config.renderer_path.name,
        "rendererSha256": report.renderer_sha256,
        "rendererContractVersion": RENDERER_CONTRACT,
        "contentManifestFilename": CONTENT_MANIFEST_FILENAME,
        "parentSourceRelease": PARENT_SOURCE_RELEASE,
        "parentSourceArchiveSha256": PARENT_SOURCE_ARCHIVE_SHA256,
        "selectedApiVersion": API_VERSION,
        "requestedApiVersion": API_VERSION,
        "apiProbeStatus": report.stats.api_probe_status,
        "insecureTls": report.stats.insecure_tls,
        "insecureHttpAuth": report.stats.insecure_http_auth,
        "environmentProxyEnabled": report.stats.environment_proxy_enabled,
        "airflowVersion": AIRFLOW_VERSION,
    }


def dag_parameter_payload(report: Report) -> dict[str, Any]:
    """Expose effective report parameters and their provenance."""
    return {
        "effective": {
            "requestedHistoryStart": iso(report.config.requested_history_start),
            "requestedHistoryEnd": iso(report.config.requested_history_end),
            "historyStart": iso(report.config.history_start),
            "historyEnd": iso(report.config.history_end),
            "reportDays": list(report.config.selected_days),
            "futureRequestedEnd": iso(report.config.future_requested_end),
            "futureEffectiveEnd": iso(report.config.future_effective_end),
            "timezone": report.config.timezone,
            "requestedBucketSeconds": report.config.requested_bucket_seconds,
            "effectiveBucketSeconds": report.config.bucket_seconds,
            "requestedApiVersion": API_VERSION,
            "selectedApiVersion": API_VERSION,
            "authMode": report.config.auth_mode,
            "emailRecipientCount": len(report.config.email_to),
        },
        "sources": dict(sorted(report.config.parameter_sources.items())),
        "precedence": ["params", "dag_run.conf"],
        "unknownRuntimeConfPolicy": "reject",
    }


def capacity_payload(report: Report) -> dict[str, Any]:
    """Serialize requested/effective date coverage and capacity accounting."""
    plan = report.capacity_plan
    reasons = list(plan.reasons)
    reason_text = ", ".join(reasons) if reasons else "none"
    helper = (
        f"Capacity fit: history {plan.effective_history_days}/"
        f"{plan.requested_history_days} days; future "
        f"{plan.effective_future_days}/{plan.requested_future_days} days; "
        f"retained {plan.retention_ratio * 100:.1f}%; "
        + (
            f"recalculated because {reason_text}."
            if plan.recalculated
            else "full requested range rendered."
        )
    )
    return {
        "policy": "equal-ratio-complete-days",
        "limits": {
            "historyDays": MAX_HISTORY_DAYS,
            "futureDays": MAX_FUTURE_DAYS,
            "historicalItems": report.config.max_rendered_runs,
            "futureOccurrences": report.config.max_future_occurrences,
            "timelineItems": MAX_TOTAL_TIMELINE_ITEMS_HARD,
            "futureTargetPerDag": report.config.future_target_per_dag,
        },
        "requested": {
            "historyStart": iso(plan.requested_history_start),
            "historyEnd": iso(plan.requested_history_end),
            "historyDays": plan.requested_history_days,
            "futureEnd": iso(plan.requested_future_end),
            "futureDays": plan.requested_future_days,
        },
        "effective": {
            "historyStart": iso(plan.effective_history_start),
            "historyEnd": iso(plan.effective_history_end),
            "historyDays": plan.effective_history_days,
            "futureEnd": iso(plan.effective_future_end),
            "futureDays": plan.effective_future_days,
        },
        "counts": {
            "historicalAvailable": plan.historical_available,
            "historicalRendered": plan.historical_rendered,
            "historicalOmitted": plan.historical_omitted,
            "futureAvailable": plan.future_available,
            "futureRendered": plan.future_rendered,
            "futureOmitted": plan.future_omitted,
            "combinedAvailable": plan.combined_available,
            "combinedRendered": plan.combined_rendered,
        },
        "futureCoverage": {
            "configuredTarget": plan.configured_future_target,
            "effectiveTarget": plan.effective_future_target,
            "targetMetDags": plan.future_target_met_dags,
            "targetTotalDags": plan.future_target_total_dags,
        },
        "retentionRatio": round(plan.retention_ratio, 6),
        "recalculated": plan.recalculated,
        "reasons": reasons,
        "helperNote": helper,
    }


def projection_payload(
    report: Report,
    future: Sequence[Mapping[str, Any]],
    audits: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Build the canonical future-projection summary object."""
    return {
        "enabled": report.config.future_enabled,
        "anchor": iso(report.config.trigger_time),
        "requestedEnd": iso(report.config.future_requested_end),
        "effectiveEnd": iso(report.config.future_effective_end),
        "clamped": report.config.future_clamped,
        "maximumCalendarDays": MAX_FUTURE_DAYS,
        "occurrences": len(future),
        "availableOccurrences": report.capacity_plan.future_available,
        "omittedOccurrences": report.capacity_plan.future_omitted,
        "coverageTarget": report.capacity_plan.configured_future_target,
        "effectiveCoverageTarget": report.capacity_plan.effective_future_target,
        "eligibleDags": sum((bool(row["eligible"]) for row in audits)),
        "projectedDags": len({str(item["dag"]) for item in future}),
    }


def summary_payload(
    report: Report,
    source_runs: Sequence[Run],
    calendar_days: Sequence[Mapping[str, Any]],
    runs: Sequence[Mapping[str, Any]],
    dags: Sequence[Mapping[str, Any]],
    future: Sequence[Mapping[str, Any]],
    audits: Sequence[Mapping[str, Any]],
    free: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Build the report summary from canonical payload sections."""
    counts = state_counts(source_runs)
    run_counts = Counter(run.dag_id for run in source_runs)
    top_dag = run_counts.most_common(1)[0][0] if run_counts else "<none>"
    return {
        "windowDays": round(selected_history_seconds(report.config) / 86400, 6),
        "selectedCalendarDays": len(report.config.selected_days)
        if report.config.selected_days
        else len(calendar_day_intervals(report.config)),
        "runs": len(source_runs),
        "runSegments": len(runs),
        "dags": len(dags),
        "failedRuns": counts["failed"],
        "successRuns": counts["success"],
        "activeRuns": counts["active"],
        "queuedRuns": counts["queued"],
        "renderBuckets": len(report.buckets),
        "nonEmptyBuckets": sum(
            (1 for bucket in report.buckets if bucket.run_ids or bucket.risk > 0)
        ),
        "emptyBuckets": sum(
            (1 for bucket in report.buckets if not bucket.run_ids and bucket.risk <= 0)
        ),
        "longestFreeWindow": max(
            free, key=lambda item: float(item.get("durationSec") or 0)
        )["label"]
        if free
        else "0s",
        "topDag": top_dag,
        "futureOccurrences": len(future),
        "scheduledDags": sum((bool(row["eligible"]) for row in audits)),
    }


def ordered_run_types(report: Report) -> list[str]:
    """Return deterministic run-type filter options."""
    actual_types = {run.run_type for run in report.runs}
    values: list[str] = [
        value for value in ("manual", "scheduled") if value in actual_types
    ]
    values.extend(sorted(actual_types - set(values), key=str.casefold))
    values.append("future")
    return values


def critical_window_indexes(report: Report) -> tuple[int, ...]:
    """Return canonical bucket indexes that the renderer treats as critical."""
    return tuple(
        bucket.index
        for bucket in report.buckets
        if bucket.risk_norm >= 0.65 or bucket.state_counts.get("failed", 0) > 0
    )


def live_filter_payload(report: Report) -> dict[str, object]:
    """Build idempotent server-rendered materialized filter values."""
    coverage = dict(report.materialized_coverage)
    relative_days = int(
        coverage.get("reportDays") or report.config.live_report_days or 0
    )
    future_end = report.config.future_requested_end
    today = report.generated_at.in_timezone(report.config.timezone).start_of("day")
    return {
        "enabled": report.source_mode == "materialized",
        "start": ""
        if relative_days
        else report.config.requested_history_start.to_date_string(),
        "end": ""
        if relative_days
        else report.config.requested_history_end.subtract(
            microseconds=1
        ).to_date_string(),
        "reportDays": relative_days,
        "futureEnd": future_end.subtract(microseconds=1).to_date_string()
        if future_end is not None
        else "",
        "coverageText": str(coverage.get("text") or ""),
        "coverage": coverage,
        "today": today.to_date_string(),
        "earliestHistory": today.subtract(days=9).to_date_string(),
        "latestFuture": today.add(days=9).to_date_string(),
        "maxHistoryDays": 10,
        "maxFutureDays": 10,
        "filterMessage": str(coverage.get("filterMessage") or ""),
        "invalidFields": list(coverage.get("invalidFields") or ()),
        "submitted": dict(coverage.get("submittedFilters") or {}),
    }
