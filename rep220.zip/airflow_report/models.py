# SPDX-License-Identifier: Apache-2.0
"""Typed runtime models for configuration, API accounting, and report data."""

from __future__ import annotations

from .preamble import (
    Any,
    Counter,
    Mapping,
    Path,
    TaskEnrichmentStatus,
    dataclass,
    field,
    pendulum,
)


@dataclass(frozen=True, slots=True)
class Config:
    """Hold validated immutable task configuration and resource budgets."""

    timezone: str
    requested_history_start: pendulum.DateTime
    requested_history_end: pendulum.DateTime
    history_start: pendulum.DateTime
    history_end: pendulum.DateTime
    history_clamped: bool
    trigger_time: pendulum.DateTime
    requested_selected_days: tuple[str, ...]
    selected_days: tuple[str, ...]
    future_enabled: bool
    future_requested_end: pendulum.DateTime | None
    future_effective_end: pendulum.DateTime | None
    future_clamped: bool
    requested_bucket_seconds: float
    bucket_seconds: float
    bucket_auto_scaled: bool
    max_html_buckets: int
    auth_mode: str
    api_conn_id: str
    token_endpoint: str
    api_timeout: int
    token_timeout: int
    api_retries: int
    token_retries: int
    api_backoff: float
    page_limit: int
    max_pages: int
    max_rows: int
    max_response_bytes: int
    max_detail_calls: int
    count_task_instances: bool
    verify_open_runs: bool
    open_run_mode: str
    open_run_max_hours: float
    max_task_instance_calls: int
    max_rendered_runs: int
    max_future_occurrences: int
    max_future_per_dag: int
    future_target_per_dag: int
    max_cache_entries: int
    max_cache_bytes: int
    max_request_fingerprints: int
    max_html_bytes: int
    max_email_attachment_bytes: int
    allow_insecure_tls: bool
    allow_insecure_http_auth: bool
    api_trust_env: bool
    new_directory_mode: int | None
    run_id: str
    task_instance_key: str
    renderer_path: Path
    email_to: tuple[str, ...]
    parameter_sources: Mapping[str, str]
    live_report_days: int = 0


@dataclass(frozen=True, slots=True)
class CapacityPlan:
    """Describe requested, effective, and rendered timeline capacity."""

    requested_history_start: pendulum.DateTime
    requested_history_end: pendulum.DateTime
    effective_history_start: pendulum.DateTime
    effective_history_end: pendulum.DateTime
    requested_future_end: pendulum.DateTime | None
    effective_future_end: pendulum.DateTime | None
    requested_history_days: int
    clamped_history_days: int
    effective_history_days: int
    requested_future_days: int
    clamped_future_days: int
    effective_future_days: int
    historical_available: int
    historical_rendered: int
    historical_omitted: int
    future_available: int
    future_rendered: int
    future_omitted: int
    combined_available: int
    combined_rendered: int
    retention_ratio: float
    recalculated: bool
    reasons: tuple[str, ...]
    configured_future_target: int
    effective_future_target: int
    future_target_met_dags: int
    future_target_total_dags: int


@dataclass(frozen=True, slots=True)
class RendererTemplate:
    """Store one validated renderer text object and its immutable identity."""

    text: str
    sha256: str
    size: int


@dataclass(frozen=True, slots=True)
class PublishedArtifact:
    """Identify the exact durable report artifact published by this task."""

    path: Path
    device: int
    inode: int
    size: int
    mtime_ns: int
    ctime_ns: int
    sha256: str


@dataclass(slots=True)
class ApiStats:
    """Accumulate bounded API, normalization, and completeness telemetry."""

    requests: int = 0
    pages: int = 0
    rows: int = 0
    input_members: int = 0
    accepted_members: int = 0
    rejected_members: int = 0
    identity_rejections: int = 0
    normalization_rejections: int = 0
    duplicate_conflicts: int = 0
    raw_run_rows: int = 0
    deduplicated_run_rows: int = 0
    omitted_runs: int = 0
    omitted_dags: int = 0
    omitted_state_counts: Counter[str] = field(default_factory=Counter)
    selected_day_rejections: int = 0
    selected_day_segments: int = 0
    cache_hits: int = 0
    cache_entries: int = 0
    cache_bytes: int = 0
    duplicate_requests_prevented: int = 0
    repeated_pages_stopped: int = 0
    dag_detail_calls: int = 0
    dag_detail_unavailable: int = 0
    global_run_calls: int = 0
    per_dag_run_calls: int = 0
    task_instance_calls: int = 0
    response_bytes: int = 0
    response_byte_limit_hits: int = 0
    response_status_classes: Counter[str] = field(default_factory=Counter)
    operation_requests: Counter[str] = field(default_factory=Counter)
    elapsed_ms: int = 0
    peak_page_rows: int = 0
    max_rows_hit: bool = False
    incomplete_reasons: list[str] = field(default_factory=list)
    projection_incomplete_reasons: list[str] = field(default_factory=list)
    api_probe_status: str = "not-run"
    active_query_strategy: str = "not-run"
    insecure_tls: bool = False
    insecure_http_auth: bool = False
    environment_proxy_enabled: bool = False

    @staticmethod
    def _append_reason(target: list[str], reason: str) -> None:
        """Append one normalized unique incompleteness reason."""
        normalized = str(reason).strip()
        if normalized and normalized not in target:
            target.append(normalized)

    def mark_incomplete(self, reason: str, *, projection: bool = False) -> None:
        """Record a historical or projection incompleteness reason."""
        target = (
            self.projection_incomplete_reasons
            if projection
            else self.incomplete_reasons
        )
        self._append_reason(target, reason)


@dataclass(frozen=True, slots=True)
class DagInfo:
    """Represent canonical metadata for one DAG."""

    dag_id: str
    tags: tuple[str, ...]
    owner: str
    fileloc: str
    paused: bool
    stale: bool
    schedule_kind: str
    schedule_expression: str
    schedule_summary: str
    schedule_timezone: str
    schedule_timezone_source: str
    schedule_source: str
    next_run: pendulum.DateTime | None
    eligible: bool
    exclusion_reason: str
    detail_status: str


@dataclass(frozen=True, slots=True)
class TaskEnrichmentResult:
    """Represent bounded task-instance enrichment for one DAG run."""

    status: TaskEnrichmentStatus
    state_counts: Counter[str] | None = None
    task_count: int | None = None
    open_count: int | None = None


@dataclass(frozen=True, slots=True)
class Run:
    """Represent one normalized historical run segment."""

    dag_id: str
    run_id: str
    source_run_id: str
    segment_index: int
    segment_count: int
    selected_day: str | None
    state: str
    raw_state: str
    run_type: str
    start: pendulum.DateTime
    end: pendulum.DateTime
    queued_at: pendulum.DateTime | None
    effective_start_source: str
    logical_date: pendulum.DateTime | None
    interval_start: pendulum.DateTime | None
    interval_end: pendulum.DateTime | None
    tags: tuple[str, ...]
    owner: str
    paused: bool
    stale: bool
    task_count: int | None
    task_enrichment_status: str
    synthetic_end: bool


@dataclass(frozen=True, slots=True)
class FutureRun:
    """Represent one projected future schedule occurrence."""

    projection_id: str
    dag_id: str
    projected_at: pendulum.DateTime
    schedule_kind: str
    schedule_summary: str
    schedule_timezone: str
    source: str
    paused: bool
    owner: str
    tags: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class ScheduleAudit:
    """Record projection eligibility and occurrence coverage for one DAG."""

    dag_id: str
    source: str
    kind: str
    eligible: bool
    reason: str
    detail_status: str
    occurrences: int
    truncated: bool
    available_occurrences: int = 0
    omitted_occurrences: int = 0
    configured_target: int = 20
    effective_target: int = 0
    coverage_status: str = "excluded"


@dataclass(slots=True)
class Bucket:
    """Aggregate concurrent run activity for one report time bucket."""

    index: int
    start: pendulum.DateTime
    end: pendulum.DateTime
    seconds: float = 0.0
    run_ids: set[str] = field(default_factory=set)
    dag_ids: set[str] = field(default_factory=set)
    state_counts: Counter[str] = field(default_factory=Counter)
    state_seconds: dict[str, float] = field(default_factory=dict)
    risk: float = 0.0
    risk_norm: float = 0.0
    dominant: str = "free"


@dataclass(frozen=True, slots=True)
class Report:
    """Contain canonical report-domain data independent of renderer storage."""

    config: Config
    generated_at: pendulum.DateTime
    output_path: Path
    hostname: str
    dags: Mapping[str, DagInfo]
    runs: tuple[Run, ...]
    future_runs: tuple[FutureRun, ...]
    schedule_audit: tuple[ScheduleAudit, ...]
    buckets: tuple[Bucket, ...]
    stats: ApiStats
    backend_sha256: str
    renderer_sha256: str
    report_id: str
    historical_complete: bool
    projection_complete: bool
    capacity_plan: CapacityPlan
    historical_ledger: Mapping[str, Any] = field(default_factory=dict)
    projection_ledger: Mapping[str, Any] = field(default_factory=dict)
    historical_tag_source_runs: tuple[Run, ...] = field(default_factory=tuple)
    historical_tag_window_start: pendulum.DateTime | None = None
    historical_tag_window_end: pendulum.DateTime | None = None
    source_name: str = "Airflow runtime report"
    source_mode: str = "scheduled"
    source_origin: str = "runtime:scheduled"
    airflow_ui_base_path: str = ""
    materialized_coverage: Mapping[str, Any] = field(default_factory=dict)
