# Third-party notices

The deployable runtime contains no bundled third-party JavaScript framework, external font, Python dependency tree, browser binary, or native library.

The project is designed to run with Apache Airflow and its installed dependencies. Validation uses separately installed tools recorded in `requirements-validation.lock` and `package-lock.json`. Those packages are not redistributed in the release archives and retain their own licenses. The validation-license policy permits Apache-2.0, MIT, BSD-2-Clause, BSD-3-Clause, and ISC packages. `tools/dependency_inventory.py` records declared dependencies in `SBOM.spdx.json` and reports missing license metadata explicitly. Actual Python wheels and npm tarballs remain unaudited until approved copies are available; this declaration is not a completed distribution-license audit.

Apache Airflow is an Apache Software Foundation project. The Airflow name is used only to describe interoperability; this project is not represented as an Apache Software Foundation work.

The header embeds the official Apache Airflow icon artwork from the Apache Airflow website. Original path geometry and colors are retained, with uniform 52px sizing and a scoped clip identifier. The artwork is an attributed project brand asset, not independently invented integration code. The geometry is retained unchanged from the locked parent; no new upstream artwork was copied in this release. No runtime download or JavaScript dependency is introduced. Apache Airflow and its logo remain Apache Software Foundation trademarks.
