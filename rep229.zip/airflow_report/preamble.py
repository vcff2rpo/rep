# SPDX-License-Identifier: Apache-2.0
"""Shared imports, release identity, and hard resource contracts.

The module contains component-neutral report runtime dependencies and safety
ceilings shared by scheduled and request-driven execution.
"""

from __future__ import annotations

import copy
import hashlib
import heapq
import json
import logging
import math
import os
import re
import socket
import stat
import tempfile
import time
from collections import Counter, OrderedDict
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field, replace
from datetime import datetime
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Final, Literal, NoReturn, TypeAlias, cast
from urllib.parse import quote, unquote, urlencode, urlsplit, urlunsplit

import pendulum
import requests
from airflow import __version__ as AIRFLOW_VERSION
from airflow.configuration import conf
from airflow.sdk import Connection, get_current_context
from croniter import CroniterBadCronError, croniter
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

_AIRFLOW_VERSION_MATCH = re.match(r"^\s*(\d+)\.(\d+)\.(\d+)", AIRFLOW_VERSION)
if _AIRFLOW_VERSION_MATCH is None:
    raise RuntimeError(
        f"unsupported Airflow version string: {AIRFLOW_VERSION!r}; expected MAJOR.MINOR.PATCH"
    )
_AIRFLOW_MAJOR = int(_AIRFLOW_VERSION_MATCH.group(1))
_AIRFLOW_MINOR = int(_AIRFLOW_VERSION_MATCH.group(2))
if _AIRFLOW_MAJOR != 3 or tuple(map(int, _AIRFLOW_VERSION_MATCH.groups())) < (3, 1, 7):
    raise RuntimeError(
        "airflow_runtime_report_v3 requires Airflow 3.1.7+ within major version 3; "
        f"detected {AIRFLOW_VERSION!r}"
    )


if _AIRFLOW_MAJOR == 3 and _AIRFLOW_MINOR >= 2:
    from airflow.sdk.exceptions import AirflowFailException
else:
    from airflow.exceptions import AirflowFailException

TaskEnrichmentStatus: TypeAlias = Literal["ok", "unknown", "error", "skipped"]

LOG: Final = logging.getLogger("airflow.task")
REPORT_ID: Final[str] = "airflow_runtime_report_v3"
RELEASE_ID: Final[str] = "release-20261029-201"
RENDERER_FILENAME: Final[str] = "airflow_runtime_report_v3.html"
EXPECTED_RENDERER_SHA256: Final[str] = (
    "2937b8534893362af795e748f0a4a52dabef82b42456f7c4c3dc6ee19fafef66"
)
RENDERER_CONTRACT: Final[str] = "contract_v3"
PAYLOAD_SCHEMA: Final[str] = "payload_v3"
PARENT_SOURCE_RELEASE: Final[str] = "release-20261029-200"
PARENT_SOURCE_ARCHIVE_SHA256: Final[str] = (
    "6779c19402469e21723d358a5c504ba4f4d16f700a2306c7cb445f3100f80d28"
)
BUILD_ID: Final[str] = "build-20261029-201"
CONTENT_MANIFEST_FILENAME: Final[str] = "SHA256SUMS_v3"
DATA_PLACEHOLDER: Final = "__AIRFLOW_REPORT_DATA_JSON__"
ENV_PREFIX: Final = "AIRFLOW_REPORT__"
DEFAULT_TIMEZONE: Final = "Europe/Prague"
MAX_HISTORY_DAYS: Final = 10
MAX_FUTURE_DAYS: Final = 10
DEFAULT_HISTORY_HOURS: Final = 24
STATE_ORDER: Final = ("success", "failed", "active", "queued", "skipped", "other")
ACTIVE_RAW_STATES: Final = {"running", "queued"}
OPEN_TASK_STATES: Final = frozenset(
    (
        "scheduled queued running restarting up_for_retry up_for_reschedule "
        "deferred awaiting_input"
    ).split()
)
STATE_ALIASES: Final = {
    "success": "success",
    "failed": "failed",
    "upstream_failed": "failed",
    "running": "active",
    "queued": "queued",
    "skipped": "skipped",
}
REQUIRED_DOM_IDS: Final = tuple(
    """
    title generatedMeta sourceMeta subtitle ref airflowReportData widthWarn liveReportFilters
    liveFilterStart liveFilterEnd liveFilterReportDays liveFilterFutureEnd liveFilterTimezone
    liveFilterApply liveFilterReset liveFilterReinit liveFilterStatus layerBuckets layerFree
    layerRisk layerAnnotations layerCrossedTiming statusLine stateFilter
    runTypeFilter tagFilter badgeFilter groupFilter searchFilter riskValue
    riskFilter kpis timelineInfo ganttTopSlider ganttTopSliderValue dayCalendar
    overviewSvg ganttTopNativeScroll ganttTopNativeScrollContent ganttLeft
    ganttLeftContent ganttYLeftScroll ganttYLeftScrollContent ganttTimeline
    timelineContent ganttYRightScroll ganttYRightScrollContent graphActionToolbar
    graphZoomInBtn graphZoomInRatio graphZoomOutBtn graphZoomOutRatio
    graphZoomSelectedBtn graphClearSelectionBtn
    graphResetFiltersBtn graphResetBtn graphDaySelector
    graphFocusExactBtn graphFocusDynamicBtn graphFocus5mBtn graphFocus15mBtn
    graphFocus1hBtn ganttMeta scopeSelectionLabel selectedRunTiles
    dataCoverageSection coverageNav cardCoverageRuns
    coverageRunsMeta coverageTimeFromDate coverageTimeFromHour
    coverageTimeFromMinute coverageTimeToDate coverageTimeToHour
    coverageTimeToMinute coverageTimeClear coverageTimeHint coverageRuns
    selectionStartHour selectionStartMinute selectionEndHour selectionEndMinute
    selectionDagsButton selectionValidation selectionFields selectionControlTooltip reportAirflowLogoClip selectionPlannerStatus
    cardCoverageDagMeta coverageDagMetaMeta coverageDagMeta
    cardCoverageFreeWindows coverageFreeWindowsMeta coverageFreeWindows
    cardCoverageSource coverageSourceMeta
    coverageSource tooltip
    """.split()
)
CRON_PRESETS: Final = {
    "@hourly": "0 * * * *",
    "@daily": "0 0 * * *",
    "@weekly": "0 0 * * 0",
    "@monthly": "0 0 1 * *",
    "@quarterly": "0 0 1 1,4,7,10 *",
    "@yearly": "0 0 1 1 *",
    "@annually": "0 0 1 1 *",
}
EMAIL_RE: Final = re.compile("^[^@\\s,;<>]+@[^@\\s,;<>]+\\.[^@\\s,;<>]+$")
SAFE_FILENAME_RE: Final = re.compile("[^A-Za-z0-9_.-]+")
ISO_DATE_RE: Final = re.compile("^\\d{4}-\\d{2}-\\d{2}$")
MIN_BUCKET_SECONDS: Final = 0.3
MAX_BUCKET_SECONDS: Final = 3600.0
MAX_BUCKETS: Final = 300000
NICE_BUCKETS: Final = (1, 5, 10, 30, 60, 120, 300, 600, 900, 1800, 3600)
MAX_RENDERER_BYTES: Final = 8 * 1024 * 1024
MAX_CA_BUNDLE_BYTES: Final = 4 * 1024 * 1024
MAX_API_ROWS_HARD: Final = 250_000
MAX_API_RESPONSE_BYTES_HARD: Final = 64 * 1024 * 1024
MAX_API_PAGES_HARD: Final = 5_000
MAX_API_CACHE_ENTRIES_HARD: Final = 128
MAX_API_CACHE_BYTES_HARD: Final = 8 * 1024 * 1024
MAX_REQUEST_FINGERPRINTS_HARD: Final = 5_000
MAX_DAG_DETAIL_CALLS_HARD: Final = 10_000
MAX_TASK_INSTANCE_CALLS_HARD: Final = 5_000
MAX_RENDERED_RUNS_HARD: Final = 10_000
MAX_FUTURE_OCCURRENCES_HARD: Final = 10_000
MAX_TOTAL_TIMELINE_ITEMS_HARD: Final = 20_000
MAX_FUTURE_PER_DAG_HARD: Final = 10_000
FUTURE_OCCURRENCES_TARGET_PER_DAG: Final = 20
MAX_HTML_BYTES_HARD: Final = 128 * 1024 * 1024
REPORT_PARAM_NAMES: Final = frozenset(
    {
        "start",
        "end",
        "report_days",
        "future_end",
        "timezone",
        "bucket_seconds",
        "auth_mode",
        "email_to",
    }
)


_FLAT_BUILD_BINDINGS = (
    AIRFLOW_VERSION,
    AirflowFailException,
    Any,
    Connection,
    Counter,
    CroniterBadCronError,
    HTMLParser,
    HTTPAdapter,
    Iterable,
    Mapping,
    NoReturn,
    OrderedDict,
    Path,
    Retry,
    Sequence,
    cast,
    conf,
    copy,
    croniter,
    dataclass,
    datetime,
    field,
    get_current_context,
    hashlib,
    heapq,
    json,
    math,
    os,
    pendulum,
    quote,
    replace,
    requests,
    socket,
    stat,
    tempfile,
    time,
    unquote,
    urlencode,
    urlsplit,
    urlunsplit,
)
